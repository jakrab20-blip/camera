plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "com.example.procamera"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.example.procamera"
        minSdk = 29
        targetSdk = 35
        versionCode = 6
        versionName = "0.6-open-gallery"
    }

    // ลงนามแอปรุ่น release: ตั้งตัวแปรสภาพแวดล้อม PROCAMERA_KEYSTORE (พาธไฟล์ .jks), PROCAMERA_STORE_PASSWORD,
    // PROCAMERA_KEY_ALIAS, PROCAMERA_KEY_PASSWORD ถ้าไม่ตั้ง จะสร้าง release แบบไม่ลงนาม (debug ไม่กระทบ)
    signingConfigs {
        create("release") {
            val ks = System.getenv("PROCAMERA_KEYSTORE")
            if (ks != null && file(ks).exists()) {
                storeFile = file(ks)
                storePassword = System.getenv("PROCAMERA_STORE_PASSWORD")
                keyAlias = System.getenv("PROCAMERA_KEY_ALIAS")
                keyPassword = System.getenv("PROCAMERA_KEY_PASSWORD")
            }
        }
    }
    buildTypes {
        release {
            // ยังไม่เปิด minify: ML Kit/CameraX ต้องมีกฎ keep ที่ทดสอบกับเครื่องจริงก่อน ไม่งั้นแอปอาจพังเฉพาะรุ่น release
            isMinifyEnabled = false
            val rel = signingConfigs.getByName("release")
            if (rel.storeFile != null) signingConfig = rel
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    buildFeatures {
        compose = true
    }
}

dependencies {
    val camerax = "1.4.2"
    implementation("androidx.camera:camera-core:$camerax")
    implementation("androidx.camera:camera-camera2:$camerax")
    implementation("androidx.camera:camera-lifecycle:$camerax")
    implementation("androidx.camera:camera-view:$camerax")
    implementation("androidx.camera:camera-video:$camerax")
    implementation("androidx.camera:camera-extensions:$camerax")
    implementation("androidx.annotation:annotation-experimental:1.4.1")
    implementation("androidx.exifinterface:exifinterface:1.3.7")
    // โหมดภาพเหมือน: แยกตัวคนออกจากฉากหลัง (โมเดลฝังในแอป ไม่ต้องโหลดตอนใช้งาน)
    implementation("com.google.mlkit:segmentation-selfie:16.0.0-beta6")
    implementation("com.google.android.gms:play-services-tasks:18.2.0")

    implementation(platform("androidx.compose:compose-bom:2024.10.01"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")

    implementation("androidx.activity:activity-compose:1.9.3")
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.7")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0")

    testImplementation("junit:junit:4.13.2")
}
