package com.example.procamera

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Matrix
import android.graphics.Paint
import android.location.Location
import android.location.LocationManager
import android.hardware.camera2.CameraMetadata
import androidx.core.content.ContextCompat
import androidx.exifinterface.media.ExifInterface
import java.io.File
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.roundToInt

// =====================================================================
//  ตัวช่วยของฟีเจอร์ "มืออาชีพ" รอบที่ 8: สมดุลสีขาว, โฟกัสมือ, ซูมตามเลนส์จริง, ตราวันที่, GPS, พื้นที่เก็บข้อมูล
// =====================================================================

/** ค่าสมดุลสีขาวแบบพรีเซ็ต (ค่า K เป็นค่าประมาณที่ใช้เรียกโหมดของ Camera2 ไม่ใช่ค่าที่วัดจริงของเครื่อง) */
data class WbPreset(val label: String, val awbMode: Int, val kelvin: Int)

val WbPresets = listOf(
    WbPreset("อัตโนมัติ", CameraMetadata.CONTROL_AWB_MODE_AUTO, 0),
    WbPreset("หลอดไส้ 2700K", CameraMetadata.CONTROL_AWB_MODE_INCANDESCENT, 2700),
    WbPreset("ไฟอุ่น 3000K", CameraMetadata.CONTROL_AWB_MODE_WARM_FLUORESCENT, 3000),
    WbPreset("ฟลูออเรสเซนต์ 4000K", CameraMetadata.CONTROL_AWB_MODE_FLUORESCENT, 4000),
    WbPreset("แดด 5500K", CameraMetadata.CONTROL_AWB_MODE_DAYLIGHT, 5500),
    WbPreset("เมฆมาก 6500K", CameraMetadata.CONTROL_AWB_MODE_CLOUDY_DAYLIGHT, 6500),
    WbPreset("เงา 7500K", CameraMetadata.CONTROL_AWB_MODE_SHADE, 7500),
    WbPreset("พลบค่ำ", CameraMetadata.CONTROL_AWB_MODE_TWILIGHT, 4500)
)

/** ตัวเลือกหลังถ่ายที่ส่งเข้า processAndSave */
data class PhotoPostOptions(
    val sharpen: Float = 0.9f,
    val stamp: Boolean = false,
    val location: Location? = null
)

/** ระดับความคมชัดในตั้งค่า 0=ปิด 1=นุ่ม 2=มาตรฐาน 3=คมมาก -> ความแรง unsharp mask */
fun sharpenAmount(level: Int): Float = when (level) {
    0 -> 0f
    1 -> 0.5f
    3 -> 1.3f
    else -> 0.9f
}

/** ปุ่มซูมที่จะแสดง อิงช่วงซูมจริงที่กล้องรายงาน (เช่น เครื่องมีอัลตราไวด์ min จะ <1) */
fun zoomStepsFor(minZ: Float, maxZ: Float): List<Float> {
    val out = ArrayList<Float>()
    if (minZ < 0.95f) out.add(ceil(minZ * 10f - 0.001f) / 10f)
    if (minZ <= 1.01f && maxZ >= 0.99f) out.add(1f)
    for (z in listOf(2f, 3f, 5f, 10f)) if (z <= maxZ + 0.01f && z >= minZ) out.add(z)
    return out
}

fun zoomLabel(z: Float): String =
    if (abs(z - z.roundToInt()) < 0.05f) z.roundToInt().toString() else "%.1f".format(z)

/** ตำแหน่งโฟกัสมือ 0 = ไกลสุด (∞) ... 1 = ใกล้สุดที่เลนส์โฟกัสได้ */
fun focusDistanceLabel(pos: Float, maxDiopter: Float): String {
    val d = pos * maxDiopter
    return if (d < 0.05f) "ไกล (∞)" else "%.0f ซม.".format(100f / d)
}

/** พื้นที่ว่างพอไหม (ตรวจจากพาร์ทิชันเดียวกับ cache) ถ้าตรวจไม่ได้ให้ถือว่าพอ */
fun hasFreeSpace(context: Context, minMb: Long): Boolean =
    runCatching { context.cacheDir.usableSpace > minMb * 1024L * 1024L }.getOrDefault(true)

/** ตำแหน่งล่าสุดที่ระบบจำไว้ (ไม่เกิน 30 นาที) ต้องได้รับสิทธิ์ตำแหน่งก่อน ไม่มีสิทธิ์/ไม่มีตำแหน่ง = null */
fun lastKnownLocation(context: Context): Location? {
    val fine = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) ==
        PackageManager.PERMISSION_GRANTED
    val coarse = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) ==
        PackageManager.PERMISSION_GRANTED
    if (!fine && !coarse) return null
    val lm = context.getSystemService(Context.LOCATION_SERVICE) as? LocationManager ?: return null
    var best: Location? = null
    for (provider in listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER, LocationManager.PASSIVE_PROVIDER)) {
        val l = try {
            lm.getLastKnownLocation(provider)
        } catch (e: Exception) {
            null
        }
        val b = best
        if (l != null && (b == null || l.time > b.time)) best = l
    }
    val result = best ?: return null
    return if (System.currentTimeMillis() - result.time < 30 * 60 * 1000L) result else null
}

fun hasLocationPermission(context: Context): Boolean =
    ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
        ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED

/** เขียนพิกัด GPS ลง EXIF ของไฟล์ JPEG */
fun writeGps(file: File, loc: Location) {
    val exif = ExifInterface(file.absolutePath)
    exif.setLatLong(loc.latitude, loc.longitude)
    exif.saveAttributes()
}

/**
 * ประทับวันที่/เวลาที่มุมขวาล่างของภาพ โดยคำนึงถึงทิศทาง EXIF (บิตแมปที่ถอดรหัสยังเป็นทิศดิบของเซนเซอร์)
 * จึงหมุนแคนวาสให้ข้อความตั้งตรงเมื่อดูภาพตามทิศ EXIF
 */
fun drawDateStamp(bmp: Bitmap, orientation: Int, text: String) {
    val w = bmp.width.toFloat()
    val h = bmp.height.toFloat()
    val canvas = Canvas(bmp)
    val m = Matrix()
    var uw = w
    var uh = h
    when (orientation) {
        ExifInterface.ORIENTATION_ROTATE_90 -> {
            m.setValues(floatArrayOf(0f, 1f, 0f, -1f, 0f, h, 0f, 0f, 1f)); uw = h; uh = w
        }
        ExifInterface.ORIENTATION_ROTATE_180 ->
            m.setValues(floatArrayOf(-1f, 0f, w, 0f, -1f, h, 0f, 0f, 1f))
        ExifInterface.ORIENTATION_ROTATE_270 -> {
            m.setValues(floatArrayOf(0f, -1f, w, 1f, 0f, 0f, 0f, 0f, 1f)); uw = h; uh = w
        }
    }
    canvas.concat(m)
    val size = (uw * 0.028f).coerceAtLeast(14f)
    val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFFFD60A.toInt()
        textSize = size
        textAlign = Paint.Align.RIGHT
        setShadowLayer(size * 0.15f, 0f, 0f, 0xFF000000.toInt())
    }
    val margin = size * 1.2f
    canvas.drawText(text, uw - margin, uh - margin, paint)
}

fun shareText(context: Context, subject: String, text: String) {
    runCatching {
        val i = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, subject)
            putExtra(Intent.EXTRA_TEXT, text.takeLast(20000))
        }
        context.startActivity(Intent.createChooser(i, subject).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }
}
