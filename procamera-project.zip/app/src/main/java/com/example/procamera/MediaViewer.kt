package com.example.procamera

import android.app.Activity
import android.app.RecoverableSecurityException
import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.widget.Toast
import android.widget.VideoView
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.FavoriteBorder
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.RotateRight
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.exifinterface.media.ExifInterface
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import kotlin.math.max
import kotlin.math.roundToInt

// =====================================================================
//  หน้าดูภาพ/วิดีโอในแอป: เลื่อนซ้ายขวาดูภาพถ่ายและวิดีโอ (รวมสโลโมชัน/พาโนรามา) ที่เดียวกัน
//  ภาพถ่าย = แสดงเต็มจอ (พาโนรามาเลื่อนดูตามแนวนอนได้) / วิดีโอ = แตะเพื่อเล่น-หยุด มีแถบเลื่อนเวลา
//  ดึงเฉพาะไฟล์ที่แอปนี้บันทึกไว้ใน Pictures/ProCamera และ Movies/ProCamera
// =====================================================================

private val ViewerYellow = Color(0xFFFFD60A)

private class MediaEntry(val uri: Uri, val isVideo: Boolean, val name: String, val dateAdded: Long)

private fun queryMedia(context: Context): List<MediaEntry> {
    val out = ArrayList<MediaEntry>()
    fun query(base: Uri, isVideo: Boolean, path: String) {
        val proj = arrayOf(
            MediaStore.MediaColumns._ID,
            MediaStore.MediaColumns.DISPLAY_NAME,
            MediaStore.MediaColumns.DATE_ADDED
        )
        // ข้ามโฟลเดอร์ Timelapse ที่เหลือจากเวอร์ชันเก่า (ตัดโหมดไทม์แลปส์ออกแล้ว) ไม่ให้ปนกับภาพปกติ
        val sel = "${MediaStore.MediaColumns.RELATIVE_PATH} LIKE ? AND ${MediaStore.MediaColumns.RELATIVE_PATH} NOT LIKE ?"
        runCatching {
            context.contentResolver.query(base, proj, sel, arrayOf("$path%", "%Timelapse%"), null)?.use { c ->
                val idCol = c.getColumnIndexOrThrow(MediaStore.MediaColumns._ID)
                val nameCol = c.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME)
                val dateCol = c.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_ADDED)
                while (c.moveToNext()) {
                    out.add(
                        MediaEntry(
                            ContentUris.withAppendedId(base, c.getLong(idCol)),
                            isVideo,
                            c.getString(nameCol) ?: "",
                            c.getLong(dateCol)
                        )
                    )
                }
            }
        }
    }
    query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, false, "Pictures/ProCamera")
    query(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, true, "Movies/ProCamera")
    // ใหม่สุดก่อน (ชื่อไฟล์มีวันเวลา ใช้ตัดสินเมื่อเวลาเท่ากัน)
    return out.sortedWith(compareByDescending<MediaEntry> { it.dateAdded }.thenByDescending { it.name })
}

// ถอดรหัสภาพแบบย่อตามจำนวนพิกเซลสูงสุด พร้อมหมุนตาม EXIF (BitmapFactory ไม่ทำให้เอง)
private fun decodeForViewing(context: Context, uri: Uri): Bitmap? = runCatching {
    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
    val bw = max(1, bounds.outWidth)
    val bh = max(1, bounds.outHeight)
    val wide = bw > bh * 2.2f || bh > bw * 2.2f
    val maxPixels = if (wide) 16_000_000L else 4_000_000L
    var sample = 1
    while (bw.toLong() * bh / (sample.toLong() * sample) > maxPixels) sample *= 2
    val opts = BitmapFactory.Options().apply { inSampleSize = sample }
    val raw = context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
        ?: return@runCatching null
    val orientation = runCatching {
        context.contentResolver.openInputStream(uri)?.use {
            ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
        }
    }.getOrNull() ?: ExifInterface.ORIENTATION_NORMAL
    val m = Matrix()
    when (orientation) {
        ExifInterface.ORIENTATION_ROTATE_90 -> m.postRotate(90f)
        ExifInterface.ORIENTATION_ROTATE_180 -> m.postRotate(180f)
        ExifInterface.ORIENTATION_ROTATE_270 -> m.postRotate(270f)
        ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> m.postScale(-1f, 1f)
        ExifInterface.ORIENTATION_FLIP_VERTICAL -> m.postScale(1f, -1f)
        else -> return@runCatching raw
    }
    Bitmap.createBitmap(raw, 0, 0, raw.width, raw.height, m, true)
}.getOrNull()

/** เปิดไฟล์ด้วยแอปรูปภาพ/แกลเลอรี/เครื่องเล่นวิดีโอของเครื่อง คืน false ถ้าไม่มีแอปรับเปิด */
fun openInSystemGallery(context: Context, uri: Uri): Boolean = runCatching {
    val mime = context.contentResolver.getType(uri) ?: "image/*"
    val i = Intent(Intent.ACTION_VIEW).apply {
        setDataAndType(uri, mime)
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
    }
    context.startActivity(i)
    true
}.getOrDefault(false)

/** ไฟล์ใหม่สุดที่แอปเคยบันทึกไว้ (ใช้ตั้งภาพย่อตอนเปิดแอป) */
fun latestMediaUri(context: Context): Uri? = queryMedia(context).firstOrNull()?.uri

/** [startUri] = ไฟล์ที่ต้องการให้เปิดขึ้นมาก่อน  [onClose] = ส่งไฟล์ใหม่สุดกลับไปอัปเดตภาพย่อ (null ถ้าไม่เหลือไฟล์) */
@Composable
fun MediaViewer(startUri: Uri?, onClose: (Uri?) -> Unit) {
    val context = LocalContext.current
    var items by remember { mutableStateOf<List<MediaEntry>?>(null) }
    var reload by remember { mutableIntStateOf(0) }
    var confirmDelete by remember { mutableStateOf(false) }
    var infoText by remember { mutableStateOf<String?>(null) }
    var favTick by remember { mutableIntStateOf(0) }
    var rotTick by remember { mutableIntStateOf(0) }

    LaunchedEffect(reload) { items = withContext(Dispatchers.IO) { queryMedia(context) } }
    BackHandler { onClose(items?.firstOrNull()?.uri) }

    val deleteLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { res ->
        if (res.resultCode == Activity.RESULT_OK) reload++
    }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        val list = items
        if (list == null) {
            CircularProgressIndicator(color = ViewerYellow, modifier = Modifier.align(Alignment.Center))
        } else if (list.isEmpty()) {
            Text(
                "ยังไม่มีภาพหรือวิดีโอ",
                color = Color.White,
                fontSize = 16.sp,
                modifier = Modifier.align(Alignment.Center)
            )
        } else {
            val pagerState = rememberPagerState(
                initialPage = list.indexOfFirst { it.uri == startUri }.coerceAtLeast(0)
            ) { list.size }
            HorizontalPager(
                state = pagerState,
                modifier = Modifier.fillMaxSize(),
                key = { list.getOrNull(it)?.uri?.toString() ?: it.toString() }
            ) { page ->
                val item = list[page]
                if (item.isVideo) {
                    VideoPage(item.uri, active = pagerState.currentPage == page)
                } else {
                    PhotoPage(item.uri, rotTick)
                }
            }

            val current = list.getOrNull(pagerState.currentPage)
            Row(
                Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .navigationBarsPadding()
                    .padding(horizontal = 20.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    "${pagerState.currentPage + 1} / ${list.size}" + if (current?.isVideo == true) "  วิดีโอ" else "",
                    color = Color.White,
                    fontSize = 14.sp,
                    modifier = Modifier
                        .clip(CircleShape)
                        .background(Color.Black.copy(alpha = 0.5f))
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                )
                Box(Modifier.weight(1f))
                if (current != null) {
                    val fav = remember(current.uri, favTick) { isFavorite(context, current.uri) }
                    ViewerButton(Icons.Rounded.Share, Color.White, "แชร์") { shareMedia(context, current) }
                    ViewerButton(Icons.Rounded.Info, Color.White, "ข้อมูล") {
                        infoText = describeMedia(context, current.uri, current.isVideo, current.name)
                    }
                    ViewerButton(
                        if (fav) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder,
                        if (fav) Color(0xFFFF453A) else Color.White,
                        "ชอบ"
                    ) {
                        if (setFavorite(context, current.uri, !fav)) favTick++
                        else Toast.makeText(context, "ตั้งรายการโปรดไม่ได้ (ต้อง Android 11 ขึ้นไป)", Toast.LENGTH_SHORT).show()
                    }
                    if (!current.isVideo) {
                        ViewerButton(Icons.Rounded.RotateRight, Color.White, "หมุน") {
                            if (rotateJpeg90(context, current.uri)) rotTick++
                            else Toast.makeText(context, "หมุนภาพไม่สำเร็จ", Toast.LENGTH_SHORT).show()
                        }
                    }
                }
                if (current != null) {
                    Box(
                        Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(Color.Black.copy(alpha = 0.5f))
                            .clickable { confirmDelete = true },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Rounded.Delete, contentDescription = "ลบ", tint = Color(0xFFFF453A))
                    }
                }
            }

            if (confirmDelete && current != null) {
                AlertDialog(
                    onDismissRequest = { confirmDelete = false },
                    title = { Text("ลบไฟล์นี้?") },
                    text = { Text(current.name) },
                    confirmButton = {
                        TextButton(onClick = {
                            confirmDelete = false
                            try {
                                val n = context.contentResolver.delete(current.uri, null, null)
                                if (n > 0) reload++ else Toast.makeText(context, "ลบไม่สำเร็จ", Toast.LENGTH_SHORT).show()
                            } catch (e: SecurityException) {
                                try {
                                    val sender = if (e is RecoverableSecurityException) {
                                        e.userAction.actionIntent.intentSender
                                    } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                                        MediaStore.createDeleteRequest(context.contentResolver, listOf(current.uri)).intentSender
                                    } else {
                                        null
                                    }
                                    if (sender != null) {
                                        deleteLauncher.launch(IntentSenderRequest.Builder(sender).build())
                                    } else {
                                        Toast.makeText(context, "ลบไม่สำเร็จ", Toast.LENGTH_SHORT).show()
                                    }
                                } catch (t: Exception) {
                                    Toast.makeText(context, "ลบไม่สำเร็จ", Toast.LENGTH_SHORT).show()
                                }
                            }
                        }) { Text("ลบ", color = Color(0xFFFF453A)) }
                    },
                    dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("ยกเลิก") } }
                )
            }
        }

        infoText?.let { msg ->
            AlertDialog(
                onDismissRequest = { infoText = null },
                confirmButton = { TextButton(onClick = { infoText = null }) { Text("ปิด") } },
                title = { Text("ข้อมูลไฟล์") },
                text = { Column(Modifier.verticalScroll(rememberScrollState())) { Text(msg, fontSize = 13.sp) } }
            )
        }

        Box(
            Modifier
                .align(Alignment.TopStart)
                .statusBarsPadding()
                .padding(16.dp)
                .size(44.dp)
                .clip(CircleShape)
                .background(Color.Black.copy(alpha = 0.5f))
                .clickable { onClose(items?.firstOrNull()?.uri) },
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Rounded.Close, contentDescription = "ปิด", tint = Color.White)
        }
    }
}

@Composable
private fun PhotoPage(uri: Uri, version: Int = 0) {
    val context = LocalContext.current
    var bmp by remember(uri, version) { mutableStateOf<Bitmap?>(null) }
    LaunchedEffect(uri, version) { bmp = withContext(Dispatchers.IO) { decodeForViewing(context, uri) } }
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        val b = bmp
        if (b == null) {
            CircularProgressIndicator(color = ViewerYellow)
        } else if (b.width > b.height * 2.2f) {
            // ภาพพาโนรามา: เต็มความสูงจอ เลื่อนดูตามแนวนอน
            Row(Modifier.fillMaxSize().horizontalScroll(rememberScrollState())) {
                Image(
                    bitmap = b.asImageBitmap(),
                    contentDescription = null,
                    contentScale = ContentScale.FillHeight,
                    modifier = Modifier.fillMaxHeight().aspectRatio(b.width.toFloat() / b.height)
                )
            }
        } else {
            Image(
                bitmap = b.asImageBitmap(),
                contentDescription = null,
                contentScale = ContentScale.Fit,
                modifier = Modifier.fillMaxSize()
            )
        }
    }
}

@Composable
private fun VideoPage(uri: Uri, active: Boolean) {
    var view by remember { mutableStateOf<VideoView?>(null) }
    var playing by remember { mutableStateOf(false) }
    var progress by remember { mutableFloatStateOf(0f) }

    // หยุดเล่นเมื่อเลื่อนไปหน้าอื่น
    LaunchedEffect(active) {
        if (!active) {
            view?.pause()
            playing = false
        }
    }
    // อัปเดตแถบเวลาขณะเล่น
    LaunchedEffect(playing, view) {
        while (playing) {
            val v = view
            if (v != null && v.duration > 0) progress = v.currentPosition.toFloat() / v.duration
            delay(200)
        }
    }
    DisposableEffect(Unit) { onDispose { view?.stopPlayback() } }

    Box(Modifier.fillMaxSize().background(Color.Black), contentAlignment = Alignment.Center) {
        AndroidView(
            factory = { ctx ->
                VideoView(ctx).apply {
                    setVideoURI(uri)
                    setOnPreparedListener { seekTo(1) } // ให้เห็นเฟรมแรกก่อนกดเล่น
                    setOnCompletionListener {
                        playing = false
                        progress = 0f
                        seekTo(1)
                    }
                    view = this
                }
            },
            modifier = Modifier.fillMaxSize()
        )
        Box(
            Modifier
                .fillMaxSize()
                .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {
                    val v = view ?: return@clickable
                    if (v.isPlaying) {
                        v.pause()
                        playing = false
                    } else {
                        v.start()
                        playing = true
                    }
                },
            contentAlignment = Alignment.Center
        ) {
            if (!playing) {
                Box(
                    Modifier.size(76.dp).clip(CircleShape).background(Color.Black.copy(alpha = 0.55f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Rounded.PlayArrow, contentDescription = "เล่น", tint = Color.White, modifier = Modifier.size(44.dp))
                }
            }
        }
        Column(
            Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(start = 24.dp, end = 24.dp, bottom = 72.dp)
        ) {
            Slider(
                value = progress,
                onValueChange = {
                    progress = it
                    val v = view
                    if (v != null && v.duration > 0) v.seekTo((it * v.duration).toInt())
                },
                colors = SliderDefaults.colors(
                    thumbColor = ViewerYellow,
                    activeTrackColor = ViewerYellow,
                    inactiveTrackColor = Color.White.copy(alpha = 0.3f)
                )
            )
        }
    }
}


// ---------------------------------------------------------------------
//  ปุ่มและตัวช่วยของหน้าดูภาพ: แชร์ / ข้อมูลไฟล์ / รายการโปรด / หมุนภาพ
// ---------------------------------------------------------------------
@Composable
private fun ViewerButton(icon: ImageVector, tint: Color, desc: String, onClick: () -> Unit) {
    Box(
        Modifier
            .padding(start = 6.dp)
            .size(40.dp)
            .clip(CircleShape)
            .background(Color.Black.copy(alpha = 0.5f))
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Icon(icon, contentDescription = desc, tint = tint, modifier = Modifier.size(22.dp))
    }
}

private fun shareMedia(context: Context, item: MediaEntry) {
    runCatching {
        val i = Intent(Intent.ACTION_SEND).apply {
            type = if (item.isVideo) "video/mp4" else "image/jpeg"
            putExtra(Intent.EXTRA_STREAM, item.uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(i, "แชร์").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }
}

private fun isFavorite(context: Context, uri: Uri): Boolean {
    if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) return false
    return runCatching {
        context.contentResolver.query(uri, arrayOf(MediaStore.MediaColumns.IS_FAVORITE), null, null, null)?.use { c ->
            c.moveToFirst() && c.getInt(0) == 1
        } ?: false
    }.getOrDefault(false)
}

private fun setFavorite(context: Context, uri: Uri, fav: Boolean): Boolean {
    if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) return false
    return runCatching {
        val v = ContentValues().apply { put(MediaStore.MediaColumns.IS_FAVORITE, if (fav) 1 else 0) }
        context.contentResolver.update(uri, v, null, null) > 0
    }.getOrDefault(false)
}

// หมุนภาพ 90 องศาโดยแก้แค่แท็กทิศทางใน EXIF (ไม่เข้ารหัสภาพใหม่ จึงไม่เสียคุณภาพ)
private fun rotateJpeg90(context: Context, uri: Uri): Boolean = runCatching {
    context.contentResolver.openFileDescriptor(uri, "rw")?.use { pfd ->
        val e = ExifInterface(pfd.fileDescriptor)
        val cur = e.getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
        val next = when (cur) {
            ExifInterface.ORIENTATION_ROTATE_90 -> ExifInterface.ORIENTATION_ROTATE_180
            ExifInterface.ORIENTATION_ROTATE_180 -> ExifInterface.ORIENTATION_ROTATE_270
            ExifInterface.ORIENTATION_ROTATE_270 -> ExifInterface.ORIENTATION_NORMAL
            else -> ExifInterface.ORIENTATION_ROTATE_90
        }
        e.setAttribute(ExifInterface.TAG_ORIENTATION, next.toString())
        e.saveAttributes()
        true
    } ?: false
}.getOrDefault(false)

private fun describeMedia(context: Context, uri: Uri, isVideo: Boolean, name: String): String {
    val sb = StringBuilder(name).append('\n')
    runCatching {
        context.contentResolver.query(uri, arrayOf(MediaStore.MediaColumns.SIZE), null, null, null)?.use { c ->
            if (c.moveToFirst()) sb.append("ขนาดไฟล์: %.1f MB\n".format(c.getLong(0) / 1048576.0))
        }
    }
    if (isVideo) {
        runCatching {
            val r = android.media.MediaMetadataRetriever()
            r.setDataSource(context, uri)
            val w = r.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)
            val h = r.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)
            val d = r.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            r.release()
            sb.append("ขนาดภาพ: ${w}x$h\n")
            sb.append("ความยาว: %.1f วินาที\n".format(d / 1000.0))
        }
    } else {
        runCatching {
            context.contentResolver.openInputStream(uri)?.use { s ->
                val e = ExifInterface(s)
                val w = e.getAttribute("ImageWidth")
                val h = e.getAttribute("ImageLength")
                if (w != null && h != null) sb.append("ขนาดภาพ: ${w}x$h\n")
                e.getAttribute("DateTimeOriginal")?.let { sb.append("วันเวลาที่ถ่าย: $it\n") }
                val mk = listOfNotNull(e.getAttribute("Make"), e.getAttribute("Model")).joinToString(" ")
                if (mk.isNotBlank()) sb.append("กล้อง: $mk\n")
                e.getAttribute("LensModel")?.let { sb.append("เลนส์: $it\n") }
                e.getAttribute("PhotographicSensitivity")?.let { sb.append("ISO: $it\n") }
                val et = e.getAttributeDouble("ExposureTime", 0.0)
                if (et > 0.0) sb.append("ชัตเตอร์: " + (if (et >= 0.5) "%.1f วิ".format(et) else "1/${(1.0 / et).roundToInt()}") + "\n")
                e.getAttribute("FNumber")?.let { sb.append("รูรับแสง: f/$it\n") }
                e.getAttribute("FocalLength")?.let { sb.append("ทางยาวโฟกัส: $it mm\n") }
                val ll = e.latLong
                if (ll != null) sb.append("GPS: %.5f, %.5f\n".format(ll[0], ll[1]))
            }
        }
    }
    return sb.toString().trim()
}
