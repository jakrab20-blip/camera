package com.example.procamera

import android.graphics.Bitmap
import android.os.SystemClock
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import kotlin.math.abs
import kotlin.math.roundToInt
import kotlin.math.sqrt

// =====================================================================
//  เครื่องมือช่วยถ่ายแบบมืออาชีพ: ฮิสโตแกรมสด / โฟกัสพีคกิ้ง (ขอบที่คมเป็นสีเขียว) / ซีบรา (ส่วนที่สว่างไหม้เป็นลายเส้นแดง)
//  ทำงานผ่าน CameraX ImageAnalysis (อ่านเฉพาะช่องความสว่าง Y) ประมวลผลไม่เกิน ~10 ครั้ง/วินาที
//  ผลที่วาดทับพรีวิวเป็นบิตแมปเล็ก (กว้าง 240 พิกเซล) ยืดให้เต็มพรีวิว จึงเป็นการประมาณ ไม่ใช่ความละเอียดเต็ม
// =====================================================================

data class AnalysisConfig(
    val histogram: Boolean = false,
    val peaking: Boolean = false,
    val zebra: Boolean = false,
    // กล้องหน้า: พรีวิวถูกกลับด้านซ้าย-ขวา แต่เฟรมวิเคราะห์ไม่กลับ ต้องกลับเองให้ตรงกัน
    val mirror: Boolean = false
)

class AnalysisFrame(val histogram: IntArray, val overlay: Bitmap?)

/**
 * แปลงพิกัดในภาพ "แนวตั้งตรง" (u,v) กลับเป็นพิกัดในเฟรมดิบของเซนเซอร์ (ที่ถูกครอปแล้ว ขนาด cw x ch)
 * rot = imageInfo.rotationDegrees ของเฟรม (0/90/180/270) ผลใส่ใน out[0]=x, out[1]=y
 */
fun mapUpright(rot: Int, u: Float, v: Float, cw: Int, ch: Int, out: FloatArray) {
    when (rot) {
        90 -> { out[0] = v; out[1] = ch - u }
        180 -> { out[0] = cw - u; out[1] = ch - v }
        270 -> { out[0] = cw - v; out[1] = u }
        else -> { out[0] = u; out[1] = v }
    }
}

class LumaAnalyzer(private val onFrame: (AnalysisFrame) -> Unit) : ImageAnalysis.Analyzer {
    @Volatile
    var config = AnalysisConfig()
    private var lastMs = 0L

    override fun analyze(image: ImageProxy) {
        try {
            val now = SystemClock.elapsedRealtime()
            if (now - lastMs < 90) return
            lastMs = now
            val cfg = config
            if (!cfg.histogram && !cfg.peaking && !cfg.zebra) return

            val plane = image.planes[0]
            val buf = plane.buffer
            val rowStride = plane.rowStride
            val pixStride = plane.pixelStride
            val limit = buf.limit()
            val crop = image.cropRect
            val cw = crop.width()
            val ch = crop.height()
            if (cw < 8 || ch < 8) return
            val rot = image.imageInfo.rotationDegrees
            val uw = if (rot % 180 == 0) cw else ch
            val uh = if (rot % 180 == 0) ch else cw

            val gw = 240
            val gh = (gw.toFloat() * uh / uw).roundToInt().coerceAtLeast(8)
            val luma = IntArray(gw * gh)
            val p = FloatArray(2)
            for (gy in 0 until gh) {
                val v = (gy + 0.5f) * uh / gh
                for (gx in 0 until gw) {
                    var u = (gx + 0.5f) * uw / gw
                    if (cfg.mirror) u = uw - u
                    mapUpright(rot, u, v, cw, ch, p)
                    val sx = p[0].toInt().coerceIn(0, cw - 1)
                    val sy = p[1].toInt().coerceIn(0, ch - 1)
                    val idx = ((crop.top + sy) * rowStride + (crop.left + sx) * pixStride).coerceIn(0, limit - 1)
                    luma[gy * gw + gx] = buf.get(idx).toInt() and 0xFF
                }
            }

            val bins = IntArray(64)
            for (l in luma) bins[l shr 2]++

            var overlay: Bitmap? = null
            if (cfg.peaking || cfg.zebra) {
                val px = IntArray(gw * gh)
                for (y in 0 until gh) {
                    for (x in 0 until gw) {
                        val i = y * gw + x
                        val l = luma[i]
                        if (cfg.zebra && l >= 240 && ((x + y) / 3) % 2 == 0) {
                            px[i] = 0xB3FF453A.toInt()
                        } else if (cfg.peaking && x in 1 until gw - 1 && y in 1 until gh - 1) {
                            val g = abs(luma[i + 1] - luma[i - 1]) + abs(luma[i + gw] - luma[i - gw])
                            if (g > 44) px[i] = 0xFF30D158.toInt()
                        }
                    }
                }
                overlay = Bitmap.createBitmap(gw, gh, Bitmap.Config.ARGB_8888)
                overlay.setPixels(px, 0, gw, 0, 0, gw, gh)
            }
            onFrame(AnalysisFrame(bins, overlay))
        } catch (t: Throwable) {
            // ข้ามเฟรมที่พลาด ไม่ให้ทำให้แอปพัง
        } finally {
            image.close()
        }
    }
}

@Composable
fun HistogramView(bins: IntArray, modifier: Modifier = Modifier) {
    Canvas(
        modifier
            .size(96.dp, 44.dp)
            .clip(RoundedCornerShape(6.dp))
            .background(Color.Black.copy(alpha = 0.45f))
    ) {
        val max = (bins.maxOrNull() ?: 1).coerceAtLeast(1)
        val bw = size.width / bins.size
        for (i in bins.indices) {
            // ใช้รากที่สองให้เห็นส่วนที่มีน้อยแต่สำคัญ (เช่น ไฮไลต์)
            val h = size.height * sqrt(bins[i].toFloat() / max)
            drawRect(Color.White.copy(alpha = 0.85f), Offset(i * bw, size.height - h), Size(bw, h))
        }
    }
}
