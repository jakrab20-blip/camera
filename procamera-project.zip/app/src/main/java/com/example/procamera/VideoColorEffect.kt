package com.example.procamera

import android.opengl.EGL14
import android.opengl.EGLConfig
import android.opengl.EGLContext
import android.opengl.EGLDisplay
import android.opengl.EGLSurface
import android.opengl.GLES11Ext
import android.opengl.GLES20
import android.graphics.SurfaceTexture
import android.os.Handler
import android.os.HandlerThread
import android.util.Log
import android.view.Surface
import androidx.camera.core.CameraEffect
import androidx.camera.core.SurfaceOutput
import androidx.camera.core.SurfaceProcessor
import androidx.camera.core.SurfaceRequest
import java.util.concurrent.Executor

// =====================================================================
//  ขั้นที่ 6: ใส่ "สไตล์ภาพ" ลงในไฟล์วิดีโอที่บันทึกจริงด้วย (ก่อนหน้านี้สไตล์มีผลแค่พรีวิวสด
//  กับไฟล์ภาพนิ่งเท่านั้น ไฟล์วิดีโอไม่มีฟิลเตอร์ติดไปเลย)
//  ทำโดยแทรก CameraEffect เข้าไปที่ VIDEO_CAPTURE ผ่าน SurfaceProcessor ของ CameraX ซึ่งใช้ OpenGL ES
//  วาดแต่ละเฟรมจากกล้องใหม่ลง Surface ที่ตัวเข้ารหัสวิดีโอ (Recorder) รออยู่ พร้อมทาสีตามเมทริกซ์สีของ
//  สไตล์ที่เลือกไว้ตอนเริ่มอัด (เลือกสไตล์กลางอัดจะไม่เปลี่ยนสีของคลิปที่อัดไปแล้ว ต้องเริ่มอัดใหม่)
//
//  หมายเหตุความซื่อสัตย์: นี่คือส่วนที่ซับซ้อนและเสี่ยงบิลด์ไม่ผ่านที่สุดในบรรดาที่แก้รอบนี้ทั้งหมด
//  เพราะเขียนโค้ด EGL/OpenGL ระดับต่ำ ไม่มีเครื่องมือ Android SDK ให้คอมไพล์ทดสอบจริงในสภาพแวดล้อมนี้
//  ถ้า build ผ่าน GitHub Actions ไม่สำเร็จ ให้คัดลอก error จากแท็บ Actions ส่งมาดูได้เลย จุดที่มีโอกาส
//  ผิดสูงสุดคือการตั้งค่า EGL config (ต้องมีแฟล็ก "recordable" ให้ใช้กับ Surface ของตัวเข้ารหัสวิดีโอได้)
//  และการรวม transform matrix ของเฟรมขาเข้ากับขาออก
// =====================================================================

private const val TAG = "VideoColorEffect"
private const val EGL_RECORDABLE_ANDROID = 0x3142

/** สร้าง [CameraEffect] ที่ทาสีทับเฉพาะสตรีมวิดีโอที่บันทึกลงไฟล์ (ไม่ยุ่งกับพรีวิวสด ซึ่งมีการทาสีทับ
 * ด้วย Compose colorFilter อยู่แล้วแยกต่างหาก) ด้วยเมทริกซ์สีของ [style] ที่เลือกไว้ ณ ตอนเริ่มอัด
 */
fun createVideoStyleEffect(style: PhotoStyle): CameraEffect? {
    if (style == PhotoStyle.STANDARD) return null // มาตรฐาน ไม่ต้องแทรกอะไรเลย ประหยัดทรัพยากร
    return try {
        val glThread = HandlerThread("ColorMatrixGL").apply { start() }
        val glHandler = Handler(glThread.looper)
        val executor = Executor { command -> glHandler.post(command) }
        val processor = ColorMatrixSurfaceProcessor(style.toGlColorMatrix(), styleColorOffset(style), glHandler, executor)
        CameraEffect.Builder(CameraEffect.VIDEO_CAPTURE)
            .setSurfaceProcessor(executor, processor)
            .build()
    } catch (e: Exception) {
        Log.e(TAG, "สร้าง video effect ไม่สำเร็จ จะอัดวิดีโอแบบไม่มีฟิลเตอร์แทน: ${e.message}")
        null
    }
}

// แปลงเมทริกซ์สีของ android.graphics.ColorMatrix (4x5, ต่อพิกเซล 0-255) เป็นเมทริกซ์ 4x4 + offset
// สำหรับใช้ในตัว fragment shader ของ OpenGL (สี 0.0-1.0) โครงสร้างของ android.graphics.ColorMatrix
// คือแถวละ 5 ค่า (คูณ R,G,B,A แล้วบวกค่าคงที่) เรียงตามแถว R,G,B,A
private fun PhotoStyle.toGlColorMatrix(): FloatArray {
    // เรียกเมทริกซ์เดียวกับที่ใช้ในพรีวิว/ภาพนิ่ง (CameraScreen.kt) เพื่อให้สีตรงกันทุกที่
    val m = styleColorMatrixArray(this)
    // android.graphics.ColorMatrix เก็บเป็น array 20 ค่าแบบ "แถว" (row-major: แถว R,G,B,A แต่ละแถวมี 5
    // ค่า คือสัมประสิทธิ์ R,G,B,A,offset) แต่ GLES20.glUniformMatrix4fv (transpose ต้องเป็น false เสมอ
    // ตามสเปกของ GLES2) ต้องการข้อมูลแบบ "คอลัมน์" (column-major) จึงต้องสลับตำแหน่งตรงนี้ ไม่ใช่แค่
    // ก็อปมาเรียงแถวเฉยๆ ไม่งั้นเมทริกซ์สีจะเพี้ยนเป็นค่าที่สลับตำแหน่งกันผิด
    return floatArrayOf(
        m[0], m[5], m[10], m[15],   // คอลัมน์ 0: สัมประสิทธิ์ R ของแต่ละเอาต์พุต R,G,B,A
        m[1], m[6], m[11], m[16],   // คอลัมน์ 1: สัมประสิทธิ์ G
        m[2], m[7], m[12], m[17],   // คอลัมน์ 2: สัมประสิทธิ์ B
        m[3], m[8], m[13], m[18]    // คอลัมน์ 3: สัมประสิทธิ์ A
    )
}

private fun styleColorOffset(style: PhotoStyle): FloatArray {
    val m = styleColorMatrixArray(style)
    return floatArrayOf(m[4] / 255f, m[9] / 255f, m[14] / 255f, m[19] / 255f)
}

/** GL renderer เดียวกัน ทำหน้าที่รับเฟรมจากกล้อง (external OES texture) วาดใหม่ลง Surface ของตัวเข้ารหัส
 * วิดีโอ พร้อมทาสีตามเมทริกซ์ที่กำหนด ทำงานบน thread เดียวตลอดอายุของมันเพื่อความปลอดภัยของ EGL context
 */
private class ColorMatrixSurfaceProcessor(
    private val colorMatrix: FloatArray,
    private val colorOffset: FloatArray,
    private val glHandler: Handler,
    private val glExecutor: Executor
) : SurfaceProcessor {

    private var eglDisplay: EGLDisplay = EGL14.EGL_NO_DISPLAY
    private var eglContext: EGLContext = EGL14.EGL_NO_CONTEXT
    private var eglConfig: EGLConfig? = null
    private var program = 0
    private var textureId = 0
    private var surfaceTexture: SurfaceTexture? = null
    private var inputSurface: Surface? = null
    private val outputs = mutableListOf<OutputTarget>()
    private val transform = FloatArray(16)
    private var initialized = false

    private data class OutputTarget(val surfaceOutput: SurfaceOutput, var eglSurface: EGLSurface)

    override fun onInputSurface(request: SurfaceRequest) {
        glExecutor.execute {
            runCatching {
                ensureEgl()
                val size = request.resolution
                val tex = createOesTexture()
                textureId = tex
                val st = SurfaceTexture(tex)
                st.setDefaultBufferSize(size.width, size.height)
                val surface = Surface(st)
                surfaceTexture = st
                inputSurface = surface
                st.setOnFrameAvailableListener({ drawFrame() }, glHandler)
                request.provideSurface(surface, glExecutor) {
                    // เมื่อระบบไม่ใช้ Surface นี้แล้ว (เปลี่ยนโหมด/ปิดกล้อง) ให้คืนทรัพยากรทั้งหมด
                    glExecutor.execute {
                        st.release()
                        surface.release()
                        if (textureId != 0) {
                            GLES20.glDeleteTextures(1, intArrayOf(textureId), 0)
                            textureId = 0
                        }
                    }
                }
            }.onFailure { Log.e(TAG, "onInputSurface ล้มเหลว: ${it.message}") }
        }
    }

    override fun onOutputSurface(surfaceOutput: SurfaceOutput) {
        glExecutor.execute {
            runCatching {
                ensureEgl()
                val surface = surfaceOutput.getSurface(glExecutor) { event ->
                    glExecutor.execute {
                        outputs.removeAll { it.surfaceOutput === surfaceOutput }
                        surfaceOutput.close()
                    }
                }
                val eglSurface = createWindowSurface(surface)
                outputs.add(OutputTarget(surfaceOutput, eglSurface))
            }.onFailure { Log.e(TAG, "onOutputSurface ล้มเหลว: ${it.message}") }
        }
    }

    private fun drawFrame() {
        glExecutor.execute {
            runCatching {
                val st = surfaceTexture ?: return@runCatching
                // ต้องมี context ปัจจุบันก่อนเรียก updateTexImage เสมอ ใช้เอาต์พุตตัวแรกเป็นตัวยึด context ชั่วคราว
                val anchor = outputs.firstOrNull() ?: return@runCatching
                EGL14.eglMakeCurrent(eglDisplay, anchor.eglSurface, anchor.eglSurface, eglContext)
                st.updateTexImage()
                st.getTransformMatrix(transform)
                for (out in outputs) {
                    val combined = FloatArray(16)
                    // รวม transform ของเฟรมขาเข้ากับที่เอาต์พุตต้องการ (ครอป/หมุนตามที่ CameraX คำนวณไว้)
                    out.surfaceOutput.updateTransformMatrix(combined, transform)
                    EGL14.eglMakeCurrent(eglDisplay, out.eglSurface, out.eglSurface, eglContext)
                    val size = out.surfaceOutput.size
                    GLES20.glViewport(0, 0, size.width, size.height)
                    drawTexture(combined)
                    EGL14.eglSwapBuffers(eglDisplay, out.eglSurface)
                }
            }.onFailure { Log.e(TAG, "drawFrame ล้มเหลว: ${it.message}") }
        }
    }

    private fun ensureEgl() {
        if (initialized) return
        eglDisplay = EGL14.eglGetDisplay(EGL14.EGL_DEFAULT_DISPLAY)
        val version = IntArray(2)
        EGL14.eglInitialize(eglDisplay, version, 0, version, 1)
        val attribs = intArrayOf(
            EGL14.EGL_RENDERABLE_TYPE, EGL14.EGL_OPENGL_ES2_BIT,
            EGL14.EGL_RED_SIZE, 8,
            EGL14.EGL_GREEN_SIZE, 8,
            EGL14.EGL_BLUE_SIZE, 8,
            EGL14.EGL_ALPHA_SIZE, 8,
            EGL_RECORDABLE_ANDROID, 1,
            EGL14.EGL_NONE
        )
        val configs = arrayOfNulls<EGLConfig>(1)
        val numConfigs = IntArray(1)
        EGL14.eglChooseConfig(eglDisplay, attribs, 0, configs, 0, 1, numConfigs, 0)
        eglConfig = configs[0]
        val ctxAttribs = intArrayOf(EGL14.EGL_CONTEXT_CLIENT_VERSION, 2, EGL14.EGL_NONE)
        eglContext = EGL14.eglCreateContext(eglDisplay, eglConfig, EGL14.EGL_NO_CONTEXT, ctxAttribs, 0)
        program = buildProgram()
        initialized = true
    }

    private fun createWindowSurface(surface: Surface): EGLSurface {
        val attribs = intArrayOf(EGL14.EGL_NONE)
        return EGL14.eglCreateWindowSurface(eglDisplay, eglConfig, surface, attribs, 0)
    }

    private fun createOesTexture(): Int {
        val ids = IntArray(1)
        GLES20.glGenTextures(1, ids, 0)
        GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, ids[0])
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE)
        return ids[0]
    }

    private val quadCoords = floatArrayOf(-1f, -1f, 1f, -1f, -1f, 1f, 1f, 1f)

    private fun drawTexture(texTransform: FloatArray) {
        GLES20.glUseProgram(program)
        GLES20.glClearColor(0f, 0f, 0f, 1f)
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT)

        val posBuf = java.nio.ByteBuffer.allocateDirect(quadCoords.size * 4)
            .order(java.nio.ByteOrder.nativeOrder()).asFloatBuffer().apply { put(quadCoords); position(0) }
        val posLoc = GLES20.glGetAttribLocation(program, "aPosition")
        GLES20.glEnableVertexAttribArray(posLoc)
        GLES20.glVertexAttribPointer(posLoc, 2, GLES20.GL_FLOAT, false, 0, posBuf)

        val matLoc = GLES20.glGetUniformLocation(program, "uTexMatrix")
        GLES20.glUniformMatrix4fv(matLoc, 1, false, texTransform, 0)

        val colorMatLoc = GLES20.glGetUniformLocation(program, "uColorMat")
        GLES20.glUniformMatrix4fv(colorMatLoc, 1, false, colorMatrix, 0)
        val colorOffLoc = GLES20.glGetUniformLocation(program, "uColorOffset")
        GLES20.glUniform4fv(colorOffLoc, 1, colorOffset, 0)

        GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
        GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, textureId)
        val texLoc = GLES20.glGetUniformLocation(program, "sTexture")
        GLES20.glUniform1i(texLoc, 0)

        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
        GLES20.glDisableVertexAttribArray(posLoc)
    }

    private fun buildProgram(): Int {
        val vertexSrc = """
            attribute vec4 aPosition;
            uniform mat4 uTexMatrix;
            varying vec2 vTexCoord;
            void main() {
                gl_Position = aPosition;
                vec4 uv = vec4((aPosition.x + 1.0) * 0.5, (aPosition.y + 1.0) * 0.5, 0.0, 1.0);
                vTexCoord = (uTexMatrix * uv).xy;
            }
        """.trimIndent()
        val fragmentSrc = """
            #extension GL_OES_EGL_image_external : require
            precision mediump float;
            varying vec2 vTexCoord;
            uniform samplerExternalOES sTexture;
            uniform mat4 uColorMat;
            uniform vec4 uColorOffset;
            void main() {
                vec4 c = texture2D(sTexture, vTexCoord);
                vec4 graded = uColorMat * vec4(c.rgb, 1.0) + uColorOffset;
                gl_FragColor = vec4(clamp(graded.rgb, 0.0, 1.0), c.a);
            }
        """.trimIndent()
        val vs = compileShader(GLES20.GL_VERTEX_SHADER, vertexSrc)
        val fs = compileShader(GLES20.GL_FRAGMENT_SHADER, fragmentSrc)
        val prog = GLES20.glCreateProgram()
        GLES20.glAttachShader(prog, vs)
        GLES20.glAttachShader(prog, fs)
        GLES20.glLinkProgram(prog)
        return prog
    }

    private fun compileShader(type: Int, src: String): Int {
        val shader = GLES20.glCreateShader(type)
        GLES20.glShaderSource(shader, src)
        GLES20.glCompileShader(shader)
        return shader
    }
}

// เมทริกซ์สีของแต่ละสไตล์ (ค่าเดียวกับ toColorMatrix() ใน CameraScreen.kt คัดลอกมาเป็น array ดิบ
// เพื่อไม่ต้องพึ่ง android.graphics.ColorMatrix ฝั่งนี้ ให้ทั้งพรีวิว/ภาพนิ่ง/วิดีโอ ใช้ตัวเลขชุดเดียวกัน)
private fun styleColorMatrixArray(style: PhotoStyle): FloatArray {
    val cm = android.graphics.ColorMatrix()
    when (style) {
        PhotoStyle.STANDARD -> {}
        PhotoStyle.VIVID -> cm.setSaturation(1.45f)
        PhotoStyle.MONO -> cm.setSaturation(0f)
        PhotoStyle.WARM -> {
            cm.setSaturation(1.1f)
            cm.postConcat(
                android.graphics.ColorMatrix(
                    floatArrayOf(
                        1.08f, 0f, 0f, 0f, 8f,
                        0f, 1.02f, 0f, 0f, 2f,
                        0f, 0f, 0.90f, 0f, -6f,
                        0f, 0f, 0f, 1f, 0f
                    )
                )
            )
        }
        PhotoStyle.COOL -> {
            cm.setSaturation(1.1f)
            cm.postConcat(
                android.graphics.ColorMatrix(
                    floatArrayOf(
                        0.94f, 0f, 0f, 0f, -4f,
                        0f, 1.0f, 0f, 0f, 0f,
                        0f, 0f, 1.10f, 0f, 10f,
                        0f, 0f, 0f, 1f, 0f
                    )
                )
            )
        }
        PhotoStyle.FILM -> {
            cm.setSaturation(0.88f)
            cm.postConcat(
                android.graphics.ColorMatrix(
                    floatArrayOf(
                        0.92f, 0.04f, 0.02f, 0f, 12f,
                        0.02f, 0.90f, 0.03f, 0f, 9f,
                        0.02f, 0.05f, 0.85f, 0f, 14f,
                        0f, 0f, 0f, 1f, 0f
                    )
                )
            )
        }
    }
    val out = FloatArray(20)
    cm.getValues(out)
    return out
}
