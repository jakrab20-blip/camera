package com.example.procamera

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlin.math.abs
import kotlin.math.atan2

// เส้นตารางกฎสามส่วน
@Composable
fun GridOverlay(modifier: Modifier = Modifier) {
    Canvas(modifier.fillMaxSize()) {
        val color = Color.White.copy(alpha = 0.45f)
        val w = 0.8.dp.toPx()
        for (i in 1..2) {
            val x = size.width * i / 3f
            val y = size.height * i / 3f
            drawLine(color, Offset(x, 0f), Offset(x, size.height), w)
            drawLine(color, Offset(0f, y), Offset(size.width, y), w)
        }
    }
}

// ระดับน้ำ: ใช้เซ็นเซอร์วัดความเอียง โผล่เฉพาะตอนถือโทรศัพท์ตั้งตรง (แนวตั้ง)
// เส้นกลางเอียงตามองศา และเป็นสีเหลืองเมื่อเอียงไม่เกิน ~1 องศา
@Composable
fun LevelOverlay(modifier: Modifier = Modifier) {
    val context = LocalContext.current
    var roll by remember { mutableFloatStateOf(0f) }
    var visible by remember { mutableStateOf(false) }

    DisposableEffect(Unit) {
        val sm = context.getSystemService(Context.SENSOR_SERVICE) as SensorManager
        val sensor = sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        var fx = 0f
        var fy = 0f
        var fz = 0f
        val listener = object : SensorEventListener {
            override fun onSensorChanged(e: SensorEvent) {
                // กรองสัญญาณให้เส้นนิ่ง ไม่สั่น
                val a = 0.15f
                fx += a * (e.values[0] - fx)
                fy += a * (e.values[1] - fy)
                fz += a * (e.values[2] - fz)
                visible = fy > 6f && abs(fz) < 4f
                roll = Math.toDegrees(atan2(fx.toDouble(), fy.toDouble())).toFloat()
            }

            override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
        }
        if (sensor != null) sm.registerListener(listener, sensor, SensorManager.SENSOR_DELAY_UI)
        onDispose { sm.unregisterListener(listener) }
    }

    if (!visible) return

    Canvas(modifier.fillMaxSize()) {
        val cx = size.width / 2f
        val cy = size.height / 2f
        val level = abs(roll) < 1.2f
        val color = if (level) Color(0xFFFFD60A) else Color.White.copy(alpha = 0.85f)
        val half = 60.dp.toPx()
        val stroke = 1.5.dp.toPx()

        // เส้นอ้างอิงคงที่ซ้าย/ขวา
        val ref = Color.White.copy(alpha = 0.6f)
        drawLine(ref, Offset(cx - half - 36.dp.toPx(), cy), Offset(cx - half - 12.dp.toPx(), cy), stroke, StrokeCap.Round)
        drawLine(ref, Offset(cx + half + 12.dp.toPx(), cy), Offset(cx + half + 36.dp.toPx(), cy), stroke, StrokeCap.Round)

        // เส้นที่เอียงตามโทรศัพท์
        rotate(degrees = roll, pivot = Offset(cx, cy)) {
            drawLine(color, Offset(cx - half, cy), Offset(cx + half, cy), stroke, StrokeCap.Round)
        }
    }
}
