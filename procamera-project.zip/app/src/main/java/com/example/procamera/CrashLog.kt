package com.example.procamera

import android.content.Context
import android.util.Log
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// =====================================================================
//  บันทึกข้อผิดพลาดลงไฟล์ในเครื่อง (filesDir/procamera.log) เพื่อให้ผู้ใช้เปิดดู/แชร์ให้นักพัฒนาได้
//  - ดักแอปพังที่ไม่ได้จับ (uncaught exception) แล้วเขียนลงไฟล์ก่อนแอปปิด
//  - CrashLog.log(...) ใช้บันทึกข้อผิดพลาดที่จับได้ เช่น ผูกกล้องไม่สำเร็จ ประมวลผลภาพพลาด
//  ไฟล์ไม่เกิน ~200 KB ถ้าใหญ่กว่านี้จะเริ่มเขียนใหม่ (กันกินพื้นที่)
// =====================================================================
object CrashLog {
    private var file: File? = null
    private const val MAX_BYTES = 200_000L

    fun install(context: Context) {
        file = File(context.applicationContext.filesDir, "procamera.log")
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            runCatching { write("แอปพัง (thread ${thread.name})", throwable) }
            previous?.uncaughtException(thread, throwable)
        }
    }

    @Synchronized
    private fun write(msg: String, t: Throwable?) {
        val f = file ?: return
        if (f.length() > MAX_BYTES) f.writeText("")
        val stamp = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())
        val sb = StringBuilder("[").append(stamp).append("] ").append(msg).append('\n')
        if (t != null) sb.append(Log.getStackTraceString(t)).append('\n')
        f.appendText(sb.toString())
    }

    fun log(msg: String, t: Throwable? = null) {
        Log.w("ProCamera", msg, t)
        runCatching { write(msg, t) }
    }

    fun read(): String = runCatching { file?.takeIf { it.exists() }?.readText() ?: "" }.getOrDefault("")

    fun clear() {
        runCatching { file?.writeText("") }
    }
}
