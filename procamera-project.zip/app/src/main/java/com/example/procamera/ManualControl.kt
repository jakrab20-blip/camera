package com.example.procamera

import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraMetadata
import android.hardware.camera2.CaptureRequest
import androidx.camera.camera2.interop.Camera2CameraControl
import androidx.camera.camera2.interop.Camera2CameraInfo
import androidx.camera.camera2.interop.CaptureRequestOptions
import androidx.camera.camera2.interop.ExperimentalCamera2Interop
import androidx.camera.core.Camera
import kotlin.math.max

// ช่วงค่า ISO และความเร็วชัตเตอร์ (นาโนวินาที) ที่กล้องของเครื่องรายงานว่ารองรับ
data class ManualRanges(val iso: IntRange, val shutterNs: LongRange)

// เครื่องรองรับโหมดเก็บรายละเอียด/ลดสัญญาณรบกวนคุณภาพสูงหรือไม่
data class QualityModes(val edgeHq: Boolean, val noiseHq: Boolean)

// ความสามารถเพิ่มเติม: โหมดสมดุลสีขาวที่เครื่องมี + ระยะโฟกัสใกล้สุด (หน่วยไดออปเตอร์ 1/เมตร, 0 = โฟกัสมือไม่ได้)
data class ExtraCaps(val awbModes: Set<Int>, val minFocusDiopter: Float)

@androidx.annotation.OptIn(ExperimentalCamera2Interop::class)
fun readExtraCaps(camera: Camera): ExtraCaps {
    val info = Camera2CameraInfo.from(camera.cameraInfo)
    val awb = info.getCameraCharacteristic(CameraCharacteristics.CONTROL_AWB_AVAILABLE_MODES)?.toSet() ?: emptySet()
    val minFocus = info.getCameraCharacteristic(CameraCharacteristics.LENS_INFO_MINIMUM_FOCUS_DISTANCE) ?: 0f
    return ExtraCaps(awb, minFocus)
}

@androidx.annotation.OptIn(ExperimentalCamera2Interop::class)
fun readManualRanges(camera: Camera): ManualRanges? {
    val info = Camera2CameraInfo.from(camera.cameraInfo)
    val iso = info.getCameraCharacteristic(CameraCharacteristics.SENSOR_INFO_SENSITIVITY_RANGE) ?: return null
    val exp = info.getCameraCharacteristic(CameraCharacteristics.SENSOR_INFO_EXPOSURE_TIME_RANGE) ?: return null
    return ManualRanges(iso.lower..iso.upper, exp.lower..exp.upper)
}

@androidx.annotation.OptIn(ExperimentalCamera2Interop::class)
fun readQualityModes(camera: Camera): QualityModes {
    val info = Camera2CameraInfo.from(camera.cameraInfo)
    val edge = info.getCameraCharacteristic(CameraCharacteristics.EDGE_AVAILABLE_EDGE_MODES)
    val noise = info.getCameraCharacteristic(CameraCharacteristics.NOISE_REDUCTION_AVAILABLE_NOISE_REDUCTION_MODES)
    return QualityModes(
        edgeHq = edge?.contains(CameraMetadata.EDGE_MODE_HIGH_QUALITY) == true,
        noiseHq = noise?.contains(CameraMetadata.NOISE_REDUCTION_MODE_HIGH_QUALITY) == true
    )
}

// รวมตัวเลือกที่ส่งเข้ากล้องผ่าน Camera2:
//  - manualOn: ปิดออโต้เอ็กซ์โพชัวร์ ใช้ ISO/ชัตเตอร์ที่ตั้งเอง
//  - edgeHq / noiseHq: ขอให้ตัวประมวลผลภาพเก็บความคมและลดสัญญาณรบกวนแบบคุณภาพสูง (ใช้ตอนถ่ายภาพ)
//  - stabilizeVideo: ขอกันสั่นตอนอัดวิดีโอ/สโลโมชัน เลือก OIS (ฮาร์ดแวร์เลนส์) ก่อนถ้าเครื่องมี
//    ถ้าไม่มี OIS จะใช้ EIS (ซอฟต์แวร์ครอปภาพกันสั่น) แทน ขอทั้งคู่พร้อมกันได้ถ้าเครื่องรองรับทั้งสอง
//    (นิ่งกว่าใช้อย่างเดียว) — ยังไม่ได้ใช้โหมด "Preview Stabilization" ของ Android 13+ ที่นิ่งกว่านี้
//    อีกขั้น เพราะยังไม่ได้ยืนยัน API ชื่อคงที่ให้แน่ใจ 100% ในสภาพแวดล้อมนี้ (ไม่มีเน็ต/SDK ให้ตรวจ)
// ถ้าไม่มีอะไรต้องตั้ง จะล้างค่ากลับเป็นค่าเริ่มต้น
@androidx.annotation.OptIn(ExperimentalCamera2Interop::class)
fun applyCaptureOptions(
    camera: Camera,
    manualOn: Boolean,
    iso: Int,
    shutterNs: Long,
    edgeHq: Boolean,
    noiseHq: Boolean,
    stabilizeVideo: Boolean = false,
    awbMode: Int? = null,
    focusDiopter: Float? = null
) {
    val control = Camera2CameraControl.from(camera.cameraControl)
    if (!manualOn && !edgeHq && !noiseHq && !stabilizeVideo && awbMode == null && focusDiopter == null) {
        control.clearCaptureRequestOptions()
        return
    }
    val b = CaptureRequestOptions.Builder()
    if (manualOn) {
        b.setCaptureRequestOption(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_OFF)
        b.setCaptureRequestOption(CaptureRequest.SENSOR_SENSITIVITY, iso)
        b.setCaptureRequestOption(CaptureRequest.SENSOR_EXPOSURE_TIME, shutterNs)
        // ชัตเตอร์ช้ากว่า 1/30 วินาที ต้องยืดระยะเวลาต่อเฟรมตาม ไม่งั้นค่าจะไม่มีผล
        b.setCaptureRequestOption(CaptureRequest.SENSOR_FRAME_DURATION, max(shutterNs, 33_333_333L))
    }
    if (edgeHq) {
        b.setCaptureRequestOption(CaptureRequest.EDGE_MODE, CameraMetadata.EDGE_MODE_HIGH_QUALITY)
    }
    if (noiseHq) {
        b.setCaptureRequestOption(
            CaptureRequest.NOISE_REDUCTION_MODE,
            CameraMetadata.NOISE_REDUCTION_MODE_HIGH_QUALITY
        )
    }
    if (awbMode != null) {
        b.setCaptureRequestOption(CaptureRequest.CONTROL_AWB_MODE, awbMode)
    }
    if (focusDiopter != null) {
        b.setCaptureRequestOption(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_OFF)
        b.setCaptureRequestOption(CaptureRequest.LENS_FOCUS_DISTANCE, focusDiopter)
    }
    if (stabilizeVideo) {
        val info = Camera2CameraInfo.from(camera.cameraInfo)
        val ois = info.getCameraCharacteristic(CameraCharacteristics.LENS_INFO_AVAILABLE_OPTICAL_STABILIZATION)
        val eis = info.getCameraCharacteristic(CameraCharacteristics.CONTROL_AVAILABLE_VIDEO_STABILIZATION_MODES)
        val hasOis = ois?.contains(CaptureRequest.LENS_OPTICAL_STABILIZATION_MODE_ON) == true
        val hasEis = eis?.contains(CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE_ON) == true
        if (hasOis) {
            b.setCaptureRequestOption(
                CaptureRequest.LENS_OPTICAL_STABILIZATION_MODE,
                CaptureRequest.LENS_OPTICAL_STABILIZATION_MODE_ON
            )
        }
        if (hasEis) {
            b.setCaptureRequestOption(
                CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE,
                CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE_ON
            )
        }
    }
    control.setCaptureRequestOptions(b.build())
}
