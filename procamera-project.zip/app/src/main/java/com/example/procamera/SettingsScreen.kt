package com.example.procamera

import android.content.Context
import androidx.camera.video.Quality
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBackIosNew
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.ChevronRight
import androidx.compose.material3.Icon
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// =====================================================================
//  ขั้นที่ 3: หน้าตั้งค่าในแอป (Android ไม่มีที่ให้ฝากค่าไว้ในระบบ เลยทำเอง)
//  จัดกลุ่มตามหน้า Settings > Camera ของ iPhone
//  ค่าทั้งหมดเก็บถาวรใน SharedPreferences
// =====================================================================

data class CameraSettings(
    val grid: Boolean = false,
    val level: Boolean = false,
    val mirrorFront: Boolean = false,
    val preserveMode: Boolean = true,
    val preserveExposure: Boolean = false,
    val videoQuality: Int = 1,   // 0 = 4K, 1 = 1080p, 2 = 720p
    val videoFps: Int = 30,      // 30 หรือ 60
    val maxResolution: Boolean = false,
    val showFileInfo: Boolean = true,
    val lastMode: Int = 0,       // 0 = ภาพถ่าย, 1 = วิดีโอ
    val lastEv: Int = 0
)

private const val PREFS = "procamera_settings"

fun loadSettings(context: Context): CameraSettings {
    val p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    val d = CameraSettings()
    return CameraSettings(
        grid = p.getBoolean("grid", d.grid),
        level = p.getBoolean("level", d.level),
        mirrorFront = p.getBoolean("mirrorFront", d.mirrorFront),
        preserveMode = p.getBoolean("preserveMode", d.preserveMode),
        preserveExposure = p.getBoolean("preserveExposure", d.preserveExposure),
        videoQuality = p.getInt("videoQuality", d.videoQuality),
        videoFps = p.getInt("videoFps", d.videoFps),
        maxResolution = p.getBoolean("maxResolution", d.maxResolution),
        showFileInfo = p.getBoolean("showFileInfo", d.showFileInfo),
        lastMode = p.getInt("lastMode", d.lastMode),
        lastEv = p.getInt("lastEv", d.lastEv),
    )
}

fun saveSettings(context: Context, s: CameraSettings) {
    context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
        .putBoolean("grid", s.grid)
        .putBoolean("level", s.level)
        .putBoolean("mirrorFront", s.mirrorFront)
        .putBoolean("preserveMode", s.preserveMode)
        .putBoolean("preserveExposure", s.preserveExposure)
        .putInt("videoQuality", s.videoQuality)
        .putInt("videoFps", s.videoFps)
        .putBoolean("maxResolution", s.maxResolution)
        .putBoolean("showFileInfo", s.showFileInfo)
        .putInt("lastMode", s.lastMode)
        .putInt("lastEv", s.lastEv)
        .apply()
}

private val CardColor = Color(0xFF1C1C1E)
private val SwitchGreen = Color(0xFF34C759)
private val AccentYellow = Color(0xFFFFD60A)

@Composable
fun SettingsScreen(
    settings: CameraSettings,
    onChange: (CameraSettings) -> Unit,
    supportedQualities: List<Quality>,
    maxFps: Int,
    onOpenCameraInfo: () -> Unit,
    onClose: () -> Unit
) {
    fun supported(q: Quality) = supportedQualities.isEmpty() || q in supportedQualities

    Column(
        Modifier
            .fillMaxSize()
            .background(Color.Black)
            .pointerInput(Unit) { }   // กันแตะทะลุลงไปโดนหน้ากล้องด้านหลัง
            .statusBarsPadding()
            .navigationBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp)
    ) {
        // แถบหัว
        Box(Modifier.fillMaxWidth().padding(vertical = 12.dp), contentAlignment = Alignment.Center) {
            Row(
                Modifier
                    .align(Alignment.CenterStart)
                    .clickable(onClick = onClose)
                    .padding(4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    Icons.Rounded.ArrowBackIosNew,
                    contentDescription = null,
                    tint = AccentYellow,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(Modifier.width(4.dp))
                Text("กล้อง", color = AccentYellow, fontSize = 16.sp)
            }
            Text("ตั้งค่ากล้อง", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
        }

        Section(
            title = "การจัดองค์ประกอบภาพ",
            footer = "ระดับน้ำจะแสดงเส้นนำทางเมื่อถือโทรศัพท์ตั้งตรง และเป็นสีเหลืองเมื่อได้ระดับ"
        ) {
            SwitchRow("เส้นตาราง", settings.grid) { onChange(settings.copy(grid = it)) }
            RowDivider()
            SwitchRow("ระดับน้ำ", settings.level) { onChange(settings.copy(level = it)) }
            RowDivider()
            SwitchRow("กลับด้านกล้องหน้า", settings.mirrorFront) { onChange(settings.copy(mirrorFront = it)) }
        }

        Section(
            title = "คงค่าที่ตั้งไว้",
            footer = "เปิดไว้เพื่อให้แอปจำค่าล่าสุดเมื่อเปิดครั้งถัดไป ถ้าปิด แอปจะกลับเป็นค่าเริ่มต้น"
        ) {
            SwitchRow("โหมดกล้อง", settings.preserveMode) { onChange(settings.copy(preserveMode = it)) }
            RowDivider()
            SwitchRow("ชดเชยแสง", settings.preserveExposure) { onChange(settings.copy(preserveExposure = it)) }
        }

        Section(
            title = "คุณภาพภาพถ่าย",
            footer = "ความละเอียดสูงสุดอาจทำให้ถ่ายช้าลงและไฟล์ใหญ่ขึ้น บางเครื่องไม่รองรับ ถ้ากล้องเปิดไม่ขึ้นหลังเปิดตัวเลือกนี้ ให้ปิดกลับ"
        ) {
            SwitchRow("ความละเอียดสูงสุดที่เครื่องอนุญาต", settings.maxResolution) {
                onChange(settings.copy(maxResolution = it))
            }
            RowDivider()
            SwitchRow("แสดงรายละเอียดไฟล์หลังถ่าย", settings.showFileInfo) {
                onChange(settings.copy(showFileInfo = it))
            }
        }

        Section(
            title = "บันทึกวิดีโอ",
            footer = "ความละเอียดสูงใช้พื้นที่เก็บข้อมูลมากขึ้น ตัวเลือกที่เครื่องไม่รองรับจะเป็นสีจาง"
        ) {
            ChoiceRow("4K", settings.videoQuality == 0, supported(Quality.UHD)) {
                onChange(settings.copy(videoQuality = 0))
            }
            RowDivider()
            ChoiceRow("1080p HD", settings.videoQuality == 1, supported(Quality.FHD)) {
                onChange(settings.copy(videoQuality = 1))
            }
            RowDivider()
            ChoiceRow("720p HD", settings.videoQuality == 2, supported(Quality.HD)) {
                onChange(settings.copy(videoQuality = 2))
            }
        }

        Section(
            title = "เฟรมเรตวิดีโอ",
            footer = "เครื่องรายงานให้แอปนี้ใช้ได้สูงสุด $maxFps fps (แอปกล้องของเครื่องอาจใช้ช่องทางพิเศษที่แอปอื่นเข้าไม่ถึง) ลองเลือก 60 แล้วอัด ระบบจะบอกเฟรมเรตจริงที่ได้หลังอัดเสร็จ"
        ) {
            ChoiceRow("30 fps", settings.videoFps == 30, true) {
                onChange(settings.copy(videoFps = 30))
            }
            RowDivider()
            ChoiceRow("60 fps (ทดลอง)", settings.videoFps == 60, true) {
                onChange(settings.copy(videoFps = 60))
            }
        }

        Section(title = "เกี่ยวกับ") {
            LinkRow("ข้อมูลกล้องของเครื่อง", onOpenCameraInfo)
        }

        // แสดงเวอร์ชันของแอปที่ติดตั้งอยู่ เอาไว้เช็คว่าใช้ APK ตัวใหม่ล่าสุดจริงหรือยัง
        val ctx = androidx.compose.ui.platform.LocalContext.current
        val versionLabel = remember {
            runCatching {
                val info = ctx.packageManager.getPackageInfo(ctx.packageName, 0)
                "เวอร์ชันแอป ${info.versionName}"
            }.getOrDefault("เวอร์ชันแอป -")
        }
        Text(
            versionLabel,
            color = Color.White.copy(alpha = 0.4f),
            fontSize = 12.sp,
            modifier = Modifier.padding(start = 16.dp, top = 20.dp)
        )

        Spacer(Modifier.height(32.dp))
    }
}

@Composable
private fun Section(
    title: String,
    footer: String? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    Text(
        title,
        color = Color.White.copy(alpha = 0.55f),
        fontSize = 12.sp,
        modifier = Modifier.padding(start = 16.dp, top = 22.dp, bottom = 6.dp)
    )
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(CardColor),
        content = content
    )
    if (footer != null) {
        Text(
            footer,
            color = Color.White.copy(alpha = 0.5f),
            fontSize = 12.sp,
            modifier = Modifier.padding(start = 16.dp, top = 6.dp, end = 16.dp)
        )
    }
}

@Composable
private fun RowDivider() {
    Box(
        Modifier
            .padding(start = 16.dp)
            .fillMaxWidth()
            .height(0.5.dp)
            .background(Color.White.copy(alpha = 0.12f))
    )
}

@Composable
private fun SwitchRow(title: String, checked: Boolean, onChecked: (Boolean) -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clickable { onChecked(!checked) }
            .padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(title, color = Color.White, fontSize = 16.sp, modifier = Modifier.weight(1f))
        Switch(
            checked = checked,
            onCheckedChange = onChecked,
            colors = SwitchDefaults.colors(
                checkedTrackColor = SwitchGreen,
                checkedThumbColor = Color.White,
                checkedBorderColor = Color.Transparent,
                uncheckedTrackColor = Color(0xFF39393D),
                uncheckedThumbColor = Color.White,
                uncheckedBorderColor = Color.Transparent
            )
        )
    }
}

@Composable
private fun ChoiceRow(title: String, selected: Boolean, enabled: Boolean, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            if (enabled) title else "$title (ไม่รองรับ)",
            color = Color.White.copy(alpha = if (enabled) 1f else 0.35f),
            fontSize = 16.sp,
            modifier = Modifier.weight(1f)
        )
        if (selected) {
            Icon(
                Icons.Rounded.Check,
                contentDescription = null,
                tint = AccentYellow,
                modifier = Modifier.size(20.dp)
            )
        }
    }
}

@Composable
private fun LinkRow(title: String, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(title, color = Color.White, fontSize = 16.sp, modifier = Modifier.weight(1f))
        Icon(
            Icons.Rounded.ChevronRight,
            contentDescription = null,
            tint = Color.White.copy(alpha = 0.4f),
            modifier = Modifier.size(20.dp)
        )
    }
}
