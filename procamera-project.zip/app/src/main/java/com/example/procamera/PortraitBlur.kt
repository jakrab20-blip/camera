package com.example.procamera

import android.graphics.Bitmap
import android.graphics.Matrix
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.segmentation.Segmentation
import com.google.mlkit.vision.segmentation.selfie.SelfieSegmenterOptions
import kotlin.math.max
import kotlin.math.min

// =====================================================================
//  โหมดภาพเหมือน: เบลอฉากหลังเอง (ไม่พึ่ง Bokeh ของฮาร์ดแวร์)
//  1) ย่อภาพเป็นสำเนาเล็ก (ด้านยาวไม่เกิน 720px) แล้วให้ ML Kit Selfie Segmentation แยกตัวคนออกจากฉากหลัง
//  2) เบลอเฉพาะพิกเซลฉากหลังบนสำเนาเล็ก (ถ่วงน้ำหนักด้วยมาสก์ เพื่อไม่ให้สีของตัวแบบไหลเข้าฉากหลังรอบขอบ)
//  3) วนทีละแถวบนภาพเต็ม ผสมตัวแบบ (ของจริง) กับฉากหลังเบลอ (สุ่มแบบ bilinear จากสำเนาเล็ก) ตามมาสก์
//  ไม่สร้างสำเนาเต็มภาพเพิ่ม จึงกินหน่วยความจำต่ำ ใช้ได้กับคนเท่านั้น (ของ/สัตว์แยกไม่ได้)
// =====================================================================
object PortraitBlur {

    enum class Result { APPLIED, NO_PERSON, FAILED }

    private const val SMALL_MAX = 720

    private class Mask(val w: Int, val h: Int, val data: FloatArray)

    /** strength 0..1 (ตรงกับสไลเดอร์) — แก้ [bmp] ในที่เดิม; exifOrientation = ค่า EXIF ของไฟล์ต้นฉบับ */
    fun apply(bmp: Bitmap, strength: Float, exifOrientation: Int): Result {
        val w = bmp.width
        val h = bmp.height
        if (w < 32 || h < 32) return Result.FAILED

        // 1) สำเนาเล็กแบบ "ดิบ" (หมุนเหมือนไฟล์) และแบบตั้งตรง (ให้โมเดลแยกคนได้แม่นขึ้น)
        val scale = min(1f, SMALL_MAX.toFloat() / max(w, h))
        val sw = max(8, (w * scale).toInt())
        val sh = max(8, (h * scale).toInt())
        val small = Bitmap.createScaledBitmap(bmp, sw, sh, true)
        val deg = when (exifOrientation) {
            6 -> 90
            3 -> 180
            8 -> 270
            else -> 0
        }
        val upright = if (deg == 0) small else {
            val mtx = Matrix().apply { postRotate(deg.toFloat()) }
            Bitmap.createBitmap(small, 0, 0, sw, sh, mtx, true)
        }
        val uw = upright.width
        val uh = upright.height

        // 2) แยกตัวคน
        val mask = segment(upright) ?: return Result.FAILED
        var fg = 0
        for (v in mask.data) if (v > 0.5f) fg++
        if (fg < mask.data.size * 0.01f) return Result.NO_PERSON

        // 3) แปลงมาสก์ตั้งตรง -> พิกัดแบบดิบของสำเนาเล็ก + ทำขอบให้นุ่ม
        val raw = FloatArray(sw * sh)
        for (j in 0 until sh) {
            for (i in 0 until sw) {
                val u: Int
                val v: Int
                when (deg) {
                    90 -> { u = sh - 1 - j; v = i }
                    180 -> { u = sw - 1 - i; v = sh - 1 - j }
                    270 -> { u = j; v = sw - 1 - i }
                    else -> { u = i; v = j }
                }
                val mu = (u * (mask.w - 1f) / max(1, uw - 1)).toInt().coerceIn(0, mask.w - 1)
                val mv = (v * (mask.h - 1f) / max(1, uh - 1)).toInt().coerceIn(0, mask.h - 1)
                raw[j * sw + i] = mask.data[mv * mask.w + mu]
            }
        }
        val soft = boxBlur(raw, sw, sh, 2)
        for (i in soft.indices) {
            val t = ((soft[i] - 0.3f) / 0.4f).coerceIn(0f, 1f)
            soft[i] = t * t * (3f - 2f * t) // 1 = ตัวแบบ, 0 = ฉากหลัง
        }

        // 4) เบลอฉากหลังบนสำเนาเล็ก (ถ่วงน้ำหนักด้วย 1 - มาสก์)
        val rBlur = (3 + strength.coerceIn(0f, 1f) * 17f).toInt().coerceAtMost(min(sw, sh) / 3)
        val pix = IntArray(sw * sh)
        small.getPixels(pix, 0, sw, 0, 0, sw, sh)
        val n = sw * sh
        val pr = FloatArray(n)
        val pg = FloatArray(n)
        val pb = FloatArray(n)
        val pw = FloatArray(n)
        for (i in 0 until n) {
            val wb = 1f - soft[i]
            val p = pix[i]
            pr[i] = ((p shr 16) and 255) * wb
            pg[i] = ((p shr 8) and 255) * wb
            pb[i] = (p and 255) * wb
            pw[i] = wb
        }
        var br = pr; var bg = pg; var bb = pb; var bw = pw
        repeat(2) {
            br = boxBlur(br, sw, sh, rBlur)
            bg = boxBlur(bg, sw, sh, rBlur)
            bb = boxBlur(bb, sw, sh, rBlur)
            bw = boxBlur(bw, sw, sh, rBlur)
        }
        val bgR = FloatArray(n)
        val bgG = FloatArray(n)
        val bgB = FloatArray(n)
        for (i in 0 until n) {
            if (bw[i] > 0.02f) {
                bgR[i] = br[i] / bw[i]
                bgG[i] = bg[i] / bw[i]
                bgB[i] = bb[i] / bw[i]
            } else {
                val p = pix[i]
                bgR[i] = ((p shr 16) and 255).toFloat()
                bgG[i] = ((p shr 8) and 255).toFloat()
                bgB[i] = (p and 255).toFloat()
            }
        }

        // 5) ผสมลงภาพเต็มทีละแถว
        val x0 = IntArray(w)
        val xf = FloatArray(w)
        for (x in 0 until w) {
            val fx = x * (sw - 1f) / (w - 1f)
            x0[x] = fx.toInt().coerceAtMost(sw - 2)
            xf[x] = fx - x0[x]
        }
        val row = IntArray(w)
        for (y in 0 until h) {
            val fy = y * (sh - 1f) / (h - 1f)
            val y0 = fy.toInt().coerceAtMost(sh - 2)
            val yf = fy - y0
            val o0 = y0 * sw
            val o1 = o0 + sw
            bmp.getPixels(row, 0, w, 0, y, w, 1)
            var changed = false
            for (x in 0 until w) {
                val a = x0[x]
                val fxv = xf[x]
                val m00 = soft[o0 + a]; val m10 = soft[o0 + a + 1]
                val m01 = soft[o1 + a]; val m11 = soft[o1 + a + 1]
                val m = (m00 * (1 - fxv) + m10 * fxv) * (1 - yf) + (m01 * (1 - fxv) + m11 * fxv) * yf
                if (m >= 0.995f) continue
                val r = bilerp(bgR, o0 + a, o1 + a, fxv, yf)
                val g = bilerp(bgG, o0 + a, o1 + a, fxv, yf)
                val b = bilerp(bgB, o0 + a, o1 + a, fxv, yf)
                val p = row[x]
                val pr0 = (p shr 16) and 255
                val pg0 = (p shr 8) and 255
                val pb0 = p and 255
                val nr = (pr0 * m + r * (1f - m) + 0.5f).toInt().coerceIn(0, 255)
                val ng = (pg0 * m + g * (1f - m) + 0.5f).toInt().coerceIn(0, 255)
                val nb = (pb0 * m + b * (1f - m) + 0.5f).toInt().coerceIn(0, 255)
                row[x] = (0xFF shl 24) or (nr shl 16) or (ng shl 8) or nb
                changed = true
            }
            if (changed) bmp.setPixels(row, 0, w, 0, y, w, 1)
        }
        return Result.APPLIED
    }

    private fun bilerp(a: FloatArray, i0: Int, i1: Int, fx: Float, fy: Float): Float {
        val top = a[i0] * (1 - fx) + a[i0 + 1] * fx
        val bot = a[i1] * (1 - fx) + a[i1 + 1] * fx
        return top * (1 - fy) + bot * fy
    }

    private fun segment(bitmap: Bitmap): Mask? {
        val options = SelfieSegmenterOptions.Builder()
            .setDetectorMode(SelfieSegmenterOptions.SINGLE_IMAGE_MODE)
            .enableRawSizeMask()
            .build()
        val segmenter = Segmentation.getClient(options)
        return try {
            val res = Tasks.await(segmenter.process(InputImage.fromBitmap(bitmap, 0)))
            val buf = res.buffer
            buf.rewind()
            val arr = FloatArray(res.width * res.height)
            for (i in arr.indices) arr[i] = buf.float
            Mask(res.width, res.height, arr)
        } catch (t: Throwable) {
            null
        } finally {
            segmenter.close()
        }
    }

    private fun boxBlur(src: FloatArray, w: Int, h: Int, r: Int): FloatArray {
        if (r < 1) return src.copyOf()
        val tmp = FloatArray(w * h)
        val dst = FloatArray(w * h)
        val inv = 1f / (2 * r + 1)
        for (y in 0 until h) {
            val o = y * w
            var sum = 0f
            for (dx in -r..r) sum += src[o + dx.coerceIn(0, w - 1)]
            tmp[o] = sum * inv
            for (x in 1 until w) {
                sum += src[o + (x + r).coerceAtMost(w - 1)] - src[o + (x - r - 1).coerceAtLeast(0)]
                tmp[o + x] = sum * inv
            }
        }
        for (x in 0 until w) {
            var sum = 0f
            for (dy in -r..r) sum += tmp[dy.coerceIn(0, h - 1) * w + x]
            dst[x] = sum * inv
            for (y in 1 until h) {
                sum += tmp[(y + r).coerceAtMost(h - 1) * w + x] - tmp[(y - r - 1).coerceAtLeast(0) * w + x]
                dst[y * w + x] = sum * inv
            }
        }
        return dst
    }
}
