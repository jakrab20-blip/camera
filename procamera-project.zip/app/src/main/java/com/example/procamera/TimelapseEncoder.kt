package com.example.procamera

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.Image
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.MediaMuxer
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import java.io.File

// =====================================================================
//  ประกอบชุดภาพนิ่งจากไทม์แลปส์ให้เป็นไฟล์วิดีโอ MP4 เดียว
//  ใช้ MediaCodec แบบป้อนบัฟเฟอร์ YUV ตรง ๆ (ไม่ใช้ Surface) เพราะ Surface ที่ได้จาก
//  createInputSurface() ไม่รองรับ Canvas วาดภาพนิ่งโดยตรง วิธีนี้จึงควบคุม timestamp
//  ของแต่ละเฟรมได้แม่นยำ และไม่ต้องพึ่ง OpenGL
//  ข้อจำกัดที่รู้: แปลงสี RGB→YUV ด้วยซีพียู (ไม่ใช้ GPU) จึงช้าพอสมควรถ้าภาพเยอะ/ใหญ่มาก
//  ทดสอบผ่าน public API ของ Android เท่านั้น ยังไม่เคยรันบนอุปกรณ์จริง แนะนำให้ทดสอบก่อนใช้งานจริง
// =====================================================================
object TimelapseEncoder {

    /** คืน Uri ของวิดีโอที่สร้างเสร็จ หรือ null ถ้าล้มเหลว/ไม่มีภาพให้ประกอบ */
    fun assemble(
        context: Context,
        photoUris: List<Uri>,
        fps: Int = 30,
        outputDisplayName: String,
        outputRelativePath: String = "Movies/ProCamera/Timelapse"
    ): Uri? {
        if (photoUris.isEmpty()) return null

        // ---- หาขนาดจากภาพแรก แล้วจำกัดด้านยาวสุดไม่เกิน 1920 เพื่อให้เข้ารหัสไหวและเร็วขึ้น ----
        val firstOpts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        context.contentResolver.openInputStream(photoUris[0])?.use {
            BitmapFactory.decodeStream(it, null, firstOpts)
        } ?: return null
        if (firstOpts.outWidth <= 0 || firstOpts.outHeight <= 0) return null

        val maxDim = 1920
        var w = firstOpts.outWidth
        var h = firstOpts.outHeight
        if (maxOf(w, h) > maxDim) {
            val scale = maxDim.toFloat() / maxOf(w, h)
            w = (w * scale).toInt()
            h = (h * scale).toInt()
        }
        // ตัวเข้ารหัสวิดีโอส่วนใหญ่ต้องการความกว้าง/สูงเป็นเลขคู่
        w -= w % 2
        h -= h % 2
        if (w <= 0 || h <= 0) return null

        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, outputDisplayName)
            put(MediaStore.MediaColumns.MIME_TYPE, "video/mp4")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                put(MediaStore.MediaColumns.RELATIVE_PATH, outputRelativePath)
                put(MediaStore.MediaColumns.IS_PENDING, 1)
            }
        }
        val outUri = context.contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
            ?: return null

        // MediaMuxer เขียนลง path ไฟล์จริงเท่านั้น จึงเข้ารหัสลงไฟล์ชั่วคราวก่อน แล้วค่อยคัดลอกเข้า MediaStore
        val tempFile = File(context.cacheDir, "timelapse_${System.currentTimeMillis()}.mp4")
        var success = false
        try {
            success = encode(context, photoUris, w, h, fps, tempFile)
            if (success) {
                context.contentResolver.openOutputStream(outUri)?.use { out ->
                    tempFile.inputStream().use { it.copyTo(out) }
                } ?: run { success = false }
            }
            if (success && Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val done = ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }
                context.contentResolver.update(outUri, done, null, null)
            }
        } catch (e: Exception) {
            success = false
        } finally {
            tempFile.delete()
        }

        return if (success) {
            outUri
        } else {
            runCatching { context.contentResolver.delete(outUri, null, null) }
            null
        }
    }

    private fun encode(
        context: Context,
        photoUris: List<Uri>,
        width: Int,
        height: Int,
        fps: Int,
        outFile: File
    ): Boolean {
        val format = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, width, height).apply {
            setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420Flexible)
            setInteger(MediaFormat.KEY_BIT_RATE, width * height * 4)
            setInteger(MediaFormat.KEY_FRAME_RATE, fps)
            setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
        }
        val codec = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC)
        codec.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        codec.start()

        val muxer = MediaMuxer(outFile.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        var muxerStarted = false
        var trackIndex = -1
        val bufferInfo = MediaCodec.BufferInfo()
        val frameDurationUs = 1_000_000L / fps

        fun drainOutput(blockUntilDone: Boolean) {
            while (true) {
                val outIndex = codec.dequeueOutputBuffer(bufferInfo, 10_000)
                when {
                    outIndex == MediaCodec.INFO_TRY_AGAIN_LATER -> if (!blockUntilDone) return
                    outIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                        trackIndex = muxer.addTrack(codec.outputFormat)
                        muxer.start()
                        muxerStarted = true
                    }
                    outIndex >= 0 -> {
                        val encoded = codec.getOutputBuffer(outIndex)
                        if (encoded != null && bufferInfo.size > 0 && muxerStarted) {
                            encoded.position(bufferInfo.offset)
                            encoded.limit(bufferInfo.offset + bufferInfo.size)
                            muxer.writeSampleData(trackIndex, encoded, bufferInfo)
                        }
                        codec.releaseOutputBuffer(outIndex, false)
                        if (bufferInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) return
                    }
                }
            }
        }

        try {
            photoUris.forEachIndexed { i, uri ->
                val bmp = decodeScaled(context, uri, width, height) ?: return@forEachIndexed
                var inIndex = -1
                var attempts = 0
                while (inIndex < 0 && attempts < 50) {
                    inIndex = codec.dequeueInputBuffer(10_000)
                    attempts++
                    if (inIndex < 0) drainOutput(false)
                }
                if (inIndex >= 0) {
                    val image = codec.getInputImage(inIndex)
                    if (image != null) {
                        fillYuvImage(image, bmp)
                        codec.queueInputBuffer(inIndex, 0, 0, i * frameDurationUs, 0)
                    } else {
                        codec.queueInputBuffer(inIndex, 0, 0, i * frameDurationUs, 0)
                    }
                }
                bmp.recycle()
                drainOutput(false)
            }
            var eosIndex = -1
            var attempts = 0
            while (eosIndex < 0 && attempts < 50) {
                eosIndex = codec.dequeueInputBuffer(10_000)
                attempts++
                if (eosIndex < 0) drainOutput(false)
            }
            if (eosIndex >= 0) {
                codec.queueInputBuffer(eosIndex, 0, 0, photoUris.size * frameDurationUs, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
            }
            drainOutput(true)
        } finally {
            codec.stop()
            codec.release()
            if (muxerStarted) runCatching { muxer.stop() }
            muxer.release()
        }
        return muxerStarted
    }

    // ย่อภาพลงมาให้พอดีกรอบ width x height (เติมขอบดำถ้าสัดส่วนไม่ตรง) เพื่อให้ทุกเฟรมขนาดเท่ากัน
    private fun decodeScaled(context: Context, uri: Uri, width: Int, height: Int): Bitmap? {
        val original = context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) }
            ?: return null
        val out = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = android.graphics.Canvas(out)
        canvas.drawColor(android.graphics.Color.BLACK)
        val srcRatio = original.width.toFloat() / original.height
        val dstRatio = width.toFloat() / height
        val dst = if (srcRatio > dstRatio) {
            val dh = (width / srcRatio).toInt()
            android.graphics.Rect(0, (height - dh) / 2, width, (height - dh) / 2 + dh)
        } else {
            val dw = (height * srcRatio).toInt()
            android.graphics.Rect((width - dw) / 2, 0, (width - dw) / 2 + dw, height)
        }
        canvas.drawBitmap(original, null, dst, null)
        original.recycle()
        return out
    }

    // เติมข้อมูลลง YUV_420_888 Image ตาม rowStride/pixelStride ของแต่ละระนาบ (รองรับได้ทุกเครื่อง
    // เพราะไม่ยึดติดกับ layout NV21/I420 แบบใดแบบหนึ่ง)
    private fun fillYuvImage(image: Image, bitmap: Bitmap) {
        val width = image.width
        val height = image.height
        val pixels = IntArray(width * height)
        bitmap.getPixels(pixels, 0, width, 0, 0, width, height)

        val yPlane = image.planes[0]
        val uPlane = image.planes[1]
        val vPlane = image.planes[2]

        for (row in 0 until height) {
            val rowBase = row * width
            for (col in 0 until width) {
                val argb = pixels[rowBase + col]
                val r = (argb shr 16) and 0xFF
                val g = (argb shr 8) and 0xFF
                val b = argb and 0xFF
                val y = (0.299 * r + 0.587 * g + 0.114 * b).toInt().coerceIn(0, 255)
                yPlane.buffer.put(row * yPlane.rowStride + col * yPlane.pixelStride, y.toByte())

                if (row % 2 == 0 && col % 2 == 0) {
                    val u = (-0.168736 * r - 0.331264 * g + 0.5 * b + 128).toInt().coerceIn(0, 255)
                    val v = (0.5 * r - 0.418688 * g - 0.081312 * b + 128).toInt().coerceIn(0, 255)
                    val cr = row / 2
                    val cc = col / 2
                    uPlane.buffer.put(cr * uPlane.rowStride + cc * uPlane.pixelStride, u.toByte())
                    vPlane.buffer.put(cr * vPlane.rowStride + cc * vPlane.pixelStride, v.toByte())
                }
            }
        }
    }
}
