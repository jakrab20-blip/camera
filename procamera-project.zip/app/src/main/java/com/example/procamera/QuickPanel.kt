package com.example.procamera

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.roundToInt

// =====================================================================
//  QuickPanel: แผงด่วนสไตล์ iOS 26 (ปัดขึ้นเพื่อเปิด)
//  - แถวปุ่มกลมโปร่งแสง เลือกเครื่องมือได้ทีละอย่าง
//  - ด้านล่างแสดงตัวปรับของเครื่องมือที่เลือก
//  - กดค้างที่ปุ่ม = รีเซ็ตค่าเครื่องมือนั้น (ไอเดียของฉันเอง ไม่ได้ลอกจาก iPhone)
//  ไฟล์นี้ไม่พึ่งตัวแปรในโค้ดเดิม เอาไปวางแล้วต่อค่าตามคอมเมนต์ท้ายไฟล์
// =====================================================================

private val Yellow = Color(0xFFFFD60A)

enum class PanelTool { EXPOSURE, TIMER, ASPECT, MANUAL, STYLE, BLUR }

enum class PhotoStyle(val label: String) {
    STANDARD("มาตรฐาน"),
    VIVID("สด"),
    WARM("อุ่น"),
    COOL("เย็น"),
    MONO("ขาวดำ"),
    // สไตล์แนวฟิล์ม ได้แรงบันดาลใจจากโทนกล้องฟิล์มญี่ปุ่นยอดนิยม (จำลองด้วยโทนสี ไม่ใช่โปรไฟล์สีลิขสิทธิ์จริง)
    FILM("ฟิล์ม")
}

data class QuickPanelState(
    val evIndex: Int = 0,
    val timerSec: Int = 0,
    val aspectLabel: String = "",
    val manualOn: Boolean = false,
    val iso: Int = 100,
    val shutterNs: Long = 16_666_666L, // ~1/60 วินาที
    // ค่าเริ่มต้นของแอปตั้งเป็น "สด" (VIVID) ตามที่ผู้ใช้ต้องการ ให้เปิดแอปมาก็สีสดทันทีโดยยังไม่ต้องเลือกเอง
    val style: PhotoStyle = PhotoStyle.VIVID,
    val blur: Float = 0.5f
)

@Composable
fun QuickPanel(
    expanded: Boolean,
    onExpandedChange: (Boolean) -> Unit,
    state: QuickPanelState,
    onStateChange: (QuickPanelState) -> Unit,
    evRange: IntRange,                 // จาก exposureCompensationRange (0..0 = ไม่รองรับ)
    evStep: Float,                     // จาก exposureCompensationStep
    isoRange: IntRange?,               // null = ไม่รองรับแมนนวล
    shutterRangeNs: LongRange?,        // null = ไม่รองรับแมนนวล
    aspectOptions: List<String>,
    blurAvailable: Boolean,
    showTimer: Boolean = true,
    modifier: Modifier = Modifier
) {
    val tools = remember(evRange, isoRange, shutterRangeNs, aspectOptions, blurAvailable, showTimer) {
        buildList {
            if (evRange.first < evRange.last) add(PanelTool.EXPOSURE)
            if (showTimer) add(PanelTool.TIMER)
            if (aspectOptions.isNotEmpty()) add(PanelTool.ASPECT)
            if (isoRange != null && shutterRangeNs != null) add(PanelTool.MANUAL)
            add(PanelTool.STYLE)
            if (blurAvailable) add(PanelTool.BLUR)
        }
    }
    var selected by remember { mutableStateOf(PanelTool.TIMER) }
    val current = if (selected in tools) selected else tools.first()

    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp)
            .glass(RoundedCornerShape(28.dp))
            .pointerInput(expanded, onExpandedChange) {
                var total = 0f
                detectVerticalDragGestures(
                    onDragStart = { total = 0f },
                    onVerticalDrag = { _, dy -> total += dy },
                    onDragEnd = {
                        if (total < -40f) onExpandedChange(true)
                        else if (total > 40f) onExpandedChange(false)
                    }
                )
            }
            .padding(bottom = if (expanded) 16.dp else 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // แถบจับสำหรับปัดขึ้น/ลง (แตะเพื่อสลับได้ด้วย)
        Box(
            Modifier
                .clickable { onExpandedChange(!expanded) }
                .padding(horizontal = 40.dp, vertical = 8.dp)
        ) {
            Box(
                Modifier
                    .size(width = 36.dp, height = 4.dp)
                    .clip(CircleShape)
                    .background(Color.White.copy(alpha = 0.6f))
            )
        }

        AnimatedVisibility(
            visible = expanded,
            enter = expandVertically() + fadeIn(),
            exit = shrinkVertically() + fadeOut()
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Row(
                    Modifier
                        .horizontalScroll(rememberScrollState())
                        .padding(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    tools.forEach { t ->
                        ToolButton(
                            tool = t,
                            selected = t == current,
                            active = t.isActive(state),
                            onClick = { selected = t },
                            onLongClick = { onStateChange(state.reset(t)) }
                        )
                    }
                }

                ToolControls(
                    tool = current,
                    state = state,
                    onStateChange = onStateChange,
                    evRange = evRange,
                    evStep = evStep,
                    isoRange = isoRange,
                    shutterRangeNs = shutterRangeNs,
                    aspectOptions = aspectOptions
                )
            }
        }
    }
}

// ---------------------------------------------------------------------
//  ตัวปรับของแต่ละเครื่องมือ
// ---------------------------------------------------------------------
@Composable
private fun ToolControls(
    tool: PanelTool,
    state: QuickPanelState,
    onStateChange: (QuickPanelState) -> Unit,
    evRange: IntRange,
    evStep: Float,
    isoRange: IntRange?,
    shutterRangeNs: LongRange?,
    aspectOptions: List<String>
) {
    Column(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        when (tool) {
            PanelTool.EXPOSURE -> {
                ControlHeader("ชดเชยแสง", "%+.1f EV".format(state.evIndex * evStep))
                YellowSlider(
                    value = state.evIndex.toFloat(),
                    range = evRange.first.toFloat()..evRange.last.toFloat(),
                    steps = (evRange.last - evRange.first - 1).coerceAtLeast(0)
                ) { onStateChange(state.copy(evIndex = it.roundToInt())) }
            }

            PanelTool.TIMER -> {
                ControlHeader("ตั้งเวลา", if (state.timerSec == 0) "ปิด" else "${state.timerSec} วินาที")
                ChipRow {
                    listOf(0, 3, 5, 10).forEach { s ->
                        GlassChip(if (s == 0) "ปิด" else "${s}s", state.timerSec == s) {
                            onStateChange(state.copy(timerSec = s))
                        }
                    }
                }
            }

            PanelTool.ASPECT -> {
                ControlHeader("สัดส่วนภาพ", state.aspectLabel)
                ChipRow {
                    aspectOptions.forEach { a ->
                        GlassChip(a, state.aspectLabel == a) {
                            onStateChange(state.copy(aspectLabel = a))
                        }
                    }
                }
            }

            PanelTool.MANUAL -> {
                ControlHeader("การเปิดรับแสง", if (state.manualOn) "แมนนวล" else "อัตโนมัติ")
                ChipRow {
                    GlassChip("อัตโนมัติ", !state.manualOn) { onStateChange(state.copy(manualOn = false)) }
                    GlassChip("แมนนวล", state.manualOn) { onStateChange(state.copy(manualOn = true)) }
                }
                if (state.manualOn && isoRange != null && shutterRangeNs != null) {
                    ControlHeader("ISO", state.iso.toString())
                    LogSlider(
                        value = state.iso.toDouble(),
                        min = isoRange.first.toDouble(),
                        max = isoRange.last.toDouble()
                    ) { onStateChange(state.copy(iso = it.roundToInt())) }

                    // จำกัดชัตเตอร์ช้าสุดที่ 1 วินาที เพื่อให้ปัดใช้งานง่าย
                    val maxNs = minOf(shutterRangeNs.last, 1_000_000_000L)
                    ControlHeader("ชัตเตอร์", shutterLabel(state.shutterNs))
                    LogSlider(
                        value = state.shutterNs.toDouble(),
                        min = shutterRangeNs.first.toDouble(),
                        max = maxNs.toDouble()
                    ) { onStateChange(state.copy(shutterNs = it.toLong())) }
                }
            }

            PanelTool.STYLE -> {
                ControlHeader("สไตล์ภาพ", state.style.label)
                ChipRow {
                    PhotoStyle.values().forEach { st ->
                        GlassChip(st.label, state.style == st) { onStateChange(state.copy(style = st)) }
                    }
                }
            }

            PanelTool.BLUR -> {
                val f = 16f - state.blur * (16f - 1.4f)
                ControlHeader("เบลอฉากหลัง", "ƒ%.1f".format(f))
                YellowSlider(state.blur, 0f..1f, 0) { onStateChange(state.copy(blur = it)) }
            }
        }
    }
}

// ---------------------------------------------------------------------
//  ชิ้นส่วนย่อย
// ---------------------------------------------------------------------
@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun ToolButton(
    tool: PanelTool,
    selected: Boolean,
    active: Boolean,
    onClick: () -> Unit,
    onLongClick: () -> Unit
) {
    Box(
        Modifier
            .size(46.dp)
            .clip(CircleShape)
            .background(Color.White.copy(alpha = if (selected) 0.28f else 0.12f))
            .border(0.8.dp, Color.White.copy(alpha = if (selected) 0.6f else 0.2f), CircleShape)
            .combinedClickable(onClick = onClick, onLongClick = onLongClick),
        contentAlignment = Alignment.Center
    ) {
        ToolIcon(tool, if (active) Yellow else Color.White)
    }
}

// ไอคอนวาดเอง ไม่พึ่งอีโมจิหรือชุดไอคอนภายนอก
@Composable
private fun ToolIcon(tool: PanelTool, tint: Color) {
    when (tool) {
        PanelTool.MANUAL -> Text("ISO", color = tint, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
        PanelTool.BLUR -> Text("ƒ", color = tint, fontSize = 20.sp, fontStyle = FontStyle.Italic)
        else -> Canvas(Modifier.size(22.dp)) {
            val w = 1.8.dp.toPx()
            val stroke = Stroke(width = w, cap = StrokeCap.Round)
            val c = center
            val r = size.minDimension / 2f - w
            when (tool) {
                PanelTool.EXPOSURE -> {
                    drawCircle(tint, r, c, style = stroke)
                    drawLine(tint, Offset(c.x - r * 0.5f, c.y), Offset(c.x + r * 0.5f, c.y), w, StrokeCap.Round)
                    drawLine(tint, Offset(c.x, c.y - r * 0.5f), Offset(c.x, c.y + r * 0.5f), w, StrokeCap.Round)
                }
                PanelTool.TIMER -> {
                    drawCircle(tint, r, c, style = stroke)
                    drawLine(tint, c, Offset(c.x, c.y - r * 0.6f), w, StrokeCap.Round)
                    drawLine(tint, c, Offset(c.x + r * 0.45f, c.y), w, StrokeCap.Round)
                }
                PanelTool.ASPECT -> drawRoundRect(
                    color = tint,
                    topLeft = Offset(w, size.height * 0.2f),
                    size = Size(size.width - 2 * w, size.height * 0.6f),
                    cornerRadius = CornerRadius(3.dp.toPx()),
                    style = stroke
                )
                PanelTool.STYLE -> {
                    drawCircle(tint, r * 0.65f, Offset(c.x - r * 0.35f, c.y), style = stroke)
                    drawCircle(tint, r * 0.65f, Offset(c.x + r * 0.35f, c.y), style = stroke)
                }
                else -> {}
            }
        }
    }
}

@Composable
private fun ControlHeader(title: String, value: String) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(title, color = Color.White.copy(alpha = 0.7f), fontSize = 12.sp)
        Text(value, color = Yellow, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun ChipRow(content: @Composable () -> Unit) {
    Row(
        Modifier.horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) { content() }
}

@Composable
private fun GlassChip(text: String, selected: Boolean, onClick: () -> Unit) {
    Text(
        text = text,
        color = if (selected) Color.Black else Color.White,
        fontSize = 13.sp,
        fontWeight = FontWeight.Medium,
        modifier = Modifier
            .clip(RoundedCornerShape(50))
            .background(if (selected) Yellow else Color.White.copy(alpha = 0.16f))
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 8.dp)
    )
}

@Composable
private fun YellowSlider(
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    steps: Int,
    onChange: (Float) -> Unit
) {
    Slider(
        value = value.coerceIn(range),
        onValueChange = onChange,
        valueRange = range,
        steps = steps,
        colors = SliderDefaults.colors(
            thumbColor = Yellow,
            activeTrackColor = Yellow,
            inactiveTrackColor = Color.White.copy(alpha = 0.3f),
            activeTickColor = Color.Transparent,
            inactiveTickColor = Color.Transparent
        )
    )
}

// สไลเดอร์แบบลอการิทึม เหมาะกับ ISO และชัตเตอร์ที่ค่าห่างกันมาก
@Composable
private fun LogSlider(value: Double, min: Double, max: Double, onChange: (Double) -> Unit) {
    val lo = ln(min)
    val hi = ln(max)
    if (hi <= lo) return
    val pos = ((ln(value.coerceIn(min, max)) - lo) / (hi - lo)).toFloat()
    YellowSlider(pos, 0f..1f, 0) { onChange(exp(lo + it * (hi - lo))) }
}

// ---------------------------------------------------------------------
//  ตัวช่วย
// ---------------------------------------------------------------------
// กระจกโปร่งแสงแบบประมาณ: พื้นดำจาง + ไล่ระดับขาว + ขอบไฮไลต์
// (Compose ยังเบลอฉากหลังจริงแบบ iOS ไม่ได้ง่าย ๆ จึงใช้วิธีนี้แทน)
private fun Modifier.glass(shape: Shape, strength: Float = 0.14f): Modifier =
    this
        .clip(shape)
        .background(Color.Black.copy(alpha = 0.4f))
        .background(
            Brush.verticalGradient(
                listOf(Color.White.copy(alpha = strength + 0.06f), Color.White.copy(alpha = strength))
            )
        )
        .border(
            0.8.dp,
            Brush.verticalGradient(
                listOf(Color.White.copy(alpha = 0.55f), Color.White.copy(alpha = 0.08f))
            ),
            shape
        )

private fun PanelTool.isActive(s: QuickPanelState): Boolean = when (this) {
    PanelTool.EXPOSURE -> s.evIndex != 0
    PanelTool.TIMER -> s.timerSec != 0
    PanelTool.ASPECT -> false
    PanelTool.MANUAL -> s.manualOn
    // ค่าเริ่มต้นของแอปคือสไตล์ "สด" (VIVID) แล้ว จุดจะโชว์เฉพาะตอนเลือกสไตล์อื่นที่ไม่ใช่ค่าเริ่มต้น
    PanelTool.STYLE -> s.style != PhotoStyle.VIVID
    PanelTool.BLUR -> s.blur != 0.5f
}

private fun QuickPanelState.reset(tool: PanelTool): QuickPanelState = when (tool) {
    PanelTool.EXPOSURE -> copy(evIndex = 0)
    PanelTool.TIMER -> copy(timerSec = 0)
    PanelTool.ASPECT -> this
    PanelTool.MANUAL -> copy(manualOn = false)
    PanelTool.STYLE -> copy(style = PhotoStyle.VIVID)
    PanelTool.BLUR -> copy(blur = 0.5f)
}

private fun shutterLabel(ns: Long): String {
    val sec = ns / 1_000_000_000.0
    return if (sec >= 0.5) "%.1f วิ".format(sec) else "1/${(1.0 / sec).roundToInt()}"
}

// =====================================================================
//  สถานะการต่อเข้ากับ CameraScreen.kt (อัปเดตล่าสุด)
// =====================================================================
// ไฟล์นี้ต่อเข้ากับ CameraScreen.kt เรียบร้อยแล้ว: state, evRange/isoRange/shutterRangeNs,
// และการส่งค่าไปกล้อง (setExposureCompensationIndex, applyCaptureOptions) อยู่ใน CameraScreen.kt
// ทั้งหมด ไม่ต้องต่อสายเพิ่มเอง
//
// สไตล์ภาพ (STYLE) มีผลจริงทั้งพรีวิวสดและไฟล์ที่บันทึก (ดู CameraScreen.kt
// ฟังก์ชัน styleColorFilter/applyStyleToSavedImage)
//
// ข้อจำกัดที่ยังเหลืออยู่: สไลเดอร์ BLUR (ความแรงเบลอฉากหลัง) ยังเป็นแค่ UI/สถานะ ตัวเบลอจริง
// มาจากโหมดภาพเหมือน (Portrait) ที่ใช้ CameraX Extensions BOKEH ของฮาร์ดแวร์เครื่องแทน ซึ่งไม่มี
// API สาธารณะให้ปรับความแรงเป็นระดับได้ ถ้าจะทำให้สไลเดอร์นี้มีผลจริงต้องเพิ่มการแบ่งส่วนภาพ
// (subject segmentation) เอง เช่นด้วย ML Kit Selfie Segmentation แล้วเบลอพื้นหลังด้วยซอฟต์แวร์
// ซึ่งเป็นงานเพิ่มเติมที่ยังไม่ได้ทำในโปรเจกต์นี้
