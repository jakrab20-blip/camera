package com.example.procamera

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.hardware.camera2.CameraCharacteristics
import androidx.camera.camera2.interop.Camera2CameraInfo
import androidx.camera.camera2.interop.ExperimentalCamera2Interop
import androidx.camera.core.Camera
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.atan
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.tan

// =====================================================================
//  พาโนรามาแบบกวาดกล้อง (ต่อภาพเอง ไม่ใช้ไลบรารีภายนอก)
//  วิธีทำ: ผู้ใช้ถือเครื่องตั้งตรงแล้วกวาดกล้องไปทางเดียว แอปอ่านองศาการหมุน (yaw) จากเซนเซอร์หมุนของเครื่อง
//  ทุกครั้งที่หมุนไปอีก ~2.5° จะดึงเฟรมจากพรีวิวสด ตัดแถบกลางภาพมาวางต่อกันตามตำแหน่งที่คำนวณจากมุม
//  (โปรเจกชันทรงกระบอก x = f * มุม) ให้แถบซ้อนกันเล็กน้อยแล้วไล่ความโปร่งที่ขอบเพื่อให้รอยต่อนุ่ม
//  ทิศของเซนเซอร์ตรวจซ้ำอัตโนมัติจากภาพจริง 2 เฟรมแรก (กันกรณีเครื่องรายงานทิศกลับด้านจนภาพกลับซ้ายขวา)
//  ข้อจำกัด: ไม่ปรับแก้พารัลแลกซ์/การเอียงขึ้นลง ภาพความสูงเท่าพรีวิว (~1440px) ถ้ากวาดเร็วหรือมีวัตถุใกล้อาจเห็นรอยต่อ
// =====================================================================

/** ประมาณมุมมองแนวนอน (เรเดียน) ของภาพพรีวิวตอนถือเครื่องตั้ง จากขนาดเซนเซอร์/ทางยาวโฟกัส/อัตราซูม */
@androidx.annotation.OptIn(ExperimentalCamera2Interop::class)
fun estimateHorizontalFov(camera: Camera, zoomRatio: Float): Double = runCatching {
    val info = Camera2CameraInfo.from(camera.cameraInfo)
    val size = info.getCameraCharacteristic(CameraCharacteristics.SENSOR_INFO_PHYSICAL_SIZE)!!
    val focal = info.getCameraCharacteristic(CameraCharacteristics.LENS_INFO_AVAILABLE_FOCAL_LENGTHS)!!.first()
    val shortSide = min(size.width, size.height) // ตอนถือตั้ง แนวนอนของภาพคือด้านสั้นของเซนเซอร์
    val fov = 2.0 * atan((shortSide / (2f * focal)).toDouble())
    2.0 * atan(tan(fov / 2.0) / max(0.1f, zoomRatio))
}.getOrDefault(Math.toRadians(60.0))

class PanoramaSession(context: Context, private val fovH: Double) : SensorEventListener {

    private class Strip(val bmp: Bitmap, val x: Int)

    private val sm = context.getSystemService(Context.SENSOR_SERVICE) as SensorManager
    @Volatile private var yaw = 0.0
    @Volatile private var hasYaw = false
    private val rot = FloatArray(9)
    private val rot2 = FloatArray(9)
    private val ori = FloatArray(3)

    private val strips = ArrayList<Strip>()
    private var first = true
    private var lastYaw = 0.0
    private var cum = 0.0        // มุมสะสมในทิศของภาพพาโนรามา (บวก = ต่อไปทางขวา)
    private var flip = 1        // +1 / -1 ทิศของเซนเซอร์เทียบกับภาพ (ตรวจจากภาพจริง)
    private var calibrated = false
    private var fPx = 1.0
    private var frameW = 0
    private var frameH = 0
    private var refSmall: IntArray? = null
    private var dirP = 0        // ทิศการกวาดในพื้นที่ภาพพาโนรามา (+1 ขวา / -1 ซ้าย)

    var sweptDegrees = 0f
        private set

    private val step = Math.toRadians(2.5)
    private val maxDegrees = 300.0
    private val maxWidthPx = 9000

    fun startSensors(): Boolean {
        val s = sm.getDefaultSensor(Sensor.TYPE_GAME_ROTATION_VECTOR)
            ?: sm.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)
            ?: return false
        return sm.registerListener(this, s, SensorManager.SENSOR_DELAY_GAME)
    }

    fun stopSensors() {
        sm.unregisterListener(this)
    }

    override fun onSensorChanged(e: SensorEvent) {
        SensorManager.getRotationMatrixFromVector(rot, e.values)
        // เครื่องตั้งตรง (กล้องหันไปข้างหน้า): ต้อง remap แกนก่อน ไม่งั้นมุม yaw จะเพี้ยนตอนเครื่องตั้ง
        SensorManager.remapCoordinateSystem(rot, SensorManager.AXIS_X, SensorManager.AXIS_Z, rot2)
        SensorManager.getOrientation(rot2, ori)
        yaw = ori[0].toDouble()
        hasYaw = true
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}

    /** ส่งเฟรมพรีวิวเข้ามา คืน false เมื่อถึงขีดจำกัด (ควรจบอัตโนมัติ) — ไม่ recycle เฟรมที่ส่งเข้ามา */
    fun addFrame(frame: Bitmap): Boolean {
        if (!hasYaw) return true
        val y = yaw
        if (first) {
            first = false
            lastYaw = y
            frameW = frame.width
            frameH = frame.height
            fPx = (frameW / 2.0) / tan(fovH / 2.0)
            refSmall = smallGray(frame)
            val sw = max(16, (fPx * step * 1.5).roundToInt())
            addStrip(frame, 0, sw, 0, true)
            return true
        }
        var d = y - lastYaw
        while (d > PI) d -= 2 * PI
        while (d < -PI) d += 2 * PI
        if (abs(d) < step) return true

        // ตรวจทิศเซนเซอร์จากภาพจริงครั้งแรกที่ขยับพอ (ถ้าภาพไม่มีลายพอจะรอต่อ แล้วใช้ค่าปกติเมื่อขยับเกิน 15°)
        if (!calibrated) {
            val s = shiftBetween(refSmall, smallGray(frame))
            val big = abs(d) >= Math.toRadians(15.0)
            if (s == null && !big) return true
            if (s != null) {
                // กล้องหมุนไปทางบวกต้องทำให้ภาพ "เลื่อนไปทางซ้าย" (s < 0) ถ้าตรงกันข้าม แปลว่าทิศเซนเซอร์กลับด้าน
                flip = if ((s < 0) == (d > 0)) 1 else -1
            }
            calibrated = true
        }

        val dp = flip * d
        val sgn = if (dp > 0) 1 else -1
        if (dirP == 0) dirP = sgn
        if (sgn != dirP) return true // ขยับย้อนกลับ ไม่เอา (ไม่อัปเดตตำแหน่งอ้างอิง)
        lastYaw = y
        cum += dp

        val moved = abs(dp) * fPx
        val sw = min(frameW, max(16, (moved * 1.5).roundToInt()))
        val overlap = max(0, sw - moved.roundToInt())
        val center = (cum * fPx).roundToInt()
        addStrip(frame, center, sw, overlap, dirP > 0)

        sweptDegrees = Math.toDegrees(abs(cum)).toFloat()
        val minX = strips.minOf { it.x }
        val maxX = strips.maxOf { it.x + it.bmp.width }
        return (maxX - minX) < maxWidthPx && sweptDegrees < maxDegrees
    }

    private fun addStrip(frame: Bitmap, centerX: Int, width: Int, ramp: Int, movingRight: Boolean) {
        val sw = min(width, frame.width)
        val sx = (frame.width - sw) / 2
        val sub = Bitmap.createBitmap(frame, sx, 0, sw, frame.height)
        val strip = sub.copy(Bitmap.Config.ARGB_8888, true)
        if (sub !== frame) sub.recycle()
        strip.setHasAlpha(true)
        // ไล่ความโปร่งที่ขอบด้านที่ติดกับแถบก่อนหน้า (ซ้ายถ้ากวาดไปขวา / ขวาถ้ากวาดไปซ้าย)
        applyRamp(strip, min(ramp, sw / 2), movingRight)
        strips.add(Strip(strip, centerX - sw / 2))
    }

    private fun applyRamp(b: Bitmap, ramp: Int, leftEdge: Boolean) {
        if (ramp < 2) return
        val w = b.width
        val h = b.height
        val px = IntArray(w * h)
        b.getPixels(px, 0, w, 0, 0, w, h)
        for (i in 0 until ramp) {
            val a = (255.0 * (i + 1) / (ramp + 1)).toInt()
            val col = if (leftEdge) i else w - 1 - i
            for (yy in 0 until h) {
                val idx = yy * w + col
                px[idx] = (a shl 24) or (px[idx] and 0xFFFFFF)
            }
        }
        b.setPixels(px, 0, w, 0, 0, w, h)
    }

    /** ภาพเทาขนาดเล็ก (กว้าง 128px) เฉพาะแถบกลางตามแนวตั้ง ใช้เทียบการเลื่อนของภาพ */
    private fun smallGray(frame: Bitmap): IntArray {
        val sw = 128
        val sh = max(16, sw * frame.height / frame.width)
        val s = Bitmap.createScaledBitmap(frame, sw, sh, true)
        val px = IntArray(sw * sh)
        s.getPixels(px, 0, sw, 0, 0, sw, sh)
        if (s !== frame) s.recycle()
        // ใช้เฉพาะช่วง 40%-60% ของความสูง (แถบกลาง) ต่อกันเป็นอาร์เรย์เดียวความกว้าง 128 คูณ 8 แถว
        val rows = 8
        val y0 = (sh * 0.4).toInt()
        val out = IntArray(sw * rows)
        for (r in 0 until rows) {
            for (x in 0 until sw) {
                val p = px[min(sh - 1, y0 + r) * sw + x]
                out[r * sw + x] = ((p shr 16 and 255) * 30 + (p shr 8 and 255) * 59 + (p and 255) * 11) / 100
            }
        }
        return out
    }

    /** หาว่าเฟรม b เลื่อนจาก a กี่พิกเซล (ที่ความกว้าง 128) คืน null ถ้ายังแยกไม่ออก (ลายภาพน้อย/เลื่อนน้อยเกินไป) */
    private fun shiftBetween(a: IntArray?, b: IntArray): Int? {
        if (a == null || a.size != b.size) return null
        val w = 128
        val rows = a.size / w
        val range = 40
        var best = Int.MAX_VALUE.toLong()
        var bestS = 0
        var zero = 0L
        for (s in -range..range) {
            var sad = 0L
            var n = 0
            for (r in 0 until rows) {
                for (x in max(0, -s) until min(w, w - s)) {
                    sad += abs(a[r * w + x] - b[r * w + x + s])
                    n++
                }
            }
            if (n < w / 2) continue
            val norm = sad * 1000L / n
            if (s == 0) zero = norm
            if (norm < best) {
                best = norm
                bestS = s
            }
        }
        // ต้องเลื่อนอย่างน้อย 2 พิกเซล และดีกว่าการไม่เลื่อนอย่างชัดเจน
        if (abs(bestS) < 2 || best >= zero * 85 / 100) return null
        return bestS
    }

    /** ประกอบภาพสุดท้าย (ต้องเรียกนอกเธรดหลัก) คืน null ถ้ากวาดน้อยเกินไป */
    fun finish(): Bitmap? {
        if (strips.size < 3) {
            discard()
            return null
        }
        val minX = strips.minOf { it.x }
        val maxX = strips.maxOf { it.x + it.bmp.width }
        val width = maxX - minX
        val out = Bitmap.createBitmap(width, frameH, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(out)
        canvas.drawColor(Color.BLACK)
        for (s in strips) canvas.drawBitmap(s.bmp, (s.x - minX).toFloat(), 0f, null)
        discard()
        return out
    }

    fun discard() {
        for (s in strips) s.bmp.recycle()
        strips.clear()
    }
}
