package com.example.procamera

import android.Manifest
import android.content.ContentValues
import android.content.Context
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.CamcorderProfile
import android.media.MediaMetadataRetriever
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.provider.MediaStore
import android.util.Range
import android.util.Rational
import android.util.Size
import android.view.OrientationEventListener
import android.view.HapticFeedbackConstants
import android.view.View
import android.view.Surface
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.FocusMeteringAction
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.core.UseCaseGroup
import androidx.camera.core.ViewPort
import androidx.camera.core.resolutionselector.AspectRatioStrategy
import androidx.camera.core.resolutionselector.ResolutionSelector
import androidx.camera.core.resolutionselector.ResolutionStrategy
import androidx.camera.extensions.ExtensionMode
import androidx.camera.extensions.ExtensionsManager
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.FallbackStrategy
import androidx.camera.video.MediaStoreOutputOptions
import androidx.camera.video.Quality
import androidx.camera.video.QualitySelector
import androidx.camera.video.Recorder
import androidx.camera.video.Recording
import androidx.camera.video.VideoCapture
import androidx.camera.video.VideoRecordEvent
import androidx.camera.view.PreviewView
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.requiredSize
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.FlashAuto
import androidx.compose.material.icons.rounded.FlashOff
import androidx.compose.material.icons.rounded.FlashOn
import androidx.compose.material.icons.rounded.FlipCameraAndroid
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.WbSunny
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.concurrent.Executors
import java.util.Locale
import java.util.concurrent.TimeUnit
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlin.math.roundToInt

// =====================================================================
//  ขั้นที่ 1: หน้ากล้องหลัก ออกแบบใหม่ตามพฤติกรรมของแอปกล้อง iPhone (iOS 26)
//  ทำแล้ว: พรีวิว ถ่ายภาพ สลับกล้อง แฟลช ซูม แตะโฟกัส บีบนิ้วซูม
//          ตั้งเวลา สัดส่วนภาพ ชดเชยแสง (ผ่านแผงปัดขึ้น QuickPanel) ภาพย่อ
//  ขั้นที่ 2: โหมดวิดีโอ (อัด/หยุด, เวลาที่อัด, ไฟฉายแทนแฟลช, บันทึกลง Movies/ProCamera)
//  ขั้นที่ 3: แถบโหมดครบ 6 โหมดแบบ iPhone (ปาโนรามา/ไทม์แลปส์/สโลโมชัน/วิดีโอ/ภาพถ่าย/ภาพเหมือน)
//          Portrait ใช้ CameraX Extensions (BOKEH) จริงถ้าเครื่องรองรับ ไม่งั้นถ่ายภาพปกติ
//          สไตล์ภาพ (มาตรฐาน/สด/อุ่น/เย็น/ขาวดำ) มีผลจริงทั้งพรีวิวและไฟล์ที่บันทึก
//  ขั้นที่ 4: ไทม์แลปส์ประกอบเป็น MP4 อัตโนมัติ (TimelapseEncoder), สโลโมชัน retime ให้เล่นช้าจริง
//          (SlowMotionRetimer), จัดการสิทธิ์กล้อง/ไมค์ดีขึ้น, มีไอคอนแอป
//  ขั้นที่ 5: แก้บั๊ก PreviewView ใช้ SurfaceView (PERFORMANCE) ทำให้ฟิลเตอร์สไตล์ภาพไม่โชว์ในพรีวิวสด
//          เปลี่ยนเป็น COMPATIBLE (TextureView) แล้ว, เพิ่มการขอกันสั่น OIS/EIS จริงตอนอัดวิดีโอ/
//          สโลโมชัน (เลือก OIS ก่อนถ้ามี ไม่มีก็ใช้ EIS), แก้ภาพย่อกระพริบระหว่างไทม์แลปส์,
//          เพิ่มบรรทัดกันสั่นในหน้าข้อมูลกล้องของเครื่อง
//  หมายเหตุความซื่อสัตย์: พาโนรามาตอนนี้เป็นเวอร์ชันต้นแบบ (ถ่ายภาพเดียวมุมกว้างสุดที่เครื่องมี
//          ยังไม่ต่อภาพจากการกวาดกล้องแบบ iPhone จริง) / สไลเดอร์ความแรงเบลอฉากหลัง (BLUR) ในโหมด
//          ภาพเหมือนยังเป็นแค่ UI ตัวเบลอจริงมาจากฮาร์ดแวร์ (CameraX Extensions BOKEH) ซึ่งไม่มี API
//          ให้ปรับความแรงเป็นระดับ / ซูม 0.5-10x เป็นลิสต์ตายตัว ไม่ได้อิงจากเลนส์จริงของเครื่อง /
//          ยังไม่มี RAW, Live Photo, Cinematic mode
//  ขั้นที่ 6 (ทำตามคำขอ): ค่าเริ่มต้นของสไตล์ภาพเปลี่ยนเป็น "สด" (VIVID) ทันทีที่เปิดแอป / เพิ่มสไตล์
//          "ฟิล์ม" จำลองโทนแนวฟิล์มญี่ปุ่นยอดนิยม (โทนสีเท่านั้น ไม่ใช่โปรไฟล์สีลิขสิทธิ์จริง) / แก้บั๊ก
//          องศาภาพผิด: เพิ่ม OrientationEventListener อ่านองศาการหมุนเครื่องจริงตลอดเวลา (แอปยังล็อก UI
//          แนวตั้งเหมือนเดิม) แล้วสั่ง targetRotation ของ ImageCapture/VideoCapture ให้ตรงเสมอ ไม่ว่าจะถือ
//          เครื่องแนวตั้ง/แนวนอน/ตะแคงซ้ายขวา / ขยาย EDGE_MODE กับ NOISE_REDUCTION แบบ HIGH_QUALITY (คมชัด
//          สูงสุดที่ Camera2 เปิดให้) ให้ครอบคลุมทุกโหมดถ่ายภาพนิ่ง ไม่ใช่แค่โหมดภาพถ่ายธรรมดา / เพิ่มตัว
//          กรองคมชัด (unsharp mask ซอฟต์แวร์) ทาลงไฟล์ภาพที่บันทึกจริงเสมอทุกภาพ เพิ่มเติมจากที่ขอฮาร์ดแวร์
//          ไปแล้ว / เพิ่มการฝังสไตล์ภาพลงไฟล์วิดีโอจริงด้วย (VideoColorEffect.kt ใช้ CameraX Effects API +
//          OpenGL ES) ก่อนหน้านี้สไตล์มีผลแค่พรีวิวกับภาพนิ่ง — ส่วนนี้ซับซ้อนสุดและยังไม่เคยคอมไพล์ทดสอบจริง
//          เสี่ยง build ไม่ผ่านสูงสุดในทุกจุดที่แก้รอบนี้ ถ้า build พังให้ดู error จาก GitHub Actions ก่อน
// =====================================================================

private val CamYellow = Color(0xFFFFD60A)

private enum class CamMode { PANO, SLOMO, VIDEO, PHOTO, PORTRAIT }

// ลำดับโหมดในแถบล่าง เรียงแบบเดียวกับแอปกล้อง iPhone
private val ModeOrder = listOf(
    CamMode.PANO to "พาโนรามา",
    CamMode.SLOMO to "สโลโมชัน",
    CamMode.VIDEO to "วิดีโอ",
    CamMode.PHOTO to "ภาพถ่าย",
    CamMode.PORTRAIT to "ภาพเหมือน"
)

@Composable
fun CameraScreen() {
    val context = LocalContext.current
    val hostView = LocalView.current
    // ประมวลผลภาพทีละใบ (กันหน่วยความจำเต็มถ้ากดถ่ายรัวๆ) และเอฟเฟกต์กะพริบตอนถ่ายแบบ iPhone
    val photoProcessMutex = remember { Mutex() }
    var shutterFlashTick by remember { mutableIntStateOf(0) }
    val shutterFlashAlpha = remember { Animatable(0f) }
    LaunchedEffect(shutterFlashTick) {
        if (shutterFlashTick > 0) {
            shutterFlashAlpha.snapTo(0.8f)
            shutterFlashAlpha.animateTo(0f, tween(180, easing = FastOutSlowInEasing))
        }
    }
    val lifecycleOwner = LocalLifecycleOwner.current
    val scope = rememberCoroutineScope()
    val mainExecutor = remember { ContextCompat.getMainExecutor(context) }
    val previewView = remember {
        PreviewView(context).apply {
            scaleType = PreviewView.ScaleType.FILL_CENTER
            // ต้องใช้ COMPATIBLE (TextureView) ไม่ใช่ PERFORMANCE (SurfaceView) ค่าเริ่มต้น
            // เพราะ SurfaceView ไม่ผ่านกระบวนการวาดปกติของ View จึงทำให้ colorFilter ของสไตล์ภาพ
            // (styleColorFilter ด้านล่าง) ไม่มีผลกับพรีวิวสดเลย แม้โค้ดจะรันไม่ error ก็ตาม
            implementationMode = PreviewView.ImplementationMode.COMPATIBLE
        }
    }

    // ---- องศาการหมุนของเครื่องจริง (แก้บั๊กภาพเอียง/หมุนผิด) ----
    // แอปนี้ล็อก UI ไว้แนวตั้งเสมอ (AndroidManifest: screenOrientation="portrait") ทำให้ display rotation
    // ของระบบไม่เปลี่ยนตามการหมุนเครื่องจริงเลย ถ้าไม่ทำอะไรเพิ่ม ภาพที่ถ่ายตอนถือเครื่องแนวนอน/ตะแคง
    // จะถูกบันทึก EXIF ผิดองศา (ภาพเอียง/หัวกลับตอนเปิดดู) จึงต้องอ่านองศาจริงจากเซนเซอร์การหมุนเครื่อง
    // (ไม่ใช่จาก UI) แล้วสั่ง targetRotation ของ ImageCapture/VideoCapture ตรง ๆ ทุกครั้งที่เปลี่ยน
    var deviceRotation by remember { mutableIntStateOf(Surface.ROTATION_0) }
    DisposableEffect(Unit) {
        val listener = object : OrientationEventListener(context) {
            override fun onOrientationChanged(orientation: Int) {
                if (orientation == ORIENTATION_UNKNOWN) return
                val rotation = when (orientation) {
                    in 45 until 135 -> Surface.ROTATION_270
                    in 135 until 225 -> Surface.ROTATION_180
                    in 225 until 315 -> Surface.ROTATION_90
                    else -> Surface.ROTATION_0
                }
                if (rotation != deviceRotation) deviceRotation = rotation
            }
        }
        if (listener.canDetectOrientation()) listener.enable()
        onDispose { listener.disable() }
    }

    var lens by remember { mutableIntStateOf(CameraSelector.LENS_FACING_BACK) }
    var camera by remember { mutableStateOf<Camera?>(null) }
    var imageCapture by remember { mutableStateOf<ImageCapture?>(null) }
    var flashMode by remember { mutableIntStateOf(ImageCapture.FLASH_MODE_OFF) }

    var minZoom by remember { mutableFloatStateOf(1f) }
    var maxZoom by remember { mutableFloatStateOf(1f) }
    var zoom by remember { mutableFloatStateOf(1f) }

    var settings by remember { mutableStateOf(loadSettings(context)) }
    var showSettings by remember { mutableStateOf(false) }
    var supportedQualities by remember { mutableStateOf<List<Quality>>(emptyList()) }
    var maxFps by remember { mutableIntStateOf(30) }
    var manualRanges by remember { mutableStateOf<ManualRanges?>(null) }
    var bindCount by remember { mutableIntStateOf(0) }
    var aeLocked by remember { mutableStateOf(false) }
    var focusTick by remember { mutableIntStateOf(0) }
    var qualityModes by remember { mutableStateOf<QualityModes?>(null) }
    var extensionsInfo by remember { mutableStateOf("กำลังตรวจ...") }
    // true เมื่อเครื่องรองรับ Portrait/Bokeh จริงผ่าน CameraX Extensions สำหรับกล้องตัวที่ใช้อยู่
    var portraitAvailable by remember { mutableStateOf(false) }
    // ความสามารถเพิ่มเติมของกล้อง (สมดุลสีขาว/โฟกัสมือ), สถานะพักอัดวิดีโอ, ผลวิเคราะห์ภาพสด (ฮิสโตแกรม/พีคกิ้ง/ซีบรา)
    var extraCaps by remember { mutableStateOf<ExtraCaps?>(null) }
    var paused by remember { mutableStateOf(false) }
    var analysisHist by remember { mutableStateOf<IntArray?>(null) }
    var analysisOverlay by remember { mutableStateOf<Bitmap?>(null) }
    var showOnboarding by remember { mutableStateOf(!settings.onboarded) }
    var showLog by remember { mutableStateOf(false) }
    val analysisExecutor = remember { Executors.newSingleThreadExecutor() }
    val analyzer = remember {
        LumaAnalyzer { f ->
            mainExecutor.execute {
                analysisHist = f.histogram
                analysisOverlay = f.overlay
            }
        }
    }
    DisposableEffect(Unit) { onDispose { analysisExecutor.shutdown() } }

    var panelExpanded by remember { mutableStateOf(false) }
    var panel by remember {
        mutableStateOf(
            QuickPanelState(
                aspectLabel = "4:3",
                evIndex = if (settings.preserveExposure) settings.lastEv else 0
            )
        )
    }

    var countdown by remember { mutableStateOf<Int?>(null) }
    var countdownJob by remember { mutableStateOf<Job?>(null) }

    var focusPoint by remember { mutableStateOf<Offset?>(null) }
    var focusVisible by remember { mutableStateOf(false) }

    var lastUri by remember { mutableStateOf<Uri?>(null) }
    var thumb by remember { mutableStateOf<Bitmap?>(null) }
    var showInfo by remember { mutableStateOf(false) }
    var showViewer by remember { mutableStateOf(false) }
    // พาโนรามาแบบกวาดกล้อง: session ที่กำลังเก็บเฟรม / องศาที่กวาดไปแล้ว / กำลังรวมภาพ
    var panoSession by remember { mutableStateOf<PanoramaSession?>(null) }
    var panoJob by remember { mutableStateOf<Job?>(null) }
    var panoDeg by remember { mutableFloatStateOf(0f) }
    var panoSaving by remember { mutableStateOf(false) }
    // กล่องข้อความแจ้งผลที่ค้างจนกว่าผู้ใช้จะกดปิด (เช่น สาเหตุที่สโลโมชันทำไม่สำเร็จ)
    var noteDialog by remember { mutableStateOf<String?>(null) }
    var mode by remember {
        mutableStateOf(if (settings.preserveMode && settings.lastMode == 1) CamMode.VIDEO else CamMode.PHOTO)
    }
    var videoCapture by remember { mutableStateOf<VideoCapture<Recorder>?>(null) }
    var recording by remember { mutableStateOf<Recording?>(null) }
    var recordSeconds by remember { mutableLongStateOf(0L) }
    val usesVideoPipeline = mode == CamMode.VIDEO || mode == CamMode.SLOMO
    // โหมดวิดีโอ/สโลโมชันใช้ 16:9 เสมอ
    val effAspect = if (usesVideoPipeline) "16:9" else panel.aspectLabel
    // สไตล์ภาพที่จะฝังลงไฟล์วิดีโอจริง (มีผลเฉพาะตอนอยู่โหมดวิดีโอ/สโลโมชันเท่านั้น กันไม่ให้การเปลี่ยน
    // สไตล์ตอนอยู่โหมดภาพถ่ายไปสั่งผูกกล้องใหม่โดยไม่จำเป็น)
    val videoEffectStyle = if (usesVideoPipeline) panel.style else PhotoStyle.STANDARD
    // เครื่องมือช่วยถ่าย (ฮิสโตแกรม/พีคกิ้ง/ซีบรา) ใช้ ImageAnalysis เพิ่มอีก 1 use case จึงเปิดเฉพาะโหมดที่ปลอดภัย
    // (ไม่ใช้กับสโลโมชัน/พาโนรามา) ถ้าเครื่องผูกไม่ได้ ระบบจะถอยกลับไปผูกแบบไม่มีตัววิเคราะห์เอง
    val analysisWanted = (settings.histogram || settings.peaking || settings.zebra) &&
        (mode == CamMode.PHOTO || mode == CamMode.PORTRAIT || mode == CamMode.VIDEO)
    LaunchedEffect(settings.histogram, settings.peaking, settings.zebra, lens) {
        analyzer.config = AnalysisConfig(
            histogram = settings.histogram,
            peaking = settings.peaking,
            zebra = settings.zebra,
            mirror = lens == CameraSelector.LENS_FACING_FRONT
        )
    }
    LaunchedEffect(analysisWanted) {
        if (!analysisWanted) {
            analysisHist = null
            analysisOverlay = null
        }
    }

    // ---- ผูกกล้อง: ทำใหม่ทุกครั้งที่สลับกล้องหรือเปลี่ยนสัดส่วนภาพ ----
    LaunchedEffect(lens, effAspect, mode, settings.videoQuality, settings.videoFps, settings.maxResolution, videoEffectStyle, analysisWanted) {
        try {
            val future = ProcessCameraProvider.getInstance(context)
            val provider = suspendCancellableCoroutine<ProcessCameraProvider> { cont ->
                future.addListener({ cont.resume(future.get()) }, mainExecutor)
            }

            val strategy = if (effAspect == "16:9") {
                AspectRatioStrategy.RATIO_16_9_FALLBACK_AUTO_STRATEGY
            } else {
                AspectRatioStrategy.RATIO_4_3_FALLBACK_AUTO_STRATEGY
            }
            val selector = ResolutionSelector.Builder().setAspectRatioStrategy(strategy).build()
            // ภาพนิ่ง: ถ้าเปิดตัวเลือก 'ความละเอียดสูงสุด' จะขอใช้โหมดความละเอียดสูงของเซนเซอร์ (ถ้าเครื่องเปิดให้)
            // ค่าเริ่มต้น: ถ่ายที่ราว 12 ล้านพิกเซล (แบบเดียวกับ iPhone) เพราะชัตเตอร์ไวกว่ามาก ประมวลผลปรับ
            // คมชัดทันเวลา และภาพจากเซนเซอร์ที่รวมพิกเซลมักสะอาด/คมกว่าที่ความละเอียดสูงสุดในที่แสงน้อย
            // ถ้าอยากได้ความละเอียดสูงสุดจริงๆ ให้เปิดสวิตช์ "ความละเอียดสูงสุดที่เครื่องอนุญาต" ในตั้งค่า
            val stillSelector = ResolutionSelector.Builder()
                .setAspectRatioStrategy(strategy)
                .apply {
                    if (settings.maxResolution) {
                        setAllowedResolutionMode(ResolutionSelector.PREFER_HIGHER_RESOLUTION_OVER_CAPTURE_RATE)
                    } else {
                        val target = if (effAspect == "16:9") Size(4000, 2250) else Size(4000, 3000)
                        setResolutionStrategy(
                            ResolutionStrategy(target, ResolutionStrategy.FALLBACK_RULE_CLOSEST_HIGHER_THEN_LOWER)
                        )
                    }
                }
                .build()

            val preview = Preview.Builder().setResolutionSelector(selector).build()
            preview.surfaceProvider = previewView.surfaceProvider
            // ViewPort ทำให้ภาพ/วิดีโอที่บันทึกถูกครอปตรงกับที่เห็นในพรีวิว
            val (w, h) = when (effAspect) {
                "16:9" -> 9 to 16
                "1:1" -> 1 to 1
                else -> 3 to 4
            }
            val groupBuilder = UseCaseGroup.Builder()
                .addUseCase(preview)
                .setViewPort(ViewPort.Builder(Rational(w, h), Surface.ROTATION_0).build())

            // ---- เช็คส่วนขยายกล้อง (HDR/กลางคืน/โบเก้ ฯลฯ) ก่อนผูกกล้อง เพื่อเลือกกล้องแบบมีโบเก้ให้โหมดภาพเหมือน ----
            val baseSelector = CameraSelector.Builder().requireLensFacing(lens).build()
            val extManager = try {
                val extFuture = ExtensionsManager.getInstanceAsync(context, provider)
                suspendCancellableCoroutine<ExtensionsManager> { cont ->
                    extFuture.addListener({
                        try {
                            cont.resume(extFuture.get())
                        } catch (t: Exception) {
                            cont.resumeWithException(t)
                        }
                    }, mainExecutor)
                }
            } catch (t: Exception) {
                null
            }
            val bokehAvailable = extManager?.isExtensionAvailable(baseSelector, ExtensionMode.BOKEH) == true
            portraitAvailable = bokehAvailable
            // โหมดภาพเหมือนเบลอฉากหลังเองด้วยแอป (ML Kit) จึงใช้กล้องปกติ ไม่ผูกส่วนขยาย Bokeh ของเครื่อง
            val finalSelector = baseSelector

            // โหมดภาพถ่าย/ภาพเหมือน/พาโนรามา = พรีวิว+ถ่ายภาพ / โหมดวิดีโอ/สโลโมชัน = พรีวิว+อัดวิดีโอ
            var capture: ImageCapture? = null
            var video: VideoCapture<Recorder>? = null
            if (usesVideoPipeline) {
                val vq = when (settings.videoQuality) {
                    0 -> Quality.UHD
                    2 -> Quality.HD
                    else -> Quality.FHD
                }
                val recorder = Recorder.Builder()
                    .setQualitySelector(
                        QualitySelector.from(vq, FallbackStrategy.lowerQualityOrHigherThan(vq))
                    )
                    .build()
                val vcBuilder = VideoCapture.Builder(recorder)
                // สโลโมชัน: ขอเฟรมเรตสูงสุดที่รอบก่อนหน้าตรวจเจอ (ไฟล์จะช้าลงเองถ้าเปิดด้วยแอปที่รู้เฟรมเรตจริง)
                val targetFps = when {
                    mode == CamMode.SLOMO && maxFps >= 120 -> 120
                    mode == CamMode.SLOMO && maxFps >= 60 -> 60
                    settings.videoFps >= 60 -> 60
                    else -> 0
                }
                if (targetFps > 0) vcBuilder.setTargetFrameRate(Range(targetFps, targetFps))
                vcBuilder.setTargetRotation(deviceRotation)
                val vc = vcBuilder.build()
                video = vc
                groupBuilder.addUseCase(vc)
                // ฝังสไตล์ภาพลงไฟล์วิดีโอจริง — ปิดไว้ก่อนชั่วคราว! ทดสอบจริงแล้วพบว่าทำให้วิดีโอ
                // ออกมาจอดำทั้งคลิป (โค้ด OpenGL ส่วนนี้ยังมีบั๊กที่ยังไม่ได้ไล่แก้จนจบ) เลือกให้วิดีโอ
                // อัดได้ปกติก่อนเป็นอันดับแรก ไว้ค่อยกลับมาทำฟิลเตอร์วิดีโอใหม่แบบระวังกว่านี้ทีหลัง
                // if (videoEffectStyle != PhotoStyle.STANDARD) {
                //     createVideoStyleEffect(videoEffectStyle)?.let { groupBuilder.addEffect(it) }
                // }
            } else {
                val cap = ImageCapture.Builder()
                    .setResolutionSelector(stillSelector)
                    // เน้นชัตเตอร์ไว (ไม่รอปรับโฟกัส/แสงซ้ำก่อนถ่ายทุกครั้ง) แล้วชดเชยความคมด้วยตัวปรับภาพคมชัด
                    // ที่ทำก่อนบันทึกลงเครื่อง (ดู processAndSave) ไฟล์ชั่วคราวเก็บคุณภาพสูงสุดก่อนประมวลผล
                    .setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY)
                    .setJpegQuality(100)
                    .setFlashMode(flashMode)
                    .setTargetRotation(deviceRotation)
                    .build()
                capture = cap
                groupBuilder.addUseCase(cap)
            }

            provider.unbindAll()
            var analysisUseCase: ImageAnalysis? = null
            if (analysisWanted) {
                val aTarget = if (effAspect == "16:9") Size(1280, 720) else Size(960, 720)
                val aSel = ResolutionSelector.Builder()
                    .setAspectRatioStrategy(strategy)
                    .setResolutionStrategy(
                        ResolutionStrategy(aTarget, ResolutionStrategy.FALLBACK_RULE_CLOSEST_HIGHER_THEN_LOWER)
                    )
                    .build()
                val ia = ImageAnalysis.Builder()
                    .setResolutionSelector(aSel)
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                    .build()
                ia.setAnalyzer(analysisExecutor, analyzer)
                analysisUseCase = ia
                groupBuilder.addUseCase(ia)
            }
            val cam = try {
                provider.bindToLifecycle(lifecycleOwner, finalSelector, groupBuilder.build())
            } catch (e: IllegalArgumentException) {
                if (analysisUseCase == null) throw e
                // เครื่องนี้ผูก use case รวมกันไม่ได้ (เช่น 4K + วิเคราะห์ภาพ) -> ผูกใหม่โดยไม่มีตัววิเคราะห์
                CrashLog.log("ผูกกล้องพร้อมตัววิเคราะห์ภาพไม่ได้ ถอยกลับแบบปกติ", e)
                Toast.makeText(context, "เครื่องนี้เปิดเครื่องมือช่วยถ่ายพร้อมโหมดนี้ไม่ได้", Toast.LENGTH_SHORT).show()
                val plain = UseCaseGroup.Builder()
                    .addUseCase(preview)
                    .setViewPort(ViewPort.Builder(Rational(w, h), Surface.ROTATION_0).build())
                capture?.let { plain.addUseCase(it) }
                video?.let { plain.addUseCase(it) }
                provider.bindToLifecycle(lifecycleOwner, finalSelector, plain.build())
            }
            camera = cam
            imageCapture = capture
            videoCapture = video
            supportedQualities = QualitySelector.getSupportedQualities(cam.cameraInfo)
            maxFps = cam.cameraInfo.supportedFrameRateRanges.maxOfOrNull { it.upper } ?: 30
            manualRanges = runCatching { readManualRanges(cam) }.getOrNull()
            qualityModes = runCatching { readQualityModes(cam) }.getOrNull()
            extraCaps = runCatching { readExtraCaps(cam) }.getOrNull()
            bindCount++

            val zs = cam.cameraInfo.zoomState.value
            minZoom = zs?.minZoomRatio ?: 1f
            maxZoom = zs?.maxZoomRatio ?: 1f
            zoom = zs?.zoomRatio ?: 1f
            // โหมดพาโนรามา (ต้นแบบ): กางกล้องไปมุมกว้างสุดที่เครื่องมีให้อัตโนมัติ
            if (mode == CamMode.PANO) {
                camera?.cameraControl?.setZoomRatio(minZoom)
            }

            extensionsInfo = if (extManager != null) {
                listOf(
                    "HDR" to ExtensionMode.HDR,
                    "กลางคืน" to ExtensionMode.NIGHT,
                    "อัตโนมัติ" to ExtensionMode.AUTO,
                    "โบเก้" to ExtensionMode.BOKEH,
                    "แต่งหน้า" to ExtensionMode.FACE_RETOUCH
                ).joinToString("  ") { (n, m) ->
                    n + " " + (if (extManager.isExtensionAvailable(baseSelector, m)) "ได้" else "ไม่ได้")
                }
            } else {
                "ตรวจไม่ได้"
            }
        } catch (e: Exception) {
            CrashLog.log("เปิดกล้องไม่ได้", e)
            Toast.makeText(context, "เปิดกล้องไม่ได้: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    // อัปเดตองศาการบันทึกทุกครั้งที่เครื่องหมุน หรือทุกครั้งที่ผูกกล้องใหม่ (imageCapture/videoCapture ตัวใหม่)
    // เพื่อให้ภาพ/วิดีโอที่ได้อยู่ในแนวตั้ง/แนวนอน/ตะแคงถูกต้องตามที่ถือเครื่องจริงเสมอ
    LaunchedEffect(deviceRotation, imageCapture, videoCapture) {
        imageCapture?.targetRotation = deviceRotation
        videoCapture?.targetRotation = deviceRotation
    }
    LaunchedEffect(flashMode, imageCapture) { imageCapture?.flashMode = flashMode }
    // ในโหมดวิดีโอ/สโลโมชัน ปุ่มแฟลชทำหน้าที่เปิด/ปิดไฟฉาย
    LaunchedEffect(mode, flashMode, camera) {
        val usesVideo = mode == CamMode.VIDEO || mode == CamMode.SLOMO
        camera?.cameraControl?.enableTorch(usesVideo && flashMode == ImageCapture.FLASH_MODE_ON)
    }
    DisposableEffect(Unit) { onDispose { recording?.stop() } }
    // ออกจากโหมดพาโนรามา (หรือปิดแอป) ระหว่างกวาด: เลิกเก็บเฟรมและปล่อยเซนเซอร์เสมอ
    DisposableEffect(mode) {
        onDispose {
            panoJob?.cancel()
            panoJob = null
            panoSession?.let { it.stopSensors(); it.discard() }
            panoSession = null
        }
    }
    // เปิดแอปมา: ตั้งภาพย่อเป็นไฟล์ล่าสุดที่เคยบันทึกไว้ (จะได้กดเปิดหน้าดูภาพได้เลย)
    LaunchedEffect(Unit) {
        if (lastUri == null) lastUri = withContext(Dispatchers.IO) { latestMediaUri(context) }
    }
    LaunchedEffect(mode, panel.evIndex) {
        val n = settings.copy(lastMode = if (mode == CamMode.VIDEO) 1 else 0, lastEv = panel.evIndex)
        if (n != settings) {
            settings = n
            saveSettings(context, n)
        }
    }
    LaunchedEffect(panel.evIndex, bindCount) {
        camera?.cameraControl?.setExposureCompensationIndex(panel.evIndex)
    }
    // แมนนวล ISO/ชัตเตอร์ (ใช้ค่าที่กล้องรองรับเท่านั้น)
    LaunchedEffect(bindCount, mode, panel.manualOn, panel.iso, panel.shutterNs, panel.wbIndex, panel.focusOn, panel.focus) {
        val cam = camera ?: return@LaunchedEffect
        val r = manualRanges
        val iso = if (r != null) panel.iso.coerceIn(r.iso.first, r.iso.last) else panel.iso
        val shutter = if (r != null) panel.shutterNs.coerceIn(r.shutterNs.first, r.shutterNs.last) else panel.shutterNs
        val q = qualityModes
        // ขอคุณภาพความคมชัด/ลดสัญญาณรบกวนสูงสุด (EDGE_MODE / NOISE_REDUCTION_MODE = HIGH_QUALITY)
        // ในทุกโหมดที่ถ่ายภาพนิ่ง (ภาพถ่าย/ภาพเหมือน/พาโนรามา/ไทม์แลปส์) ไม่ใช่แค่โหมดภาพถ่ายธรรมดา
        // เพราะนี่คือค่าสูงสุดที่ Camera2 API เปิดให้ปรับได้แล้วในทุกกรณีที่ไม่ใช่วิดีโอ
        val stillPhoto = !usesVideoPipeline
        val caps = extraCaps
        val wbMode = WbPresets.getOrNull(panel.wbIndex)
            ?.takeIf { it.kelvin != 0 && caps?.awbModes?.contains(it.awbMode) == true }
            ?.awbMode
        val focusD = if (panel.focusOn && caps != null && caps.minFocusDiopter > 0f) {
            panel.focus * caps.minFocusDiopter
        } else null
        runCatching {
            applyCaptureOptions(
                cam,
                panel.manualOn,
                iso,
                shutter,
                edgeHq = stillPhoto && q?.edgeHq == true,
                noiseHq = stillPhoto && q?.noiseHq == true,
                stabilizeVideo = mode == CamMode.VIDEO || mode == CamMode.SLOMO,
                awbMode = wbMode,
                focusDiopter = focusD
            )
        }
    }

    // กรอบโฟกัสหายเองหลัง 3 วินาที (ต่ออายุทุกครั้งที่แตะหรือลากปรับแสง) ถ้าล็อกไว้จะไม่หาย
    LaunchedEffect(focusTick) {
        if (focusPoint != null) {
            focusVisible = true
            if (!aeLocked) {
                delay(3000)
                focusVisible = false
            }
        }
    }
    LaunchedEffect(lastUri) {
        val uri = lastUri ?: return@LaunchedEffect
        thumb = withContext(Dispatchers.IO) {
            runCatching { context.contentResolver.loadThumbnail(uri, Size(256, 256), null) }.getOrNull()
        }
    }

    // ---- ถ่ายภาพ ----
    fun takePhoto(
        relativePath: String = "Pictures/ProCamera",
        onSaved: (Uri) -> Unit = {}
    ) {
        val cap = imageCapture ?: return
        if (!hasFreeSpace(context, 100)) {
            Toast.makeText(context, "พื้นที่เก็บข้อมูลเหลือน้อยเกินไป กรุณาลบไฟล์ก่อน", Toast.LENGTH_LONG).show()
            return
        }
        val name = SimpleDateFormat("yyyyMMdd_HHmmss_SSS", Locale.US).format(System.currentTimeMillis())
        val metadata = ImageCapture.Metadata().apply {
            isReversedHorizontal = lens == CameraSelector.LENS_FACING_FRONT && settings.mirrorFront
        }
        val styleAtCapture = panel.style
        // ตัวเลือกหลังถ่าย: ความคมชัด / ตราวันที่ / GPS (อ่านค่า ณ ตอนกดชัตเตอร์)
        val postAtCapture = PhotoPostOptions(
            sharpen = sharpenAmount(settings.sharpness),
            stamp = settings.dateStamp,
            location = if (settings.geotag) lastKnownLocation(context) else null
        )
        // โหมดภาพเหมือน: ส่งค่าสไลเดอร์ (0..1) ไปเบลอฉากหลังเองหลังถ่าย โหมดอื่นเป็น null = ไม่เบลอ
        val blurAtCapture = if (mode == CamMode.PORTRAIT) panel.blur else null

        // เอฟเฟกต์กะพริบตอนกดถ่าย (จอมืดวูบสั้นๆ เหมือนชัตเตอร์กล้อง iPhone)
        shutterFlashTick++
        val tempFile = java.io.File(context.cacheDir, "cap_$name.jpg")
        val output = ImageCapture.OutputFileOptions.Builder(tempFile).setMetadata(metadata).build()
        cap.takePicture(output, mainExecutor, object : ImageCapture.OnImageSavedCallback {
            override fun onImageSaved(result: ImageCapture.OutputFileResults) {
                // ปล่อยให้กดถ่ายใบต่อไปได้ทันที ส่วนการปรับภาพให้สวยคมชัดทำเบื้องหลัง แล้วค่อยบันทึกลงเครื่อง
                scope.launch(Dispatchers.IO) {
                    withContext(NonCancellable) {
                        photoProcessMutex.withLock {
                            val saved = processAndSave(
                                context, tempFile, "IMG_$name", relativePath, styleAtCapture, blurAtCapture, postAtCapture
                            ) { msg ->
                                scope.launch(Dispatchers.Main) {
                                    Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                                }
                            }
                            if (saved != null) {
                                withContext(Dispatchers.Main) {
                                    lastUri = saved
                                    onSaved(saved)
                                }
                                if (settings.showFileInfo) {
                                    val info = describePhoto(context, saved)
                                    if (info != null) {
                                        withContext(Dispatchers.Main) {
                                            Toast.makeText(context, "บันทึกแล้ว: $info", Toast.LENGTH_SHORT).show()
                                        }
                                    }
                                }
                            } else {
                                withContext(Dispatchers.Main) {
                                    Toast.makeText(context, "บันทึกภาพไม่สำเร็จ", Toast.LENGTH_SHORT).show()
                                }
                            }
                        }
                    }
                }
            }

            override fun onError(exc: ImageCaptureException) {
                tempFile.delete()
                Toast.makeText(context, "ถ่ายภาพไม่สำเร็จ: ${exc.message}", Toast.LENGTH_SHORT).show()
            }
        })
    }

    // ---- อัดวิดีโอ: แตะครั้งแรกเริ่มอัด แตะอีกครั้งหยุด ----
    fun toggleRecording() {
        val active = recording
        if (active != null) {
            active.stop()
            return
        }
        val vc = videoCapture ?: return
        if (!hasFreeSpace(context, 300)) {
            Toast.makeText(context, "พื้นที่เก็บข้อมูลเหลือน้อยเกินไปสำหรับอัดวิดีโอ", Toast.LENGTH_LONG).show()
            return
        }
        val name = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(System.currentTimeMillis())
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, "VID_$name")
            put(MediaStore.MediaColumns.MIME_TYPE, "video/mp4")
            put(MediaStore.MediaColumns.RELATIVE_PATH, "Movies/ProCamera")
        }
        val options = MediaStoreOutputOptions.Builder(
            context.contentResolver,
            MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        ).setContentValues(values).build()
        var pending = vc.output.prepareRecording(context, options)
        val hasMic = ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) ==
            PackageManager.PERMISSION_GRANTED
        if (hasMic) pending = pending.withAudioEnabled()
        recordSeconds = 0L
        // จำโหมด ณ ตอนเริ่มอัด ไว้ใช้ตอนอัดเสร็จ (เผื่อผู้ใช้สลับโหมดระหว่างอัดวิดีโอ)
        val recordingMode = mode
        recording = pending.start(mainExecutor) { event ->
            when (event) {
                is VideoRecordEvent.Status -> {
                    recordSeconds = event.recordingStats.recordedDurationNanos / 1_000_000_000L
                }
                is VideoRecordEvent.Pause -> paused = true
                is VideoRecordEvent.Resume -> paused = false
                is VideoRecordEvent.Finalize -> {
                    recording = null
                    paused = false
                    if (event.hasError()) {
                        Toast.makeText(context, "บันทึกวิดีโอไม่สำเร็จ (รหัส ${event.error})", Toast.LENGTH_SHORT).show()
                    } else {
                        val savedUri = event.outputResults.outputUri
                        lastUri = savedUri
                        scope.launch(Dispatchers.IO) {
                            val info = describeVideo(context, savedUri)
                            if (info != null && settings.showFileInfo) {
                                withContext(Dispatchers.Main) {
                                    Toast.makeText(context, "บันทึกแล้ว: $info", Toast.LENGTH_LONG).show()
                                }
                            }
                            // สโลโมชัน: ทำให้ไฟล์เล่นช้าลงจริงตามเฟรมเรตที่วัดได้ (ไม่ใช่แค่บันทึกเฟรมเรตสูงเฉย ๆ)
                            if (recordingMode == CamMode.SLOMO) {
                                withContext(Dispatchers.Main) {
                                    Toast.makeText(context, "กำลังทำสโลโมชัน...", Toast.LENGTH_SHORT).show()
                                }
                                val slomoName = "VID_SLOMO_" +
                                    SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(System.currentTimeMillis())
                                val retimed = runCatching {
                                    SlowMotionRetimer.retime(context, savedUri, outputDisplayName = slomoName)
                                }.getOrNull()
                                withContext(Dispatchers.Main) {
                                    if (retimed != null) {
                                        lastUri = retimed
                                        // ไฟล์ต้นฉบับเล่นเร็วปกติ ไม่มีประโยชน์แยกไว้ ลบทิ้งเมื่อ retime สำเร็จแล้ว
                                        runCatching { context.contentResolver.delete(savedUri, null, null) }
                                        Toast.makeText(
                                            context,
                                            "ทำสโลโมชันเสร็จแล้ว (ไม่มีเสียง) " + SlowMotionRetimer.lastSummary,
                                            Toast.LENGTH_LONG
                                        ).show()
                                    } else {
                                        // แสดงสาเหตุจริงในกล่องข้อความที่ค้างจนกว่าจะกดปิด (Toast หายเร็วเกินไป)
                                        noteDialog = "ทำสโลโมชันไม่สำเร็จ เก็บไฟล์ต้นฉบับ (เล่นเร็วปกติ) ไว้แทน\n\n" +
                                            "สาเหตุ: " + SlowMotionRetimer.lastFailure +
                                            (info?.let { "\n\nไฟล์ที่อัด: $it" } ?: "")
                                    }
                                }
                            }
                        }
                    }
                }
                else -> {}
            }
        }
        if (!hasMic) {
            Toast.makeText(context, "ยังไม่ได้อนุญาตไมโครโฟน วิดีโอจะไม่มีเสียง", Toast.LENGTH_SHORT).show()
        }
    }

    // ---- ถ่ายภาพนิ่งระหว่างอัดวิดีโอ: เก็บเฟรมจากพรีวิวสด (ความละเอียดเท่าพรีวิว ไม่ใช่ความละเอียดเต็มของเซนเซอร์) ----
    fun snapshotWhileRecording() {
        val frame = previewView.bitmap ?: return
        shutterFlashTick++
        scope.launch(Dispatchers.IO) {
            val stamp = SimpleDateFormat("yyyyMMdd_HHmmss_SSS", Locale.US).format(System.currentTimeMillis())
            val f = java.io.File(context.cacheDir, "snap_$stamp.jpg")
            val uri = try {
                f.outputStream().buffered().use { frame.compress(Bitmap.CompressFormat.JPEG, 95, it) }
                insertJpegToGallery(context, f, "IMG_SNAP_$stamp", "Pictures/ProCamera")
            } catch (t: Throwable) {
                CrashLog.log("ถ่ายภาพนิ่งระหว่างอัดวิดีโอไม่สำเร็จ", t)
                null
            } finally {
                f.delete()
                frame.recycle()
            }
            withContext(Dispatchers.Main) {
                if (uri != null) {
                    lastUri = uri
                    Toast.makeText(context, "บันทึกภาพนิ่งระหว่างอัดแล้ว", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(context, "บันทึกภาพนิ่งไม่สำเร็จ", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    // ---- พาโนรามา: จบการกวาด (save=true รวมภาพแล้วบันทึกลงแกลเลอรี) ----
    fun stopPano(save: Boolean) {
        val sess = panoSession ?: return
        panoJob?.cancel()
        panoJob = null
        panoSession = null
        sess.stopSensors()
        if (!save) {
            sess.discard()
            return
        }
        panoSaving = true
        scope.launch(Dispatchers.Default) {
            val bmp = runCatching { sess.finish() }.getOrNull()
            val uri = if (bmp != null) {
                withContext(Dispatchers.IO) { runCatching { savePanorama(context, bmp) }.getOrNull() }
            } else null
            bmp?.recycle()
            withContext(Dispatchers.Main) {
                panoSaving = false
                if (uri != null) {
                    lastUri = uri
                    Toast.makeText(context, "บันทึกพาโนรามาแล้ว", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(context, "กวาดกล้องน้อยเกินไปหรือบันทึกไม่สำเร็จ ลองกวาดให้ช้าและยาวขึ้น", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    // ---- พาโนรามา: เริ่มกวาด เก็บเฟรมจากพรีวิวสดทุก ~30 มิลลิวินาที (ตัวชัตเตอร์จะรับเฟรมเมื่อกล้องหมุนไปครบมุมที่กำหนด) ----
    fun startPano() {
        val cam = camera ?: return
        val z = cam.cameraInfo.zoomState.value?.zoomRatio ?: zoom
        val sess = PanoramaSession(context, estimateHorizontalFov(cam, z))
        if (!sess.startSensors()) {
            Toast.makeText(context, "เครื่องนี้ไม่มีเซนเซอร์หมุน ใช้พาโนรามาไม่ได้", Toast.LENGTH_LONG).show()
            return
        }
        panoSession = sess
        panoDeg = 0f
        Toast.makeText(context, "ถือเครื่องตั้งตรง กวาดกล้องช้า ๆ ไปทางเดียว แตะชัตเตอร์อีกครั้งเพื่อจบ", Toast.LENGTH_LONG).show()
        panoJob = scope.launch {
            while (isActive) {
                val frame = previewView.bitmap
                if (frame != null) {
                    val more = sess.addFrame(frame)
                    frame.recycle()
                    panoDeg = sess.sweptDegrees
                    if (!more) {
                        stopPano(true)
                        break
                    }
                }
                delay(30)
            }
        }
    }

    // แตะชัตเตอร์ซ้ำระหว่างนับถอยหลัง = ยกเลิก
    fun onShutter() {
        shutterHapticClick(context, hostView)
        if (mode == CamMode.VIDEO || mode == CamMode.SLOMO) {
            toggleRecording()
            return
        }
        if (mode == CamMode.PANO) {
            if (panoSaving) return
            if (panoSession != null) stopPano(true) else startPano()
            return
        }
        // ภาพถ่าย / ภาพเหมือน ใช้เส้นทางถ่ายภาพเดียวกัน
        if (countdownJob != null) {
            countdownJob?.cancel()
            countdownJob = null
            countdown = null
            return
        }
        val sec = panel.timerSec
        if (sec == 0) {
            takePhoto()
            return
        }
        countdownJob = scope.launch {
            for (i in sec downTo 1) {
                countdown = i
                delay(1000)
            }
            countdown = null
            countdownJob = null
            takePhoto()
        }
    }

    val ratio = when (effAspect) {
        "16:9" -> 9f / 16f
        "1:1" -> 1f
        else -> 3f / 4f
    }
    // รวมสเต็ปซูมไกลเข้าไปด้วยถ้าเครื่องรองรับ (Honor 400 เคลมซูมดิจิทัลได้ถึง 30x)
    val zoomSteps = remember(minZoom, maxZoom) {
        zoomStepsFor(minZoom, maxZoom)
    }
    val busy = recording != null || panoSession != null

    Box(Modifier.fillMaxSize().background(Color.Black)) {

        // ---- พรีวิว ----
        Box(
            Modifier
                .align(Alignment.TopCenter)
                .padding(top = if (effAspect == "16:9") 0.dp else 88.dp)
                .fillMaxWidth()
                .aspectRatio(ratio)
                .pointerInput(camera) {
                    detectTapGestures(
                        // แตะค้าง = ล็อกโฟกัสและแสง จนกว่าจะแตะที่อื่น
                        onLongPress = { offset ->
                            val point = previewView.meteringPointFactory.createPoint(offset.x, offset.y)
                            val action = FocusMeteringAction.Builder(
                                point,
                                FocusMeteringAction.FLAG_AF or FocusMeteringAction.FLAG_AE
                            ).disableAutoCancel().build()
                            camera?.cameraControl?.startFocusAndMetering(action)
                            aeLocked = true
                            focusPoint = offset
                            focusTick++
                        },
                        onTap = { offset ->
                            if (panelExpanded) panelExpanded = false
                            val point = previewView.meteringPointFactory.createPoint(offset.x, offset.y)
                            val action = FocusMeteringAction.Builder(
                                point,
                                FocusMeteringAction.FLAG_AF or FocusMeteringAction.FLAG_AE
                            ).setAutoCancelDuration(3, TimeUnit.SECONDS).build()
                            camera?.cameraControl?.startFocusAndMetering(action)
                            aeLocked = false
                            focusPoint = offset
                            focusTick++
                        }
                    )
                }
                // สองนิ้ว = บีบซูม / นิ้วเดียวปัดซ้าย-ขวา = เลื่อนโหมดในแถบล่าง (แบบ iPhone)
                .pointerInput(camera, minZoom, maxZoom, mode, busy) {
                    awaitEachGesture {
                        awaitFirstDown(requireUnconsumed = false)
                        var swipeX = 0f
                        var multi = false
                        do {
                            val event = awaitPointerEvent()
                            val pressed = event.changes.count { it.pressed }
                            if (pressed >= 2) {
                                multi = true
                                val z = event.calculateZoom()
                                if (z != 1f) {
                                    zoom = (zoom * z).coerceIn(minZoom, maxZoom)
                                    camera?.cameraControl?.setZoomRatio(zoom)
                                }
                                event.changes.forEach { it.consume() }
                            } else if (!multi && pressed == 1) {
                                swipeX += event.calculatePan().x
                                if (kotlin.math.abs(swipeX) > viewConfiguration.touchSlop) {
                                    event.changes.forEach { it.consume() }
                                }
                            }
                        } while (event.changes.any { it.pressed })
                        if (!multi && !busy) {
                            val threshold = 80.dp.toPx()
                            val idx = ModeOrder.indexOfFirst { it.first == mode }.coerceAtLeast(0)
                            if (swipeX > threshold && idx > 0) {
                                mode = ModeOrder[idx - 1].first
                            } else if (swipeX < -threshold && idx < ModeOrder.lastIndex) {
                                mode = ModeOrder[idx + 1].first
                            }
                        }
                    }
                }
        ) {
            AndroidView(
                factory = { previewView },
                modifier = Modifier.fillMaxSize().styleColorFilter(panel.style)
            )
            analysisOverlay?.let { ov ->
                if (settings.peaking || settings.zebra) {
                    Image(
                        bitmap = ov.asImageBitmap(),
                        contentDescription = null,
                        contentScale = ContentScale.FillBounds,
                        filterQuality = FilterQuality.None,
                        modifier = Modifier.fillMaxSize()
                    )
                }
            }
            val hist = analysisHist
            if (settings.histogram && hist != null) {
                HistogramView(hist, Modifier.align(Alignment.BottomStart).padding(10.dp))
            }
            if (settings.grid) GridOverlay()
            if (settings.level) LevelOverlay()
            // ฟ้าผ่ามืดวูบสั้นๆ ตอนถ่ายภาพ (ไม่รับการแตะ จึงไม่ขวางปุ่มอื่น)
            if (shutterFlashAlpha.value > 0.001f) {
                Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = shutterFlashAlpha.value)))
            }

            val fp = focusPoint
            AnimatedVisibility(
                visible = fp != null && focusVisible,
                enter = fadeIn(),
                exit = fadeOut()
            ) {
                if (fp != null) {
                    Box(
                        Modifier
                            .offset { IntOffset((fp.x - 40.dp.toPx()).roundToInt(), (fp.y - 40.dp.toPx()).roundToInt()) }
                            .size(80.dp)
                    ) {
                        Box(Modifier.size(80.dp).border(1.dp, CamYellow, RoundedCornerShape(2.dp)))

                        if (aeLocked) {
                            Text(
                                "ล็อกแสง/โฟกัส",
                                color = Color.Black,
                                fontSize = 11.sp,
                                modifier = Modifier
                                    .align(Alignment.TopCenter)
                                    .offset(y = (-26).dp)
                                    .requiredSize(width = 96.dp, height = 20.dp)
                                    .clip(RoundedCornerShape(50))
                                    .background(CamYellow)
                                    .padding(top = 3.dp)
                            )
                        }

                        // ก้านปรับความสว่าง: ลากดวงอาทิตย์ขึ้น/ลง (ขึ้น = สว่างขึ้น)
                        val evR = camera?.cameraInfo?.exposureState?.exposureCompensationRange
                        if (evR != null && evR.upper > evR.lower) {
                            val frac = (panel.evIndex - evR.lower).toFloat() / (evR.upper - evR.lower)
                            val sunY = ((0.5f - frac) * 100f).dp
                            Box(
                                Modifier
                                    .align(Alignment.CenterEnd)
                                    .offset(x = 30.dp)
                                    .requiredSize(width = 40.dp, height = 130.dp)
                                    .pointerInput(evR) {
                                        var acc = 0f
                                        detectVerticalDragGestures(
                                            onDragStart = { acc = panel.evIndex.toFloat() },
                                            onVerticalDrag = { change, dy ->
                                                change.consume()
                                                acc = (acc - dy / 8.dp.toPx())
                                                    .coerceIn(evR.lower.toFloat(), evR.upper.toFloat())
                                                panel = panel.copy(evIndex = acc.roundToInt())
                                                focusTick++
                                            }
                                        )
                                    },
                                contentAlignment = Alignment.Center
                            ) {
                                Box(
                                    Modifier
                                        .width(1.dp)
                                        .fillMaxHeight()
                                        .background(CamYellow.copy(alpha = 0.6f))
                                )
                                Icon(
                                    Icons.Rounded.WbSunny,
                                    contentDescription = null,
                                    tint = CamYellow,
                                    modifier = Modifier
                                        .offset(y = sunY)
                                        .size(24.dp)
                                        .background(Color.Black.copy(alpha = 0.35f), CircleShape)
                                        .padding(2.dp)
                                )
                            }
                        }
                    }
                }
            }

            countdown?.let {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("$it", color = Color.White, fontSize = 72.sp)
                }
            }

            if (panoSession != null || panoSaving) {
                Column(
                    Modifier.fillMaxWidth().padding(top = 10.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        if (panoSaving) "กำลังรวมภาพพาโนรามา..." else "กวาดกล้องช้า ๆ ไปทางเดียว  ${panoDeg.toInt()}°",
                        color = Color.Black,
                        fontSize = 12.sp,
                        modifier = Modifier
                            .clip(RoundedCornerShape(50))
                            .background(CamYellow)
                            .padding(horizontal = 14.dp, vertical = 6.dp)
                    )
                    if (!panoSaving) {
                        Box(
                            Modifier
                                .padding(top = 8.dp)
                                .size(220.dp, 4.dp)
                                .clip(RoundedCornerShape(50))
                                .background(Color.White.copy(alpha = 0.3f))
                        ) {
                            Box(
                                Modifier
                                    .fillMaxHeight()
                                    .fillMaxWidth((panoDeg / 300f).coerceIn(0.02f, 1f))
                                    .background(CamYellow)
                            )
                        }
                    }
                }
            }

        }

        noteDialog?.let { msg ->
            AlertDialog(
                onDismissRequest = { noteDialog = null },
                confirmButton = { TextButton(onClick = { noteDialog = null }) { Text("ปิด") } },
                title = { Text("สโลโมชัน") },
                text = { Text(msg) }
            )
        }

        // ---- หน้าต่างข้อมูลกล้อง (ชั่วคราว ใช้ตรวจว่าเครื่องเปิดกล้องอัลตราไวด์ให้แอปไหม) ----
        if (showInfo) {
            AlertDialog(
                onDismissRequest = { showInfo = false },
                confirmButton = { TextButton(onClick = { showInfo = false }) { Text("ปิด") } },
                title = { Text("ข้อมูลกล้องของเครื่อง") },
                text = {
                    Column(Modifier.verticalScroll(rememberScrollState())) {
                        Text(
                            remember(extensionsInfo) {
                                describeCameras(context) + "\nส่วนขยายกล้อง: " + extensionsInfo
                            },
                            fontSize = 12.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            )
        }

        // ---- บันทึกข้อผิดพลาด (เปิดจากตั้งค่า > เกี่ยวกับ) ----
        if (showLog) {
            val logText = remember(showLog) { CrashLog.read() }
            AlertDialog(
                onDismissRequest = { showLog = false },
                title = { Text("บันทึกข้อผิดพลาด") },
                text = {
                    Column(Modifier.verticalScroll(rememberScrollState())) {
                        Text(
                            logText.ifBlank { "ยังไม่มีข้อผิดพลาดที่บันทึกไว้" },
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                },
                confirmButton = {
                    TextButton(onClick = { shareText(context, "ProCamera log", logText) }) { Text("แชร์") }
                },
                dismissButton = {
                    Row {
                        TextButton(onClick = { CrashLog.clear(); showLog = false }) { Text("ล้าง") }
                        TextButton(onClick = { showLog = false }) { Text("ปิด") }
                    }
                }
            )
        }

        // ---- แนะนำการใช้งานครั้งแรก ----
        if (showOnboarding) {
            AlertDialog(
                onDismissRequest = { },
                title = { Text("ยินดีต้อนรับสู่ ProCamera") },
                text = {
                    Text(
                        "• แตะเพื่อโฟกัส แตะค้างเพื่อล็อกแสง/โฟกัส\n" +
                            "• ลากดวงอาทิตย์ข้างกรอบโฟกัสเพื่อปรับความสว่าง\n" +
                            "• ปัดแผงด้านล่างขึ้น เพื่อใช้ ISO/ชัตเตอร์ สมดุลสีขาว โฟกัสมือ สไตล์ภาพ\n" +
                            "• ตั้งค่า > เครื่องมือช่วยถ่าย: ฮิสโตแกรม โฟกัสพีคกิ้ง ซีบรา\n" +
                            "• ปัดซ้าย-ขวาบนพรีวิวเพื่อเปลี่ยนโหมด"
                    )
                },
                confirmButton = {
                    TextButton(onClick = {
                        showOnboarding = false
                        val n = settings.copy(onboarded = true)
                        settings = n
                        saveSettings(context, n)
                    }) { Text("เริ่มใช้งาน") }
                }
            )
        }

        // ---- แถบบน: แฟลช ... ตั้งค่า ----
        Row(
            Modifier
                .align(Alignment.TopCenter)
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            GlassIconButton(
                icon = when (flashMode) {
                    ImageCapture.FLASH_MODE_ON -> Icons.Rounded.FlashOn
                    ImageCapture.FLASH_MODE_AUTO -> Icons.Rounded.FlashAuto
                    else -> Icons.Rounded.FlashOff
                },
                tint = if (flashMode == ImageCapture.FLASH_MODE_OFF) Color.White else CamYellow
            ) {
                flashMode = if (usesVideoPipeline) {
                    if (flashMode == ImageCapture.FLASH_MODE_OFF) ImageCapture.FLASH_MODE_ON else ImageCapture.FLASH_MODE_OFF
                } else when (flashMode) {
                    ImageCapture.FLASH_MODE_OFF -> ImageCapture.FLASH_MODE_AUTO
                    ImageCapture.FLASH_MODE_AUTO -> ImageCapture.FLASH_MODE_ON
                    else -> ImageCapture.FLASH_MODE_OFF
                }
            }
            if (recording != null) {
                Text(
                    text = (if (paused) "หยุดชั่วคราว " else "● ") + "%02d:%02d".format(recordSeconds / 60, recordSeconds % 60),
                    color = Color(0xFFFF3B30),
                    fontSize = 15.sp,
                    modifier = Modifier
                        .clip(RoundedCornerShape(50))
                        .background(Color.Black.copy(alpha = 0.45f))
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                )
            }
            GlassIconButton(icon = Icons.Rounded.Settings) { showSettings = true }
        }

        // ---- ส่วนล่าง ----
        Column(
            Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(bottom = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            val exp = camera?.cameraInfo?.exposureState
            QuickPanel(
                expanded = panelExpanded,
                onExpandedChange = { panelExpanded = it },
                state = panel,
                onStateChange = { panel = it },
                evRange = exp?.exposureCompensationRange?.let { it.lower..it.upper } ?: 0..0,
                evStep = exp?.exposureCompensationStep?.toFloat() ?: 0f,
                isoRange = manualRanges?.iso,
                shutterRangeNs = manualRanges?.shutterNs,
                aspectOptions = if (usesVideoPipeline || mode == CamMode.PANO) emptyList() else listOf("4:3", "16:9", "1:1"),
                blurAvailable = mode == CamMode.PORTRAIT,
                showTimer = mode == CamMode.PHOTO || mode == CamMode.PORTRAIT,
                wbModes = extraCaps?.awbModes ?: emptySet(),
                focusMaxDiopter = extraCaps?.minFocusDiopter ?: 0f
            )

            // ปุ่มเลือกซูมแบบแคปซูล
            if (zoomSteps.size > 1) {
                Row(
                    Modifier
                        .clip(RoundedCornerShape(50))
                        .background(Color.Black.copy(alpha = 0.35f))
                        .padding(3.dp),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    zoomSteps.forEach { z ->
                        val selected = kotlin.math.abs(zoom - z) < 0.25f
                        Text(
                            text = zoomLabel(z) + if (selected) "×" else "",
                            color = if (selected) CamYellow else Color.White,
                            fontSize = if (selected) 13.sp else 12.sp,
                            modifier = Modifier
                                .clip(CircleShape)
                                .background(if (selected) Color.Black.copy(alpha = 0.5f) else Color.Transparent)
                                .clickable {
                                    zoom = z
                                    camera?.cameraControl?.setZoomRatio(z)
                                }
                                .padding(horizontal = 11.dp, vertical = 7.dp)
                        )
                    }
                }
            }

            // แถบโหมด: ครบ 6 โหมดแบบ iPhone เลื่อนดูได้ ปัดบนพรีวิวก็เปลี่ยนโหมดได้เหมือนกัน
            val modeListState = rememberLazyListState()
            LaunchedEffect(mode) {
                val idx = ModeOrder.indexOfFirst { it.first == mode }
                if (idx >= 0) modeListState.animateScrollToItem(idx.coerceAtMost(ModeOrder.lastIndex))
            }
            LazyRow(
                state = modeListState,
                horizontalArrangement = Arrangement.spacedBy(22.dp),
                contentPadding = PaddingValues(horizontal = 140.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                items(ModeOrder) { (m, label) ->
                    Text(
                        label,
                        color = if (mode == m) CamYellow else Color.White.copy(alpha = 0.65f),
                        fontSize = 14.sp,
                        fontWeight = if (mode == m) FontWeight.SemiBold else FontWeight.Normal,
                        modifier = Modifier.clickable(enabled = !busy) { mode = m }
                    )
                }
            }

            // ภาพย่อ | ชัตเตอร์ | สลับกล้อง
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 28.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                val t = thumb
                if (recording != null && mode == CamMode.VIDEO) {
                    // ปุ่มถ่ายภาพนิ่งระหว่างอัดวิดีโอ
                    Box(
                        Modifier
                            .size(52.dp)
                            .clip(CircleShape)
                            .border(2.dp, Color.White, CircleShape)
                            .clickable { snapshotWhileRecording() }
                            .padding(8.dp)
                    ) {
                        Box(Modifier.fillMaxSize().clip(CircleShape).background(Color.White))
                    }
                } else if (t != null) {
                    Image(
                        bitmap = t.asImageBitmap(),
                        contentDescription = null,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .size(52.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .border(1.dp, Color.White.copy(alpha = 0.5f), RoundedCornerShape(12.dp))
                            .clickable { showViewer = true }
                    )
                } else {
                    Spacer(Modifier.size(52.dp))
                }

                // ชัตเตอร์: วงในขาว = ถ่ายภาพ / วงในแดง = อัดวิดีโอ/สโลโมชัน / สี่เหลี่ยมมน = กำลังอัด
                val recordingNow = recording != null || panoSession != null
                val innerSize by animateDpAsState(if (recordingNow) 28.dp else 62.dp, label = "shutter")
                Box(
                    Modifier
                        .size(78.dp)
                        .border(3.dp, Color.White, CircleShape)
                        .clip(CircleShape)
                        .clickable { onShutter() },
                    contentAlignment = Alignment.Center
                ) {
                    Box(
                        Modifier
                            .size(innerSize)
                            .clip(if (recordingNow) RoundedCornerShape(8.dp) else CircleShape)
                            .background(
                                when {
                                    panoSession != null -> CamYellow
                                    usesVideoPipeline -> Color(0xFFFF3B30)
                                    countdown != null -> CamYellow
                                    else -> Color.White
                                }
                            )
                    )
                }

                if (recording != null && mode == CamMode.VIDEO) {
                    // ปุ่มพัก/อัดต่อ (ไม่ใช้กับสโลโมชัน เพราะการวัดเฟรมเรตจะเพี้ยน)
                    GlassIconButton(icon = if (paused) Icons.Rounded.PlayArrow else Icons.Rounded.Pause, size = 52.dp) {
                        val r = recording
                        if (r != null) {
                            if (paused) r.resume() else r.pause()
                        }
                    }
                } else {
                    GlassIconButton(icon = Icons.Rounded.FlipCameraAndroid, size = 52.dp) {
                        if (busy) return@GlassIconButton
                        lens = if (lens == CameraSelector.LENS_FACING_BACK) {
                            CameraSelector.LENS_FACING_FRONT
                        } else {
                            CameraSelector.LENS_FACING_BACK
                        }
                    }
                }
            }
        }

        // ---- หน้าดูภาพ/วิดีโอในแอป (เปิดจากภาพย่อมุมล่างซ้าย) ----
        if (showViewer) {
            MediaViewer(
                startUri = lastUri,
                onClose = { latest ->
                    showViewer = false
                    lastUri = latest
                    if (latest == null) thumb = null
                }
            )
        }

        // ---- หน้าตั้งค่า (เปิดจากปุ่มเฟือง) ----
        if (showSettings) {
            BackHandler { showSettings = false }
            SettingsScreen(
                settings = settings,
                onChange = {
                    settings = it
                    saveSettings(context, it)
                },
                supportedQualities = supportedQualities,
                maxFps = maxFps,
                onOpenCameraInfo = { showInfo = true },
                onOpenLog = { showLog = true },
                onClose = { showSettings = false }
            )
        }
    }
}

// สั่นตอนกดชัตเตอร์ ใช้ 2 ทางพร้อมกันเพื่อให้สั่นแน่ๆ บนเครื่องที่ตั้งค่าสั่นต่างกัน:
// (1) สั่งมอเตอร์สั่นโดยตรงด้วยเอฟเฟกต์ "คลิกหนัก" สำเร็จรูปของระบบ (ก่อนหน้านี้ใช้พัลส์ 18 มิลลิวินาที
//     แรงต่ำ ซึ่งสั้น/เบาเกินไปจนบางเครื่องแทบไม่รู้สึกหรือถูกระบบตัดทิ้ง)
// (2) ขอให้ View ทำ haptic feedback ของระบบอีกชั้น โดยไม่สน "เปิดสั่นเมื่อสัมผัส" ในตั้งค่าเครื่อง
private fun shutterHapticClick(context: Context, view: View) {
    runCatching {
        val vibrator: Vibrator? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            (context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager)?.defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
        }
        if (vibrator != null && vibrator.hasVibrator()) {
            vibrator.vibrate(VibrationEffect.createPredefined(VibrationEffect.EFFECT_HEAVY_CLICK))
        }
    }
    runCatching {
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            HapticFeedbackConstants.CONFIRM
        } else {
            HapticFeedbackConstants.VIRTUAL_KEY
        }
        @Suppress("DEPRECATION")
        view.performHapticFeedback(type, HapticFeedbackConstants.FLAG_IGNORE_GLOBAL_SETTING)
    }
}

// ---------------------------------------------------------------------
//  สไตล์ภาพ (Photographic Styles แบบง่าย): ปรับสี/ความอิ่มสีจริงทั้งพรีวิวและไฟล์ที่บันทึก
// ---------------------------------------------------------------------

// เมทริกซ์สีของแต่ละสไตล์ (android.graphics.ColorMatrix ใช้ได้ทั้งวาดพรีวิวและแต่งบิตแมปไฟล์จริง)
private fun PhotoStyle.toColorMatrix(): android.graphics.ColorMatrix {
    val cm = android.graphics.ColorMatrix()
    when (this) {
        PhotoStyle.STANDARD -> { /* ไม่ปรับอะไร */ }
        PhotoStyle.VIVID -> cm.setSaturation(1.45f)
        PhotoStyle.MONO -> cm.setSaturation(0f)
        PhotoStyle.WARM -> {
            cm.setSaturation(1.1f)
            cm.postConcat(
                android.graphics.ColorMatrix(
                    floatArrayOf(
                        1.08f, 0f, 0f, 0f, 8f,
                        0f, 1.02f, 0f, 0f, 2f,
                        0f, 0f, 0.90f, 0f, -6f,
                        0f, 0f, 0f, 1f, 0f
                    )
                )
            )
        }
        PhotoStyle.COOL -> {
            cm.setSaturation(1.1f)
            cm.postConcat(
                android.graphics.ColorMatrix(
                    floatArrayOf(
                        0.94f, 0f, 0f, 0f, -4f,
                        0f, 1.0f, 0f, 0f, 0f,
                        0f, 0f, 1.10f, 0f, 10f,
                        0f, 0f, 0f, 1f, 0f
                    )
                )
            )
        }
        // จำลองโทนแนวฟิล์มญี่ปุ่นยอดนิยม (ขำๆ ตามที่ขอ): ลดจัดสีลงนิด, ยกเงาให้ไม่ดำสนิท (ฟิล์มจริงมักไม่มีดำล้วน),
        // ใส่โทนอุ่นในไฮไลต์กับโทนเขียวอมฟ้าบางๆ ในเงามืด (split-tone) — เป็นการประมาณด้วยเมทริกซ์สีเชิงเส้น
        // ไม่ใช่โปรไฟล์สีลิขสิทธิ์ของกล้องแบรนด์ใดจริง
        PhotoStyle.FILM -> {
            cm.setSaturation(0.88f)
            cm.postConcat(
                android.graphics.ColorMatrix(
                    floatArrayOf(
                        0.92f, 0.04f, 0.02f, 0f, 12f,
                        0.02f, 0.90f, 0.03f, 0f, 9f,
                        0.02f, 0.05f, 0.85f, 0f, 14f,
                        0f, 0f, 0f, 1f, 0f
                    )
                )
            )
        }
    }
    return cm
}

// ทาสีทับพรีวิวสด ๆ ด้วยเมทริกซ์สีของสไตล์ที่เลือก (ใช้ saveLayer กับ Paint ปกติ รองรับทุกเวอร์ชัน)
private fun Modifier.styleColorFilter(style: PhotoStyle): Modifier {
    if (style == PhotoStyle.STANDARD) return this
    return this.drawWithContent {
        val paint = android.graphics.Paint().apply {
            colorFilter = android.graphics.ColorMatrixColorFilter(style.toColorMatrix())
        }
        drawIntoCanvas { canvas ->
            val native = canvas.nativeCanvas
            val count = native.saveLayer(null, paint)
            drawContent()
            native.restoreToCount(count)
        }
    }
}

// =====================================================================
//  ปรับภาพให้สวยคมชัด "ก่อนบันทึกลงเครื่อง"
//  ขั้นตอน: กล้องถ่ายลงไฟล์ชั่วคราวใน cache (เร็ว ไม่แตะแกลเลอรี) -> ทาสไตล์สี + ปรับคมชัด (unsharp mask
//  รัศมีกว้างพอให้เห็นผลตอนดูบนหน้าจอ) -> บันทึกลงแกลเลอรีครั้งเดียวเป็นไฟล์สุดท้าย
//  ประมวลผลทีละแถวในที่เดิม (ไม่สร้างสำเนาภาพเต็ม) กินหน่วยความจำต่ำ ภาพไม่ล้มเหลวเงียบๆ เหมือนเวอร์ชันเก่า
//  ที่ใช้ IntArray ขนาดเท่าภาพทั้งภาพหลายชุด (ภาพ 12-50MP กินหลายร้อย MB จนอาจ OOM แล้วไม่ได้ปรับคมชัดเลย)
//  ถ้าขั้นตอนใดพลาด จะบันทึกไฟล์ต้นฉบับจากกล้องลงแกลเลอรีแทนเสมอ ภาพจะไม่หาย
// =====================================================================
private fun processAndSave(
    context: Context,
    source: java.io.File,
    displayName: String,
    relativePath: String,
    style: PhotoStyle,
    portraitBlur: Float? = null,
    post: PhotoPostOptions = PhotoPostOptions(),
    onNote: (String) -> Unit = {}
): Uri? {
    val processed = java.io.File(context.cacheDir, "proc_${source.name}")
    var toWrite = source
    try {
        val opts = BitmapFactory.Options().apply {
            inMutable = true
            inPreferredConfig = Bitmap.Config.ARGB_8888
        }
        val bmp = BitmapFactory.decodeFile(source.absolutePath, opts)
        if (bmp != null) {
            try {
                // โหมดภาพเหมือน: เบลอฉากหลังเองด้วยการแยกตัวคน (ML Kit) ก่อนทาสไตล์/ปรับคมชัด
                if (portraitBlur != null) {
                    val orientation = runCatching {
                        androidx.exifinterface.media.ExifInterface(source.absolutePath).getAttributeInt(
                            androidx.exifinterface.media.ExifInterface.TAG_ORIENTATION,
                            androidx.exifinterface.media.ExifInterface.ORIENTATION_NORMAL
                        )
                    }.getOrDefault(androidx.exifinterface.media.ExifInterface.ORIENTATION_NORMAL)
                    when (runCatching { PortraitBlur.apply(bmp, portraitBlur, orientation) }.getOrDefault(PortraitBlur.Result.FAILED)) {
                        PortraitBlur.Result.NO_PERSON -> onNote("ไม่พบคนในภาพ จึงไม่ได้เบลอฉากหลัง")
                        PortraitBlur.Result.FAILED -> onNote("เบลอฉากหลังไม่สำเร็จ บันทึกภาพปกติแทน")
                        else -> {}
                    }
                }
                if (style != PhotoStyle.STANDARD || post.sharpen > 0f) enhanceInPlace(bmp, style, post.sharpen)
                if (post.stamp) {
                    val o = runCatching {
                        androidx.exifinterface.media.ExifInterface(source.absolutePath).getAttributeInt(
                            androidx.exifinterface.media.ExifInterface.TAG_ORIENTATION,
                            androidx.exifinterface.media.ExifInterface.ORIENTATION_NORMAL
                        )
                    }.getOrDefault(androidx.exifinterface.media.ExifInterface.ORIENTATION_NORMAL)
                    runCatching {
                        drawDateStamp(
                            bmp, o,
                            SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(System.currentTimeMillis())
                        )
                    }
                }
                val ok = processed.outputStream().buffered().use { bmp.compress(Bitmap.CompressFormat.JPEG, 97, it) }
                if (ok) {
                    // ต้องคัดลอก EXIF (โดยเฉพาะทิศทางภาพ) กลับไป เพราะการเข้ารหัส JPEG ใหม่ไม่พก EXIF มาด้วย
                    // ถ้าคัดลอกไม่สำเร็จจะไม่ใช้ไฟล์ที่ปรับแล้ว (กันภาพหมุนผิด) ใช้ไฟล์ต้นฉบับแทน
                    if (runCatching { copyExifTags(source, processed) }.isSuccess) toWrite = processed
                }
            } finally {
                bmp.recycle()
            }
        }
    } catch (t: Throwable) {
        CrashLog.log("ประมวลผลภาพไม่สำเร็จ ใช้ไฟล์ต้นฉบับแทน", t)
        toWrite = source // รวมกรณีหน่วยความจำไม่พอ (OutOfMemoryError) ด้วย
    }
    // ฝังพิกัด GPS (ถ้าผู้ใช้เปิดไว้และมีตำแหน่ง) ลงไฟล์ที่จะบันทึกจริง
    post.location?.let { loc -> runCatching { writeGps(toWrite, loc) } }
    val uri = insertJpegToGallery(context, toWrite, displayName, relativePath)
    source.delete()
    processed.delete()
    return uri
}

private fun copyExifTags(from: java.io.File, to: java.io.File) {
    val src = androidx.exifinterface.media.ExifInterface(from.absolutePath)
    val dst = androidx.exifinterface.media.ExifInterface(to.absolutePath)
    // ใช้ชื่อแท็กเป็นสตริงตรง ๆ (ตรงกับค่าคงที่ของ ExifInterface) เพื่อคัดลอกข้อมูลกล้องให้ครบขึ้น
    val tags = arrayOf(
        "Orientation", "DateTime", "DateTimeOriginal", "DateTimeDigitized",
        "SubSecTime", "SubSecTimeOriginal", "SubSecTimeDigitized",
        "Make", "Model", "LensModel", "Software",
        "ExposureTime", "FNumber", "ExposureProgram", "ExposureBiasValue", "MeteringMode",
        "PhotographicSensitivity", "FocalLength", "FocalLengthIn35mmFilm",
        "WhiteBalance", "Flash", "SceneCaptureType",
        "GPSLatitude", "GPSLatitudeRef", "GPSLongitude", "GPSLongitudeRef",
        "GPSAltitude", "GPSAltitudeRef", "GPSTimeStamp", "GPSDateStamp"
    )
    for (tag in tags) {
        src.getAttribute(tag)?.let { dst.setAttribute(tag, it) }
    }
    dst.saveAttributes()
}

// บันทึกภาพพาโนรามา (JPEG คุณภาพ 92) ลง Pictures/ProCamera
private fun savePanorama(context: Context, bmp: Bitmap): Uri? {
    val name = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(System.currentTimeMillis())
    val f = java.io.File(context.cacheDir, "pano_$name.jpg")
    return try {
        f.outputStream().buffered().use { bmp.compress(Bitmap.CompressFormat.JPEG, 92, it) }
        insertJpegToGallery(context, f, "PANO_$name", "Pictures/ProCamera")
    } finally {
        f.delete()
    }
}

private fun insertJpegToGallery(context: Context, file: java.io.File, displayName: String, relativePath: String): Uri? {
    val resolver = context.contentResolver
    val values = ContentValues().apply {
        put(MediaStore.MediaColumns.DISPLAY_NAME, "$displayName.jpg")
        put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
        put(MediaStore.MediaColumns.RELATIVE_PATH, relativePath)
        put(MediaStore.MediaColumns.IS_PENDING, 1)
    }
    val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values) ?: return null
    return try {
        val out = resolver.openOutputStream(uri) ?: throw java.io.IOException("เปิดไฟล์ปลายทางไม่ได้")
        out.use { o -> file.inputStream().use { it.copyTo(o) } }
        values.clear()
        values.put(MediaStore.MediaColumns.IS_PENDING, 0)
        resolver.update(uri, values, null, null)
        uri
    } catch (e: Exception) {
        runCatching { resolver.delete(uri, null, null) }
        null
    }
}

// ทาสไตล์สี + unsharp mask (เบลอกล่อง แล้วลบออกจากต้นฉบับ คูณความแรง บวกกลับ) ทีละแถวในที่เดิม
// รัศมีเบลอปรับตามขนาดภาพ (ภาพ 12MP ใช้ราว 4 พิกเซล = กล่อง 9x9) เพื่อให้เห็นความคมตอนดูบนจอมือถือที่ย่อภาพลง
// ใช้หน้าต่างแถวเลื่อนไปเรื่อยๆ: เก็บแถวต้นฉบับ (หลังทาสีแล้ว) กับผลรวมแนวนอนของแต่ละแถว + ผลรวมแนวตั้งสะสมไว้
// แถวที่เขียนทับไปแล้วจะไม่ถูกอ่านซ้ำ (อ่านล่วงหน้าไปข้างหน้าเท่านั้น) จึงถูกต้องแม้แก้บิตแมปที่เดิม
private fun enhanceInPlace(bmp: Bitmap, style: PhotoStyle, amount: Float = 0.9f) {
    val w = bmp.width
    val h = bmp.height
    if (w < 16 || h < 16) return
    val rad = (maxOf(w, h) / 1000).coerceIn(2, 6)
    val win = 2 * rad + 1
    val area = (win * win).toFloat()
    val m: FloatArray? = if (style != PhotoStyle.STANDARD) style.toColorMatrix().array else null
    val px = Array(win) { IntArray(w) }
    val hs = Array(win) { IntArray(w * 3) }
    val vs = IntArray(w * 3)

    fun loadRow(slot: Int, srcY: Int) {
        val row = px[slot]
        bmp.getPixels(row, 0, w, 0, srcY, w, 1)
        if (m != null) {
            for (x in 0 until w) {
                val p = row[x]
                val a = p ushr 24
                val r = (p shr 16) and 255
                val g = (p shr 8) and 255
                val b = p and 255
                val nr = (m[0] * r + m[1] * g + m[2] * b + m[4] + 0.5f).toInt().coerceIn(0, 255)
                val ng = (m[5] * r + m[6] * g + m[7] * b + m[9] + 0.5f).toInt().coerceIn(0, 255)
                val nb = (m[10] * r + m[11] * g + m[12] * b + m[14] + 0.5f).toInt().coerceIn(0, 255)
                row[x] = (a shl 24) or (nr shl 16) or (ng shl 8) or nb
            }
        }
        val hsRow = hs[slot]
        for (c in 0 until 3) {
            val shift = 16 - 8 * c
            var sum = 0
            for (dx in -rad..rad) {
                sum += (row[dx.coerceIn(0, w - 1)] shr shift) and 255
            }
            hsRow[c] = sum
            for (x in 1 until w) {
                val leaving = (row[(x - rad - 1).coerceAtLeast(0)] shr shift) and 255
                val entering = (row[(x + rad).coerceAtMost(w - 1)] shr shift) and 255
                sum += entering - leaving
                hsRow[x * 3 + c] = sum
            }
        }
    }

    for (k in 0 until win) loadRow(k, (k - rad).coerceIn(0, h - 1))
    for (k in 0 until win) {
        val a = hs[k]
        for (i in 0 until w * 3) vs[i] += a[i]
    }
    val out = IntArray(w)
    val k = amount / area
    val lim = 48f
    for (y in 0 until h) {
        val center = px[rad]
        for (x in 0 until w) {
            val p = center[x]
            val i = x * 3
            val r = (p shr 16) and 255
            val g = (p shr 8) and 255
            val b = p and 255
            // (ค่าจริง - ค่าเฉลี่ยเบลอ) * ความแรง จำกัดไม่ให้เกิดขอบเรืองแสง (halo) แรงเกินไป
            val nr = (r + ((r * area - vs[i]) * k).coerceIn(-lim, lim)).toInt().coerceIn(0, 255)
            val ng = (g + ((g * area - vs[i + 1]) * k).coerceIn(-lim, lim)).toInt().coerceIn(0, 255)
            val nb = (b + ((b * area - vs[i + 2]) * k).coerceIn(-lim, lim)).toInt().coerceIn(0, 255)
            out[x] = (0xFF shl 24) or (nr shl 16) or (ng shl 8) or nb
        }
        bmp.setPixels(out, 0, w, 0, y, w, 1)
        if (y < h - 1) {
            val leaving = hs[0]
            for (i in 0 until w * 3) vs[i] -= leaving[i]
            val p0 = px[0]
            for (kk in 0 until win - 1) {
                px[kk] = px[kk + 1]
                hs[kk] = hs[kk + 1]
            }
            px[win - 1] = p0
            hs[win - 1] = leaving
            loadRow(win - 1, (y + rad + 1).coerceAtMost(h - 1))
            val entering = hs[win - 1]
            for (i in 0 until w * 3) vs[i] += entering[i]
        }
    }
}

@Composable
private fun GlassIconButton(
    icon: ImageVector,
    tint: Color = Color.White,
    size: Dp = 40.dp,
    onClick: () -> Unit
) {
    Box(
        Modifier
            .size(size)
            .clip(CircleShape)
            .background(Color.Black.copy(alpha = 0.28f))
            .background(
                androidx.compose.ui.graphics.Brush.verticalGradient(
                    listOf(Color.White.copy(alpha = 0.22f), Color.White.copy(alpha = 0.08f))
                )
            )
            .border(0.8.dp, Color.White.copy(alpha = 0.32f), CircleShape)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Icon(icon, contentDescription = null, tint = tint, modifier = Modifier.size(size * 0.5f))
    }
}

// อ่านรายการกล้องทั้งหมดที่ Android เปิดให้แอปภายนอกเห็น
// ≈mm คือความยาวโฟกัสเทียบกล้องฟูลเฟรม: อัลตราไวด์ประมาณ 13-16 mm, กล้องหลักประมาณ 23-26 mm
private fun describeCameras(context: Context): String {
    val cm = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
    val sb = StringBuilder()
    for (id in cm.cameraIdList) {
        try {
            val ch = cm.getCameraCharacteristics(id)
            val facing = when (ch.get(CameraCharacteristics.LENS_FACING)) {
                CameraCharacteristics.LENS_FACING_BACK -> "หลัง"
                CameraCharacteristics.LENS_FACING_FRONT -> "หน้า"
                else -> "อื่น"
            }
            val focals = ch.get(CameraCharacteristics.LENS_INFO_AVAILABLE_FOCAL_LENGTHS)
            val size = ch.get(CameraCharacteristics.SENSOR_INFO_PHYSICAL_SIZE)
            val eq = if (focals != null && focals.isNotEmpty() && size != null) {
                val diag = kotlin.math.sqrt(size.width * size.width + size.height * size.height)
                "%.0f".format(focals[0] * 43.27f / diag)
            } else {
                "?"
            }
            val zoomRange = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                ch.get(CameraCharacteristics.CONTROL_ZOOM_RATIO_RANGE)?.let { "${it.lower}-${it.upper}" } ?: "-"
            } else {
                "-"
            }
            val physical = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                ch.physicalCameraIds.joinToString(",").ifEmpty { "-" }
            } else {
                "-"
            }
            sb.appendLine("ID $id | $facing | ≈${eq}mm | ซูม $zoomRange | กล้องจริง $physical")

            val ois = ch.get(CameraCharacteristics.LENS_INFO_AVAILABLE_OPTICAL_STABILIZATION)
                ?.contains(CameraCharacteristics.LENS_OPTICAL_STABILIZATION_MODE_ON) == true
            val eis = ch.get(CameraCharacteristics.CONTROL_AVAILABLE_VIDEO_STABILIZATION_MODES)
                ?.contains(CameraCharacteristics.CONTROL_VIDEO_STABILIZATION_MODE_ON) == true
            sb.appendLine("   กันสั่น: OIS ${if (ois) "ได้" else "ไม่ได้"} / EIS ${if (eis) "ได้" else "ไม่ได้"}")

            val fpsRanges = ch.get(CameraCharacteristics.CONTROL_AE_AVAILABLE_TARGET_FPS_RANGES)
                ?.joinToString(" ") { "${it.lower}-${it.upper}" } ?: "-"
            sb.appendLine("   fps ปกติ: $fpsRanges")
            val highSpeed = ch.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)
                ?.highSpeedVideoFpsRanges?.joinToString(" ") { "${it.lower}-${it.upper}" }
            sb.appendLine("   fps ความเร็วสูง: ${if (highSpeed.isNullOrEmpty()) "-" else highSpeed}")
            val idInt = id.toIntOrNull()
            if (idInt != null) {
                val profiles = listOf(
                    "4K" to CamcorderProfile.QUALITY_2160P,
                    "1080p" to CamcorderProfile.QUALITY_1080P,
                    "720p" to CamcorderProfile.QUALITY_720P
                ).mapNotNull { (name, q) ->
                    if (CamcorderProfile.hasProfile(idInt, q)) "$name=${CamcorderProfile.get(idInt, q)?.videoFrameRate}" else null
                }
                sb.appendLine("   โปรไฟล์วิดีโอ: ${profiles.joinToString(" ")}")
            }
        } catch (e: Exception) {
            sb.appendLine("ID $id | อ่านไม่ได้: ${e.message}")
        }
    }
    return sb.toString().ifEmpty { "ไม่พบกล้อง" }
}

// อ่านไฟล์วิดีโอที่เพิ่งอัด แล้วคำนวณเฟรมเรตจริงจากจำนวนเฟรมหารด้วยความยาว
private fun describeVideo(context: Context, uri: Uri): String? = runCatching {
    val r = MediaMetadataRetriever()
    r.setDataSource(context, uri)
    val w = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)
    val h = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)
    val frames = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_FRAME_COUNT)?.toDoubleOrNull()
    val durMs = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toDoubleOrNull()
    r.release()
    val fps = if (frames != null && durMs != null && durMs > 0) frames / (durMs / 1000.0) else null
    "${w}x$h" + (fps?.let { " | %.1f fps".format(it) } ?: "")
}.getOrNull()

// อ่านขนาดภาพที่เพิ่งบันทึก (ไม่ต้องโหลดภาพทั้งใบ)
private fun describePhoto(context: Context, uri: Uri): String? = runCatching {
    val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
    val mp = opts.outWidth * opts.outHeight / 1_000_000.0
    "${opts.outWidth}x${opts.outHeight} | %.1f MP".format(mp)
}.getOrNull()
