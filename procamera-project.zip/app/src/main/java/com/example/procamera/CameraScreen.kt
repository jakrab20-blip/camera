package com.example.procamera

import android.Manifest
import android.content.ContentValues
import android.content.Context
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.CamcorderProfile
import android.media.MediaMetadataRetriever
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.util.Range
import android.util.Rational
import android.util.Size
import android.view.OrientationEventListener
import android.view.Surface
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.FocusMeteringAction
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.core.UseCaseGroup
import androidx.camera.core.ViewPort
import androidx.camera.core.resolutionselector.AspectRatioStrategy
import androidx.camera.core.resolutionselector.ResolutionSelector
import androidx.camera.extensions.ExtensionMode
import androidx.camera.extensions.ExtensionsManager
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.FallbackStrategy
import androidx.camera.video.MediaStoreOutputOptions
import androidx.camera.video.Quality
import androidx.camera.video.QualitySelector
import androidx.camera.video.Recorder
import androidx.camera.video.Recording
import androidx.camera.video.VideoCapture
import androidx.camera.video.VideoRecordEvent
import androidx.camera.view.PreviewView
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.requiredSize
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.FlashAuto
import androidx.compose.material.icons.rounded.FlashOff
import androidx.compose.material.icons.rounded.FlashOn
import androidx.compose.material.icons.rounded.FlipCameraAndroid
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.WbSunny
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.concurrent.TimeUnit
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlin.math.roundToInt

// =====================================================================
//  ขั้นที่ 1: หน้ากล้องหลัก ออกแบบใหม่ตามพฤติกรรมของแอปกล้อง iPhone (iOS 26)
//  ทำแล้ว: พรีวิว ถ่ายภาพ สลับกล้อง แฟลช ซูม แตะโฟกัส บีบนิ้วซูม
//          ตั้งเวลา สัดส่วนภาพ ชดเชยแสง (ผ่านแผงปัดขึ้น QuickPanel) ภาพย่อ
//  ขั้นที่ 2: โหมดวิดีโอ (อัด/หยุด, เวลาที่อัด, ไฟฉายแทนแฟลช, บันทึกลง Movies/ProCamera)
//  ขั้นที่ 3: แถบโหมดครบ 6 โหมดแบบ iPhone (ปาโนรามา/ไทม์แลปส์/สโลโมชัน/วิดีโอ/ภาพถ่าย/ภาพเหมือน)
//          Portrait ใช้ CameraX Extensions (BOKEH) จริงถ้าเครื่องรองรับ ไม่งั้นถ่ายภาพปกติ
//          สไตล์ภาพ (มาตรฐาน/สด/อุ่น/เย็น/ขาวดำ) มีผลจริงทั้งพรีวิวและไฟล์ที่บันทึก
//  ขั้นที่ 4: ไทม์แลปส์ประกอบเป็น MP4 อัตโนมัติ (TimelapseEncoder), สโลโมชัน retime ให้เล่นช้าจริง
//          (SlowMotionRetimer), จัดการสิทธิ์กล้อง/ไมค์ดีขึ้น, มีไอคอนแอป
//  ขั้นที่ 5: แก้บั๊ก PreviewView ใช้ SurfaceView (PERFORMANCE) ทำให้ฟิลเตอร์สไตล์ภาพไม่โชว์ในพรีวิวสด
//          เปลี่ยนเป็น COMPATIBLE (TextureView) แล้ว, เพิ่มการขอกันสั่น OIS/EIS จริงตอนอัดวิดีโอ/
//          สโลโมชัน (เลือก OIS ก่อนถ้ามี ไม่มีก็ใช้ EIS), แก้ภาพย่อกระพริบระหว่างไทม์แลปส์,
//          เพิ่มบรรทัดกันสั่นในหน้าข้อมูลกล้องของเครื่อง
//  หมายเหตุความซื่อสัตย์: พาโนรามาตอนนี้เป็นเวอร์ชันต้นแบบ (ถ่ายภาพเดียวมุมกว้างสุดที่เครื่องมี
//          ยังไม่ต่อภาพจากการกวาดกล้องแบบ iPhone จริง) / สไลเดอร์ความแรงเบลอฉากหลัง (BLUR) ในโหมด
//          ภาพเหมือนยังเป็นแค่ UI ตัวเบลอจริงมาจากฮาร์ดแวร์ (CameraX Extensions BOKEH) ซึ่งไม่มี API
//          ให้ปรับความแรงเป็นระดับ / ซูม 0.5-10x เป็นลิสต์ตายตัว ไม่ได้อิงจากเลนส์จริงของเครื่อง /
//          ยังไม่มี RAW, Live Photo, Cinematic mode
//  ขั้นที่ 6 (ทำตามคำขอ): ค่าเริ่มต้นของสไตล์ภาพเปลี่ยนเป็น "สด" (VIVID) ทันทีที่เปิดแอป / เพิ่มสไตล์
//          "ฟิล์ม" จำลองโทนแนวฟิล์มญี่ปุ่นยอดนิยม (โทนสีเท่านั้น ไม่ใช่โปรไฟล์สีลิขสิทธิ์จริง) / แก้บั๊ก
//          องศาภาพผิด: เพิ่ม OrientationEventListener อ่านองศาการหมุนเครื่องจริงตลอดเวลา (แอปยังล็อก UI
//          แนวตั้งเหมือนเดิม) แล้วสั่ง targetRotation ของ ImageCapture/VideoCapture ให้ตรงเสมอ ไม่ว่าจะถือ
//          เครื่องแนวตั้ง/แนวนอน/ตะแคงซ้ายขวา / ขยาย EDGE_MODE กับ NOISE_REDUCTION แบบ HIGH_QUALITY (คมชัด
//          สูงสุดที่ Camera2 เปิดให้) ให้ครอบคลุมทุกโหมดถ่ายภาพนิ่ง ไม่ใช่แค่โหมดภาพถ่ายธรรมดา / เพิ่มตัว
//          กรองคมชัด (unsharp mask ซอฟต์แวร์) ทาลงไฟล์ภาพที่บันทึกจริงเสมอทุกภาพ เพิ่มเติมจากที่ขอฮาร์ดแวร์
//          ไปแล้ว / เพิ่มการฝังสไตล์ภาพลงไฟล์วิดีโอจริงด้วย (VideoColorEffect.kt ใช้ CameraX Effects API +
//          OpenGL ES) ก่อนหน้านี้สไตล์มีผลแค่พรีวิวกับภาพนิ่ง — ส่วนนี้ซับซ้อนสุดและยังไม่เคยคอมไพล์ทดสอบจริง
//          เสี่ยง build ไม่ผ่านสูงสุดในทุกจุดที่แก้รอบนี้ ถ้า build พังให้ดู error จาก GitHub Actions ก่อน
// =====================================================================

private val CamYellow = Color(0xFFFFD60A)

private enum class CamMode { PANO, TIMELAPSE, SLOMO, VIDEO, PHOTO, PORTRAIT }

// ลำดับโหมดในแถบล่าง เรียงแบบเดียวกับแอปกล้อง iPhone
private val ModeOrder = listOf(
    CamMode.PANO to "พาโนรามา",
    CamMode.TIMELAPSE to "ไทม์แลปส์",
    CamMode.SLOMO to "สโลโมชัน",
    CamMode.VIDEO to "วิดีโอ",
    CamMode.PHOTO to "ภาพถ่าย",
    CamMode.PORTRAIT to "ภาพเหมือน"
)

@Composable
fun CameraScreen() {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val scope = rememberCoroutineScope()
    val mainExecutor = remember { ContextCompat.getMainExecutor(context) }
    val previewView = remember {
        PreviewView(context).apply {
            scaleType = PreviewView.ScaleType.FILL_CENTER
            // ต้องใช้ COMPATIBLE (TextureView) ไม่ใช่ PERFORMANCE (SurfaceView) ค่าเริ่มต้น
            // เพราะ SurfaceView ไม่ผ่านกระบวนการวาดปกติของ View จึงทำให้ colorFilter ของสไตล์ภาพ
            // (styleColorFilter ด้านล่าง) ไม่มีผลกับพรีวิวสดเลย แม้โค้ดจะรันไม่ error ก็ตาม
            implementationMode = PreviewView.ImplementationMode.COMPATIBLE
        }
    }

    // ---- องศาการหมุนของเครื่องจริง (แก้บั๊กภาพเอียง/หมุนผิด) ----
    // แอปนี้ล็อก UI ไว้แนวตั้งเสมอ (AndroidManifest: screenOrientation="portrait") ทำให้ display rotation
    // ของระบบไม่เปลี่ยนตามการหมุนเครื่องจริงเลย ถ้าไม่ทำอะไรเพิ่ม ภาพที่ถ่ายตอนถือเครื่องแนวนอน/ตะแคง
    // จะถูกบันทึก EXIF ผิดองศา (ภาพเอียง/หัวกลับตอนเปิดดู) จึงต้องอ่านองศาจริงจากเซนเซอร์การหมุนเครื่อง
    // (ไม่ใช่จาก UI) แล้วสั่ง targetRotation ของ ImageCapture/VideoCapture ตรง ๆ ทุกครั้งที่เปลี่ยน
    var deviceRotation by remember { mutableIntStateOf(Surface.ROTATION_0) }
    DisposableEffect(Unit) {
        val listener = object : OrientationEventListener(context) {
            override fun onOrientationChanged(orientation: Int) {
                if (orientation == ORIENTATION_UNKNOWN) return
                val rotation = when (orientation) {
                    in 45 until 135 -> Surface.ROTATION_270
                    in 135 until 225 -> Surface.ROTATION_180
                    in 225 until 315 -> Surface.ROTATION_90
                    else -> Surface.ROTATION_0
                }
                if (rotation != deviceRotation) deviceRotation = rotation
            }
        }
        if (listener.canDetectOrientation()) listener.enable()
        onDispose { listener.disable() }
    }

    var lens by remember { mutableIntStateOf(CameraSelector.LENS_FACING_BACK) }
    var camera by remember { mutableStateOf<Camera?>(null) }
    var imageCapture by remember { mutableStateOf<ImageCapture?>(null) }
    var flashMode by remember { mutableIntStateOf(ImageCapture.FLASH_MODE_OFF) }

    var minZoom by remember { mutableFloatStateOf(1f) }
    var maxZoom by remember { mutableFloatStateOf(1f) }
    var zoom by remember { mutableFloatStateOf(1f) }

    var settings by remember { mutableStateOf(loadSettings(context)) }
    var showSettings by remember { mutableStateOf(false) }
    var supportedQualities by remember { mutableStateOf<List<Quality>>(emptyList()) }
    var maxFps by remember { mutableIntStateOf(30) }
    var manualRanges by remember { mutableStateOf<ManualRanges?>(null) }
    var bindCount by remember { mutableIntStateOf(0) }
    var aeLocked by remember { mutableStateOf(false) }
    var focusTick by remember { mutableIntStateOf(0) }
    var qualityModes by remember { mutableStateOf<QualityModes?>(null) }
    var extensionsInfo by remember { mutableStateOf("กำลังตรวจ...") }
    // true เมื่อเครื่องรองรับ Portrait/Bokeh จริงผ่าน CameraX Extensions สำหรับกล้องตัวที่ใช้อยู่
    var portraitAvailable by remember { mutableStateOf(false) }
    // ไทม์แลปส์: ลูปถ่ายภาพเป็นระยะ แล้วประกอบเป็นวิดีโอ MP4 อัตโนมัติตอนกดหยุด
    var timelapseJob by remember { mutableStateOf<Job?>(null) }
    var timelapseShots by remember { mutableIntStateOf(0) }
    val timelapseUris = remember { mutableStateListOf<Uri>() }
    var timelapseAssembling by remember { mutableStateOf(false) }

    var panelExpanded by remember { mutableStateOf(false) }
    var panel by remember {
        mutableStateOf(
            QuickPanelState(
                aspectLabel = "4:3",
                evIndex = if (settings.preserveExposure) settings.lastEv else 0
            )
        )
    }

    var countdown by remember { mutableStateOf<Int?>(null) }
    var countdownJob by remember { mutableStateOf<Job?>(null) }

    var focusPoint by remember { mutableStateOf<Offset?>(null) }
    var focusVisible by remember { mutableStateOf(false) }

    var lastUri by remember { mutableStateOf<Uri?>(null) }
    var thumb by remember { mutableStateOf<Bitmap?>(null) }
    var showInfo by remember { mutableStateOf(false) }
    var mode by remember {
        mutableStateOf(if (settings.preserveMode && settings.lastMode == 1) CamMode.VIDEO else CamMode.PHOTO)
    }
    var videoCapture by remember { mutableStateOf<VideoCapture<Recorder>?>(null) }
    var recording by remember { mutableStateOf<Recording?>(null) }
    var recordSeconds by remember { mutableLongStateOf(0L) }
    val usesVideoPipeline = mode == CamMode.VIDEO || mode == CamMode.SLOMO
    // โหมดวิดีโอ/สโลโมชันใช้ 16:9 เสมอ
    val effAspect = if (usesVideoPipeline) "16:9" else panel.aspectLabel
    // สไตล์ภาพที่จะฝังลงไฟล์วิดีโอจริง (มีผลเฉพาะตอนอยู่โหมดวิดีโอ/สโลโมชันเท่านั้น กันไม่ให้การเปลี่ยน
    // สไตล์ตอนอยู่โหมดภาพถ่ายไปสั่งผูกกล้องใหม่โดยไม่จำเป็น)
    val videoEffectStyle = if (usesVideoPipeline) panel.style else PhotoStyle.STANDARD

    // ---- ผูกกล้อง: ทำใหม่ทุกครั้งที่สลับกล้องหรือเปลี่ยนสัดส่วนภาพ ----
    LaunchedEffect(lens, effAspect, mode, settings.videoQuality, settings.videoFps, settings.maxResolution, videoEffectStyle) {
        try {
            val future = ProcessCameraProvider.getInstance(context)
            val provider = suspendCancellableCoroutine<ProcessCameraProvider> { cont ->
                future.addListener({ cont.resume(future.get()) }, mainExecutor)
            }

            val strategy = if (effAspect == "16:9") {
                AspectRatioStrategy.RATIO_16_9_FALLBACK_AUTO_STRATEGY
            } else {
                AspectRatioStrategy.RATIO_4_3_FALLBACK_AUTO_STRATEGY
            }
            val selector = ResolutionSelector.Builder().setAspectRatioStrategy(strategy).build()
            // ภาพนิ่ง: ถ้าเปิดตัวเลือก 'ความละเอียดสูงสุด' จะขอใช้โหมดความละเอียดสูงของเซนเซอร์ (ถ้าเครื่องเปิดให้)
            val stillSelector = ResolutionSelector.Builder()
                .setAspectRatioStrategy(strategy)
                .apply {
                    if (settings.maxResolution) {
                        setAllowedResolutionMode(ResolutionSelector.PREFER_HIGHER_RESOLUTION_OVER_CAPTURE_RATE)
                    }
                }
                .build()

            val preview = Preview.Builder().setResolutionSelector(selector).build()
            preview.surfaceProvider = previewView.surfaceProvider
            // ViewPort ทำให้ภาพ/วิดีโอที่บันทึกถูกครอปตรงกับที่เห็นในพรีวิว
            val (w, h) = when (effAspect) {
                "16:9" -> 9 to 16
                "1:1" -> 1 to 1
                else -> 3 to 4
            }
            val groupBuilder = UseCaseGroup.Builder()
                .addUseCase(preview)
                .setViewPort(ViewPort.Builder(Rational(w, h), Surface.ROTATION_0).build())

            // ---- เช็คส่วนขยายกล้อง (HDR/กลางคืน/โบเก้ ฯลฯ) ก่อนผูกกล้อง เพื่อเลือกกล้องแบบมีโบเก้ให้โหมดภาพเหมือน ----
            val baseSelector = CameraSelector.Builder().requireLensFacing(lens).build()
            val extManager = try {
                val extFuture = ExtensionsManager.getInstanceAsync(context, provider)
                suspendCancellableCoroutine<ExtensionsManager> { cont ->
                    extFuture.addListener({
                        try {
                            cont.resume(extFuture.get())
                        } catch (t: Exception) {
                            cont.resumeWithException(t)
                        }
                    }, mainExecutor)
                }
            } catch (t: Exception) {
                null
            }
            val bokehAvailable = extManager?.isExtensionAvailable(baseSelector, ExtensionMode.BOKEH) == true
            portraitAvailable = bokehAvailable
            val finalSelector = if (mode == CamMode.PORTRAIT && bokehAvailable && extManager != null) {
                extManager.getExtensionEnabledCameraSelector(baseSelector, ExtensionMode.BOKEH)
            } else {
                baseSelector
            }
            if (mode == CamMode.PORTRAIT && !bokehAvailable) {
                Toast.makeText(
                    context,
                    "เครื่องนี้ไม่รองรับโหมดภาพเหมือนแบบฮาร์ดแวร์ ระบบจะถ่ายภาพปกติแทน",
                    Toast.LENGTH_SHORT
                ).show()
            }

            // โหมดภาพถ่าย/ภาพเหมือน/พาโนรามา = พรีวิว+ถ่ายภาพ / โหมดวิดีโอ/สโลโมชัน = พรีวิว+อัดวิดีโอ
            // ไทม์แลปส์ใช้กลไกถ่ายภาพซ้ำ ๆ จึงผูกเป็นโหมดถ่ายภาพเช่นกัน
            var capture: ImageCapture? = null
            var video: VideoCapture<Recorder>? = null
            if (usesVideoPipeline) {
                val vq = when (settings.videoQuality) {
                    0 -> Quality.UHD
                    2 -> Quality.HD
                    else -> Quality.FHD
                }
                val recorder = Recorder.Builder()
                    .setQualitySelector(
                        QualitySelector.from(vq, FallbackStrategy.lowerQualityOrHigherThan(vq))
                    )
                    .build()
                val vcBuilder = VideoCapture.Builder(recorder)
                // สโลโมชัน: ขอเฟรมเรตสูงสุดที่รอบก่อนหน้าตรวจเจอ (ไฟล์จะช้าลงเองถ้าเปิดด้วยแอปที่รู้เฟรมเรตจริง)
                val targetFps = when {
                    mode == CamMode.SLOMO && maxFps >= 120 -> 120
                    mode == CamMode.SLOMO && maxFps >= 60 -> 60
                    settings.videoFps >= 60 -> 60
                    else -> 0
                }
                if (targetFps > 0) vcBuilder.setTargetFrameRate(Range(targetFps, targetFps))
                vcBuilder.setTargetRotation(deviceRotation)
                val vc = vcBuilder.build()
                video = vc
                groupBuilder.addUseCase(vc)
                // ฝังสไตล์ภาพลงไฟล์วิดีโอจริง (ก่อนหน้านี้สไตล์มีผลแค่พรีวิว/ภาพนิ่ง ไม่ติดไปกับวิดีโอ)
                // ถ้าสร้าง effect ไม่สำเร็จ (เครื่อง/ไดรเวอร์ไม่รองรับ) จะข้ามไปเงียบๆ อัดวิดีโอแบบไม่มีสไตล์แทน
                if (videoEffectStyle != PhotoStyle.STANDARD) {
                    createVideoStyleEffect(videoEffectStyle)?.let { groupBuilder.addEffect(it) }
                }
            } else {
                val cap = ImageCapture.Builder()
                    .setResolutionSelector(stillSelector)
                    // เน้นคุณภาพมากกว่าความเร็วในการถ่าย
                    .setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY)
                    .setJpegQuality(97)
                    .setFlashMode(flashMode)
                    .setTargetRotation(deviceRotation)
                    .build()
                capture = cap
                groupBuilder.addUseCase(cap)
            }

            provider.unbindAll()
            val cam = provider.bindToLifecycle(
                lifecycleOwner,
                finalSelector,
                groupBuilder.build()
            )
            camera = cam
            imageCapture = capture
            videoCapture = video
            supportedQualities = QualitySelector.getSupportedQualities(cam.cameraInfo)
            maxFps = cam.cameraInfo.supportedFrameRateRanges.maxOfOrNull { it.upper } ?: 30
            manualRanges = runCatching { readManualRanges(cam) }.getOrNull()
            qualityModes = runCatching { readQualityModes(cam) }.getOrNull()
            bindCount++

            val zs = cam.cameraInfo.zoomState.value
            minZoom = zs?.minZoomRatio ?: 1f
            maxZoom = zs?.maxZoomRatio ?: 1f
            zoom = zs?.zoomRatio ?: 1f
            // โหมดพาโนรามา (ต้นแบบ): กางกล้องไปมุมกว้างสุดที่เครื่องมีให้อัตโนมัติ
            if (mode == CamMode.PANO) {
                camera?.cameraControl?.setZoomRatio(minZoom)
            }

            extensionsInfo = if (extManager != null) {
                listOf(
                    "HDR" to ExtensionMode.HDR,
                    "กลางคืน" to ExtensionMode.NIGHT,
                    "อัตโนมัติ" to ExtensionMode.AUTO,
                    "โบเก้" to ExtensionMode.BOKEH,
                    "แต่งหน้า" to ExtensionMode.FACE_RETOUCH
                ).joinToString("  ") { (n, m) ->
                    n + " " + (if (extManager.isExtensionAvailable(baseSelector, m)) "ได้" else "ไม่ได้")
                }
            } else {
                "ตรวจไม่ได้"
            }
        } catch (e: Exception) {
            Toast.makeText(context, "เปิดกล้องไม่ได้: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    // อัปเดตองศาการบันทึกทุกครั้งที่เครื่องหมุน หรือทุกครั้งที่ผูกกล้องใหม่ (imageCapture/videoCapture ตัวใหม่)
    // เพื่อให้ภาพ/วิดีโอที่ได้อยู่ในแนวตั้ง/แนวนอน/ตะแคงถูกต้องตามที่ถือเครื่องจริงเสมอ
    LaunchedEffect(deviceRotation, imageCapture, videoCapture) {
        imageCapture?.targetRotation = deviceRotation
        videoCapture?.targetRotation = deviceRotation
    }
    LaunchedEffect(flashMode, imageCapture) { imageCapture?.flashMode = flashMode }
    // ในโหมดวิดีโอ/สโลโมชัน ปุ่มแฟลชทำหน้าที่เปิด/ปิดไฟฉาย
    LaunchedEffect(mode, flashMode, camera) {
        val usesVideo = mode == CamMode.VIDEO || mode == CamMode.SLOMO
        camera?.cameraControl?.enableTorch(usesVideo && flashMode == ImageCapture.FLASH_MODE_ON)
    }
    // ไทม์แลปส์: ถ้าออกจากโหมดไทม์แลปส์ ให้หยุดลูปถ่ายภาพเสมอ (timelapseJob จะไม่เป็น null ก็ต่อเมื่ออยู่โหมดนี้)
    DisposableEffect(mode) {
        onDispose {
            timelapseJob?.cancel()
            timelapseJob = null
        }
    }
    DisposableEffect(Unit) { onDispose { recording?.stop() } }
    LaunchedEffect(mode, panel.evIndex) {
        val n = settings.copy(lastMode = if (mode == CamMode.VIDEO) 1 else 0, lastEv = panel.evIndex)
        if (n != settings) {
            settings = n
            saveSettings(context, n)
        }
    }
    LaunchedEffect(panel.evIndex, bindCount) {
        camera?.cameraControl?.setExposureCompensationIndex(panel.evIndex)
    }
    // แมนนวล ISO/ชัตเตอร์ (ใช้ค่าที่กล้องรองรับเท่านั้น)
    LaunchedEffect(bindCount, mode, panel.manualOn, panel.iso, panel.shutterNs) {
        val cam = camera ?: return@LaunchedEffect
        val r = manualRanges
        val iso = if (r != null) panel.iso.coerceIn(r.iso.first, r.iso.last) else panel.iso
        val shutter = if (r != null) panel.shutterNs.coerceIn(r.shutterNs.first, r.shutterNs.last) else panel.shutterNs
        val q = qualityModes
        // ขอคุณภาพความคมชัด/ลดสัญญาณรบกวนสูงสุด (EDGE_MODE / NOISE_REDUCTION_MODE = HIGH_QUALITY)
        // ในทุกโหมดที่ถ่ายภาพนิ่ง (ภาพถ่าย/ภาพเหมือน/พาโนรามา/ไทม์แลปส์) ไม่ใช่แค่โหมดภาพถ่ายธรรมดา
        // เพราะนี่คือค่าสูงสุดที่ Camera2 API เปิดให้ปรับได้แล้วในทุกกรณีที่ไม่ใช่วิดีโอ
        val stillPhoto = !usesVideoPipeline
        runCatching {
            applyCaptureOptions(
                cam,
                panel.manualOn,
                iso,
                shutter,
                edgeHq = stillPhoto && q?.edgeHq == true,
                noiseHq = stillPhoto && q?.noiseHq == true,
                stabilizeVideo = mode == CamMode.VIDEO || mode == CamMode.SLOMO
            )
        }
    }

    // กรอบโฟกัสหายเองหลัง 3 วินาที (ต่ออายุทุกครั้งที่แตะหรือลากปรับแสง) ถ้าล็อกไว้จะไม่หาย
    LaunchedEffect(focusTick) {
        if (focusPoint != null) {
            focusVisible = true
            if (!aeLocked) {
                delay(3000)
                focusVisible = false
            }
        }
    }
    LaunchedEffect(lastUri) {
        val uri = lastUri ?: return@LaunchedEffect
        thumb = withContext(Dispatchers.IO) {
            runCatching { context.contentResolver.loadThumbnail(uri, Size(256, 256), null) }.getOrNull()
        }
    }

    // ---- ถ่ายภาพ ----
    // relativePath: โฟลเดอร์ปลายทาง (ไทม์แลปส์แยกไปคนละโฟลเดอร์)
    // silent: ไทม์แลปส์ไม่อยากเด้ง Toast ทุกภาพ
    fun takePhoto(
        relativePath: String = "Pictures/ProCamera",
        silent: Boolean = false,
        onSaved: (Uri) -> Unit = {}
    ) {
        val cap = imageCapture ?: return
        val name = SimpleDateFormat("yyyyMMdd_HHmmss_SSS", Locale.US).format(System.currentTimeMillis())
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, "IMG_$name")
            put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                put(MediaStore.MediaColumns.RELATIVE_PATH, relativePath)
            }
        }
        val output = ImageCapture.OutputFileOptions.Builder(
            context.contentResolver,
            MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
            values
        )
            .setMetadata(
                ImageCapture.Metadata().apply {
                    isReversedHorizontal = lens == CameraSelector.LENS_FACING_FRONT && settings.mirrorFront
                }
            )
            .build()
        val styleAtCapture = panel.style
        cap.takePicture(output, mainExecutor, object : ImageCapture.OnImageSavedCallback {
            override fun onImageSaved(result: ImageCapture.OutputFileResults) {
                val saved = result.savedUri
                // ไทม์แลปส์ (silent = true) ไม่ควรทำให้ภาพย่อมุมล่างกระพริบเปลี่ยนทุกไม่กี่วินาที
                // อัปเดตภาพย่อเฉพาะภาพ/วิดีโอที่ผู้ใช้ตั้งใจถ่ายจริง ๆ เท่านั้น
                if (!silent) lastUri = saved
                if (saved != null) {
                    onSaved(saved)
                    scope.launch(Dispatchers.IO) {
                        // ใส่สไตล์ภาพ (ถ้าไม่ใช่มาตรฐาน) และปรับคมชัดภาพที่บันทึกลงเครื่องเสมอทุกครั้ง
                        // ไม่ว่าจะเลือกสไตล์อะไรก็ตาม ตามที่ขอ
                        runCatching { finalizeSavedImage(context, saved, styleAtCapture) }
                        if (settings.showFileInfo && !silent) {
                            val info = describePhoto(context, saved)
                            if (info != null) {
                                withContext(Dispatchers.Main) {
                                    Toast.makeText(context, "บันทึกแล้ว: $info", Toast.LENGTH_SHORT).show()
                                }
                            }
                        }
                    }
                }
            }

            override fun onError(exc: ImageCaptureException) {
                if (!silent) {
                    Toast.makeText(context, "บันทึกภาพไม่สำเร็จ: ${exc.message}", Toast.LENGTH_SHORT).show()
                }
            }
        })
    }

    // ---- ไทม์แลปส์: ถ่ายภาพซ้ำตามช่วงเวลาที่ตั้งไว้ จนกว่าจะกดหยุด แล้วประกอบเป็นวิดีโอ MP4 อัตโนมัติ ----
    fun toggleTimelapse() {
        val active = timelapseJob
        if (active != null) {
            active.cancel()
            timelapseJob = null
            val shotsToAssemble = timelapseUris.toList()
            Toast.makeText(
                context,
                "หยุดไทม์แลปส์ ถ่ายไป ${shotsToAssemble.size} ภาพ กำลังประกอบเป็นวิดีโอ...",
                Toast.LENGTH_SHORT
            ).show()
            if (shotsToAssemble.size >= 2) {
                timelapseAssembling = true
                scope.launch(Dispatchers.Default) {
                    val name = "TIMELAPSE_" +
                        SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(System.currentTimeMillis())
                    val resultUri = runCatching {
                        TimelapseEncoder.assemble(context, shotsToAssemble, fps = 30, outputDisplayName = name)
                    }.getOrNull()
                    withContext(Dispatchers.Main) {
                        timelapseAssembling = false
                        if (resultUri != null) {
                            lastUri = resultUri
                            Toast.makeText(
                                context,
                                "ประกอบไทม์แลปส์เสร็จแล้ว (ภาพต้นฉบับยังอยู่ใน Pictures/ProCamera/Timelapse)",
                                Toast.LENGTH_LONG
                            ).show()
                        } else {
                            Toast.makeText(
                                context,
                                "ประกอบวิดีโอไทม์แลปส์ไม่สำเร็จ ภาพต้นฉบับยังอยู่ใน Pictures/ProCamera/Timelapse",
                                Toast.LENGTH_LONG
                            ).show()
                        }
                    }
                }
            }
            return
        }
        timelapseShots = 0
        timelapseUris.clear()
        timelapseJob = scope.launch {
            while (isActive) {
                takePhoto(relativePath = "Pictures/ProCamera/Timelapse", silent = true) { uri ->
                    timelapseUris.add(uri)
                }
                timelapseShots++
                delay(settings.timelapseIntervalSec * 1000L)
            }
        }
        Toast.makeText(
            context,
            "เริ่มไทม์แลปส์ ทุก ${settings.timelapseIntervalSec} วินาที (จะประกอบเป็นวิดีโอให้อัตโนมัติตอนกดหยุด)",
            Toast.LENGTH_LONG
        ).show()
    }

    // ---- อัดวิดีโอ: แตะครั้งแรกเริ่มอัด แตะอีกครั้งหยุด ----
    fun toggleRecording() {
        val active = recording
        if (active != null) {
            active.stop()
            return
        }
        val vc = videoCapture ?: return
        val name = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(System.currentTimeMillis())
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, "VID_$name")
            put(MediaStore.MediaColumns.MIME_TYPE, "video/mp4")
            put(MediaStore.MediaColumns.RELATIVE_PATH, "Movies/ProCamera")
        }
        val options = MediaStoreOutputOptions.Builder(
            context.contentResolver,
            MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        ).setContentValues(values).build()
        var pending = vc.output.prepareRecording(context, options)
        val hasMic = ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) ==
            PackageManager.PERMISSION_GRANTED
        if (hasMic) pending = pending.withAudioEnabled()
        recordSeconds = 0L
        // จำโหมด ณ ตอนเริ่มอัด ไว้ใช้ตอนอัดเสร็จ (เผื่อผู้ใช้สลับโหมดระหว่างอัดวิดีโอ)
        val recordingMode = mode
        recording = pending.start(mainExecutor) { event ->
            when (event) {
                is VideoRecordEvent.Status -> {
                    recordSeconds = event.recordingStats.recordedDurationNanos / 1_000_000_000L
                }
                is VideoRecordEvent.Finalize -> {
                    recording = null
                    if (event.hasError()) {
                        Toast.makeText(context, "บันทึกวิดีโอไม่สำเร็จ (รหัส ${event.error})", Toast.LENGTH_SHORT).show()
                    } else {
                        val savedUri = event.outputResults.outputUri
                        lastUri = savedUri
                        scope.launch(Dispatchers.IO) {
                            val info = describeVideo(context, savedUri)
                            if (info != null && settings.showFileInfo) {
                                withContext(Dispatchers.Main) {
                                    Toast.makeText(context, "บันทึกแล้ว: $info", Toast.LENGTH_LONG).show()
                                }
                            }
                            // สโลโมชัน: ทำให้ไฟล์เล่นช้าลงจริงตามเฟรมเรตที่วัดได้ (ไม่ใช่แค่บันทึกเฟรมเรตสูงเฉย ๆ)
                            if (recordingMode == CamMode.SLOMO) {
                                withContext(Dispatchers.Main) {
                                    Toast.makeText(context, "กำลังทำสโลโมชัน...", Toast.LENGTH_SHORT).show()
                                }
                                val slomoName = "VID_SLOMO_" +
                                    SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(System.currentTimeMillis())
                                val retimed = runCatching {
                                    SlowMotionRetimer.retime(context, savedUri, outputDisplayName = slomoName)
                                }.getOrNull()
                                withContext(Dispatchers.Main) {
                                    if (retimed != null) {
                                        lastUri = retimed
                                        // ไฟล์ต้นฉบับเล่นเร็วปกติ ไม่มีประโยชน์แยกไว้ ลบทิ้งเมื่อ retime สำเร็จแล้ว
                                        runCatching { context.contentResolver.delete(savedUri, null, null) }
                                        Toast.makeText(context, "ทำสโลโมชันเสร็จแล้ว (ไม่มีเสียง)", Toast.LENGTH_LONG).show()
                                    } else {
                                        Toast.makeText(
                                            context,
                                            "ทำสโลโมชันไม่สำเร็จ เก็บไฟล์ต้นฉบับ (เล่นเร็วปกติ) ไว้แทน",
                                            Toast.LENGTH_LONG
                                        ).show()
                                    }
                                }
                            }
                        }
                    }
                }
                else -> {}
            }
        }
        if (!hasMic) {
            Toast.makeText(context, "ยังไม่ได้อนุญาตไมโครโฟน วิดีโอจะไม่มีเสียง", Toast.LENGTH_SHORT).show()
        }
    }

    // แตะชัตเตอร์ซ้ำระหว่างนับถอยหลัง = ยกเลิก
    fun onShutter() {
        if (mode == CamMode.VIDEO || mode == CamMode.SLOMO) {
            toggleRecording()
            return
        }
        if (mode == CamMode.TIMELAPSE) {
            toggleTimelapse()
            return
        }
        // ภาพถ่าย / ภาพเหมือน / พาโนรามา ใช้เส้นทางถ่ายภาพเดียวกัน
        if (countdownJob != null) {
            countdownJob?.cancel()
            countdownJob = null
            countdown = null
            return
        }
        val sec = panel.timerSec
        if (sec == 0) {
            takePhoto()
            return
        }
        countdownJob = scope.launch {
            for (i in sec downTo 1) {
                countdown = i
                delay(1000)
            }
            countdown = null
            countdownJob = null
            takePhoto()
        }
    }

    val ratio = when (effAspect) {
        "16:9" -> 9f / 16f
        "1:1" -> 1f
        else -> 3f / 4f
    }
    // รวมสเต็ปซูมไกลเข้าไปด้วยถ้าเครื่องรองรับ (Honor 400 เคลมซูมดิจิทัลได้ถึง 30x)
    val zoomSteps = remember(minZoom, maxZoom) {
        listOf(0.5f, 1f, 2f, 3f, 5f, 10f).filter { it >= minZoom - 0.01f && it <= maxZoom + 0.01f }
    }
    val busy = recording != null || timelapseJob != null

    Box(Modifier.fillMaxSize().background(Color.Black)) {

        // ---- พรีวิว ----
        Box(
            Modifier
                .align(Alignment.TopCenter)
                .padding(top = if (effAspect == "16:9") 0.dp else 88.dp)
                .fillMaxWidth()
                .aspectRatio(ratio)
                .pointerInput(camera) {
                    detectTapGestures(
                        // แตะค้าง = ล็อกโฟกัสและแสง จนกว่าจะแตะที่อื่น
                        onLongPress = { offset ->
                            val point = previewView.meteringPointFactory.createPoint(offset.x, offset.y)
                            val action = FocusMeteringAction.Builder(
                                point,
                                FocusMeteringAction.FLAG_AF or FocusMeteringAction.FLAG_AE
                            ).disableAutoCancel().build()
                            camera?.cameraControl?.startFocusAndMetering(action)
                            aeLocked = true
                            focusPoint = offset
                            focusTick++
                        },
                        onTap = { offset ->
                            if (panelExpanded) panelExpanded = false
                            val point = previewView.meteringPointFactory.createPoint(offset.x, offset.y)
                            val action = FocusMeteringAction.Builder(
                                point,
                                FocusMeteringAction.FLAG_AF or FocusMeteringAction.FLAG_AE
                            ).setAutoCancelDuration(3, TimeUnit.SECONDS).build()
                            camera?.cameraControl?.startFocusAndMetering(action)
                            aeLocked = false
                            focusPoint = offset
                            focusTick++
                        }
                    )
                }
                // สองนิ้ว = บีบซูม / นิ้วเดียวปัดซ้าย-ขวา = เลื่อนโหมดในแถบล่าง (แบบ iPhone)
                .pointerInput(camera, minZoom, maxZoom, mode, busy) {
                    awaitEachGesture {
                        awaitFirstDown(requireUnconsumed = false)
                        var swipeX = 0f
                        var multi = false
                        do {
                            val event = awaitPointerEvent()
                            val pressed = event.changes.count { it.pressed }
                            if (pressed >= 2) {
                                multi = true
                                val z = event.calculateZoom()
                                if (z != 1f) {
                                    zoom = (zoom * z).coerceIn(minZoom, maxZoom)
                                    camera?.cameraControl?.setZoomRatio(zoom)
                                }
                                event.changes.forEach { it.consume() }
                            } else if (!multi && pressed == 1) {
                                swipeX += event.calculatePan().x
                                if (kotlin.math.abs(swipeX) > viewConfiguration.touchSlop) {
                                    event.changes.forEach { it.consume() }
                                }
                            }
                        } while (event.changes.any { it.pressed })
                        if (!multi && !busy) {
                            val threshold = 80.dp.toPx()
                            val idx = ModeOrder.indexOfFirst { it.first == mode }.coerceAtLeast(0)
                            if (swipeX > threshold && idx > 0) {
                                mode = ModeOrder[idx - 1].first
                            } else if (swipeX < -threshold && idx < ModeOrder.lastIndex) {
                                mode = ModeOrder[idx + 1].first
                            }
                        }
                    }
                }
        ) {
            AndroidView(
                factory = { previewView },
                modifier = Modifier.fillMaxSize().styleColorFilter(panel.style)
            )
            if (settings.grid) GridOverlay()
            if (settings.level) LevelOverlay()

            val fp = focusPoint
            AnimatedVisibility(
                visible = fp != null && focusVisible,
                enter = fadeIn(),
                exit = fadeOut()
            ) {
                if (fp != null) {
                    Box(
                        Modifier
                            .offset { IntOffset((fp.x - 40.dp.toPx()).roundToInt(), (fp.y - 40.dp.toPx()).roundToInt()) }
                            .size(80.dp)
                    ) {
                        Box(Modifier.size(80.dp).border(1.dp, CamYellow, RoundedCornerShape(2.dp)))

                        if (aeLocked) {
                            Text(
                                "ล็อกแสง/โฟกัส",
                                color = Color.Black,
                                fontSize = 11.sp,
                                modifier = Modifier
                                    .align(Alignment.TopCenter)
                                    .offset(y = (-26).dp)
                                    .requiredSize(width = 96.dp, height = 20.dp)
                                    .clip(RoundedCornerShape(50))
                                    .background(CamYellow)
                                    .padding(top = 3.dp)
                            )
                        }

                        // ก้านปรับความสว่าง: ลากดวงอาทิตย์ขึ้น/ลง (ขึ้น = สว่างขึ้น)
                        val evR = camera?.cameraInfo?.exposureState?.exposureCompensationRange
                        if (evR != null && evR.upper > evR.lower) {
                            val frac = (panel.evIndex - evR.lower).toFloat() / (evR.upper - evR.lower)
                            val sunY = ((0.5f - frac) * 100f).dp
                            Box(
                                Modifier
                                    .align(Alignment.CenterEnd)
                                    .offset(x = 30.dp)
                                    .requiredSize(width = 40.dp, height = 130.dp)
                                    .pointerInput(evR) {
                                        var acc = 0f
                                        detectVerticalDragGestures(
                                            onDragStart = { acc = panel.evIndex.toFloat() },
                                            onVerticalDrag = { change, dy ->
                                                change.consume()
                                                acc = (acc - dy / 8.dp.toPx())
                                                    .coerceIn(evR.lower.toFloat(), evR.upper.toFloat())
                                                panel = panel.copy(evIndex = acc.roundToInt())
                                                focusTick++
                                            }
                                        )
                                    },
                                contentAlignment = Alignment.Center
                            ) {
                                Box(
                                    Modifier
                                        .width(1.dp)
                                        .fillMaxHeight()
                                        .background(CamYellow.copy(alpha = 0.6f))
                                )
                                Icon(
                                    Icons.Rounded.WbSunny,
                                    contentDescription = null,
                                    tint = CamYellow,
                                    modifier = Modifier
                                        .offset(y = sunY)
                                        .size(24.dp)
                                        .background(Color.Black.copy(alpha = 0.35f), CircleShape)
                                        .padding(2.dp)
                                )
                            }
                        }
                    }
                }
            }

            countdown?.let {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("$it", color = Color.White, fontSize = 72.sp)
                }
            }

            if (timelapseAssembling) {
                Box(Modifier.fillMaxWidth().padding(top = 10.dp), contentAlignment = Alignment.TopCenter) {
                    Text(
                        "กำลังประกอบวิดีโอไทม์แลปส์...",
                        color = Color.Black,
                        fontSize = 12.sp,
                        modifier = Modifier
                            .clip(RoundedCornerShape(50))
                            .background(CamYellow)
                            .padding(horizontal = 14.dp, vertical = 6.dp)
                    )
                }
            }
        }

        // ---- หน้าต่างข้อมูลกล้อง (ชั่วคราว ใช้ตรวจว่าเครื่องเปิดกล้องอัลตราไวด์ให้แอปไหม) ----
        if (showInfo) {
            AlertDialog(
                onDismissRequest = { showInfo = false },
                confirmButton = { TextButton(onClick = { showInfo = false }) { Text("ปิด") } },
                title = { Text("ข้อมูลกล้องของเครื่อง") },
                text = {
                    Column(Modifier.verticalScroll(rememberScrollState())) {
                        Text(
                            remember(extensionsInfo) {
                                describeCameras(context) + "\nส่วนขยายกล้อง: " + extensionsInfo
                            },
                            fontSize = 12.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            )
        }

        // ---- แถบบน: แฟลช ... ตั้งค่า ----
        Row(
            Modifier
                .align(Alignment.TopCenter)
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            GlassIconButton(
                icon = when (flashMode) {
                    ImageCapture.FLASH_MODE_ON -> Icons.Rounded.FlashOn
                    ImageCapture.FLASH_MODE_AUTO -> Icons.Rounded.FlashAuto
                    else -> Icons.Rounded.FlashOff
                },
                tint = if (flashMode == ImageCapture.FLASH_MODE_OFF) Color.White else CamYellow
            ) {
                flashMode = if (usesVideoPipeline) {
                    if (flashMode == ImageCapture.FLASH_MODE_OFF) ImageCapture.FLASH_MODE_ON else ImageCapture.FLASH_MODE_OFF
                } else when (flashMode) {
                    ImageCapture.FLASH_MODE_OFF -> ImageCapture.FLASH_MODE_AUTO
                    ImageCapture.FLASH_MODE_AUTO -> ImageCapture.FLASH_MODE_ON
                    else -> ImageCapture.FLASH_MODE_OFF
                }
            }
            if (recording != null) {
                Text(
                    text = "● " + "%02d:%02d".format(recordSeconds / 60, recordSeconds % 60),
                    color = Color(0xFFFF3B30),
                    fontSize = 15.sp,
                    modifier = Modifier
                        .clip(RoundedCornerShape(50))
                        .background(Color.Black.copy(alpha = 0.45f))
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                )
            } else if (timelapseJob != null) {
                Text(
                    text = "● ไทม์แลปส์ $timelapseShots ภาพ",
                    color = CamYellow,
                    fontSize = 14.sp,
                    modifier = Modifier
                        .clip(RoundedCornerShape(50))
                        .background(Color.Black.copy(alpha = 0.45f))
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                )
            }
            GlassIconButton(icon = Icons.Rounded.Settings) { showSettings = true }
        }

        // ---- ส่วนล่าง ----
        Column(
            Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(bottom = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            val exp = camera?.cameraInfo?.exposureState
            QuickPanel(
                expanded = panelExpanded,
                onExpandedChange = { panelExpanded = it },
                state = panel,
                onStateChange = { panel = it },
                evRange = exp?.exposureCompensationRange?.let { it.lower..it.upper } ?: 0..0,
                evStep = exp?.exposureCompensationStep?.toFloat() ?: 0f,
                isoRange = manualRanges?.iso,
                shutterRangeNs = manualRanges?.shutterNs,
                aspectOptions = if (usesVideoPipeline || mode == CamMode.TIMELAPSE) emptyList() else listOf("4:3", "16:9", "1:1"),
                blurAvailable = mode == CamMode.PORTRAIT && portraitAvailable,
                showTimer = mode == CamMode.PHOTO || mode == CamMode.PORTRAIT || mode == CamMode.PANO
            )

            // ปุ่มเลือกซูมแบบแคปซูล
            if (zoomSteps.size > 1) {
                Row(
                    Modifier
                        .clip(RoundedCornerShape(50))
                        .background(Color.Black.copy(alpha = 0.35f))
                        .padding(3.dp),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    zoomSteps.forEach { z ->
                        val selected = kotlin.math.abs(zoom - z) < 0.25f
                        Text(
                            text = (if (z < 1f) "0.5" else z.toInt().toString()) + if (selected) "×" else "",
                            color = if (selected) CamYellow else Color.White,
                            fontSize = if (selected) 13.sp else 12.sp,
                            modifier = Modifier
                                .clip(CircleShape)
                                .background(if (selected) Color.Black.copy(alpha = 0.5f) else Color.Transparent)
                                .clickable {
                                    zoom = z
                                    camera?.cameraControl?.setZoomRatio(z)
                                }
                                .padding(horizontal = 11.dp, vertical = 7.dp)
                        )
                    }
                }
            }

            // แถบโหมด: ครบ 6 โหมดแบบ iPhone เลื่อนดูได้ ปัดบนพรีวิวก็เปลี่ยนโหมดได้เหมือนกัน
            val modeListState = rememberLazyListState()
            LaunchedEffect(mode) {
                val idx = ModeOrder.indexOfFirst { it.first == mode }
                if (idx >= 0) modeListState.animateScrollToItem(idx.coerceAtMost(ModeOrder.lastIndex))
            }
            LazyRow(
                state = modeListState,
                horizontalArrangement = Arrangement.spacedBy(22.dp),
                contentPadding = PaddingValues(horizontal = 140.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                items(ModeOrder) { (m, label) ->
                    Text(
                        label,
                        color = if (mode == m) CamYellow else Color.White.copy(alpha = 0.65f),
                        fontSize = 14.sp,
                        fontWeight = if (mode == m) FontWeight.SemiBold else FontWeight.Normal,
                        modifier = Modifier.clickable(enabled = !busy) { mode = m }
                    )
                }
            }

            // ภาพย่อ | ชัตเตอร์ | สลับกล้อง
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 28.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                val t = thumb
                if (t != null) {
                    Image(
                        bitmap = t.asImageBitmap(),
                        contentDescription = null,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .size(52.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .border(1.dp, Color.White.copy(alpha = 0.5f), RoundedCornerShape(12.dp))
                            .clickable {
                                lastUri?.let { uri ->
                                    try {
                                        context.startActivity(
                                            Intent(Intent.ACTION_VIEW, uri)
                                                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                        )
                                    } catch (e: Exception) {
                                        Toast.makeText(context, "เปิดแกลเลอรีไม่ได้", Toast.LENGTH_SHORT).show()
                                    }
                                }
                            }
                    )
                } else {
                    Spacer(Modifier.size(52.dp))
                }

                // ชัตเตอร์: วงในขาว = ถ่ายภาพ / วงในแดง = อัดวิดีโอ/สโลโมชัน / สี่เหลี่ยมมน = กำลังอัด/ไทม์แลปส์
                val recordingNow = recording != null
                val timelapseRunning = timelapseJob != null
                val innerSize by animateDpAsState(if (recordingNow) 28.dp else 62.dp, label = "shutter")
                Box(
                    Modifier
                        .size(78.dp)
                        .border(3.dp, Color.White, CircleShape)
                        .clip(CircleShape)
                        .clickable { onShutter() },
                    contentAlignment = Alignment.Center
                ) {
                    Box(
                        Modifier
                            .size(innerSize)
                            .clip(if (recordingNow) RoundedCornerShape(8.dp) else CircleShape)
                            .background(
                                when {
                                    timelapseRunning -> CamYellow
                                    usesVideoPipeline -> Color(0xFFFF3B30)
                                    countdown != null -> CamYellow
                                    else -> Color.White
                                }
                            )
                    )
                }

                GlassIconButton(icon = Icons.Rounded.FlipCameraAndroid, size = 52.dp) {
                    if (busy) return@GlassIconButton
                    lens = if (lens == CameraSelector.LENS_FACING_BACK) {
                        CameraSelector.LENS_FACING_FRONT
                    } else {
                        CameraSelector.LENS_FACING_BACK
                    }
                }
            }
        }

        // ---- หน้าตั้งค่า (เปิดจากปุ่มเฟือง) ----
        if (showSettings) {
            BackHandler { showSettings = false }
            SettingsScreen(
                settings = settings,
                onChange = {
                    settings = it
                    saveSettings(context, it)
                },
                supportedQualities = supportedQualities,
                maxFps = maxFps,
                onOpenCameraInfo = { showInfo = true },
                onClose = { showSettings = false }
            )
        }
    }
}

// ---------------------------------------------------------------------
//  สไตล์ภาพ (Photographic Styles แบบง่าย): ปรับสี/ความอิ่มสีจริงทั้งพรีวิวและไฟล์ที่บันทึก
// ---------------------------------------------------------------------

// เมทริกซ์สีของแต่ละสไตล์ (android.graphics.ColorMatrix ใช้ได้ทั้งวาดพรีวิวและแต่งบิตแมปไฟล์จริง)
private fun PhotoStyle.toColorMatrix(): android.graphics.ColorMatrix {
    val cm = android.graphics.ColorMatrix()
    when (this) {
        PhotoStyle.STANDARD -> { /* ไม่ปรับอะไร */ }
        PhotoStyle.VIVID -> cm.setSaturation(1.45f)
        PhotoStyle.MONO -> cm.setSaturation(0f)
        PhotoStyle.WARM -> {
            cm.setSaturation(1.1f)
            cm.postConcat(
                android.graphics.ColorMatrix(
                    floatArrayOf(
                        1.08f, 0f, 0f, 0f, 8f,
                        0f, 1.02f, 0f, 0f, 2f,
                        0f, 0f, 0.90f, 0f, -6f,
                        0f, 0f, 0f, 1f, 0f
                    )
                )
            )
        }
        PhotoStyle.COOL -> {
            cm.setSaturation(1.1f)
            cm.postConcat(
                android.graphics.ColorMatrix(
                    floatArrayOf(
                        0.94f, 0f, 0f, 0f, -4f,
                        0f, 1.0f, 0f, 0f, 0f,
                        0f, 0f, 1.10f, 0f, 10f,
                        0f, 0f, 0f, 1f, 0f
                    )
                )
            )
        }
        // จำลองโทนแนวฟิล์มญี่ปุ่นยอดนิยม (ขำๆ ตามที่ขอ): ลดจัดสีลงนิด, ยกเงาให้ไม่ดำสนิท (ฟิล์มจริงมักไม่มีดำล้วน),
        // ใส่โทนอุ่นในไฮไลต์กับโทนเขียวอมฟ้าบางๆ ในเงามืด (split-tone) — เป็นการประมาณด้วยเมทริกซ์สีเชิงเส้น
        // ไม่ใช่โปรไฟล์สีลิขสิทธิ์ของกล้องแบรนด์ใดจริง
        PhotoStyle.FILM -> {
            cm.setSaturation(0.88f)
            cm.postConcat(
                android.graphics.ColorMatrix(
                    floatArrayOf(
                        0.92f, 0.04f, 0.02f, 0f, 12f,
                        0.02f, 0.90f, 0.03f, 0f, 9f,
                        0.02f, 0.05f, 0.85f, 0f, 14f,
                        0f, 0f, 0f, 1f, 0f
                    )
                )
            )
        }
    }
    return cm
}

// ทาสีทับพรีวิวสด ๆ ด้วยเมทริกซ์สีของสไตล์ที่เลือก (ใช้ saveLayer กับ Paint ปกติ รองรับทุกเวอร์ชัน)
private fun Modifier.styleColorFilter(style: PhotoStyle): Modifier {
    if (style == PhotoStyle.STANDARD) return this
    return this.drawWithContent {
        val paint = android.graphics.Paint().apply {
            colorFilter = android.graphics.ColorMatrixColorFilter(style.toColorMatrix())
        }
        drawIntoCanvas { canvas ->
            val native = canvas.nativeCanvas
            val count = native.saveLayer(null, paint)
            drawContent()
            native.restoreToCount(count)
        }
    }
}

// ตกแต่งไฟล์ภาพที่บันทึกจริงเสมอทุกครั้ง: ใส่สไตล์ภาพ (ถ้าไม่ใช่มาตรฐาน) แล้ว "ปรับคมชัด" เพิ่มเติมด้วย
// ตัวกรองคมชัด (unsharp mask) แบบซอฟต์แวร์เสมอ ไม่ว่าจะเลือกสไตล์ไหนก็ตาม เขียนทับไฟล์เดิม
// พร้อมคง EXIF การหมุนภาพไว้
private fun finalizeSavedImage(context: Context, uri: Uri, style: PhotoStyle) {
    val original = context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) } ?: return
    val exifOrientation = try {
        context.contentResolver.openInputStream(uri)?.use {
            androidx.exifinterface.media.ExifInterface(it).getAttributeInt(
                androidx.exifinterface.media.ExifInterface.TAG_ORIENTATION,
                androidx.exifinterface.media.ExifInterface.ORIENTATION_NORMAL
            )
        } ?: androidx.exifinterface.media.ExifInterface.ORIENTATION_NORMAL
    } catch (e: Exception) {
        androidx.exifinterface.media.ExifInterface.ORIENTATION_NORMAL
    }

    // ขั้น 1: ทาสไตล์ภาพ (ถ้าไม่ใช่มาตรฐานที่ไม่ต้องแก้อะไร)
    var edited = if (style != PhotoStyle.STANDARD) {
        val styled = Bitmap.createBitmap(original.width, original.height, Bitmap.Config.ARGB_8888)
        val canvas = android.graphics.Canvas(styled)
        val paint = android.graphics.Paint().apply {
            colorFilter = android.graphics.ColorMatrixColorFilter(style.toColorMatrix())
        }
        canvas.drawBitmap(original, 0f, 0f, paint)
        original.recycle()
        styled
    } else {
        original
    }

    // ขั้น 2: ปรับคมชัดเพิ่มเติมด้วยซอฟต์แวร์เสมอ (นอกเหนือจาก EDGE_MODE_HIGH_QUALITY ที่ขอจากฮาร์ดแวร์
    // ตอนถ่ายไปแล้ว) เพื่อให้ภาพที่ "บันทึกลงเครื่องจริง" คมที่สุดเท่าที่ทำได้เสมอทุกภาพ
    val sharpened = try {
        sharpenBitmap(edited)
    } catch (e: Exception) {
        edited
    }
    if (sharpened !== edited) edited.recycle()
    edited = sharpened

    // เข้ารหัสลงไฟล์ชั่วคราวก่อน แล้วค่อยเขียนทับไฟล์จริงเมื่อสำเร็จเท่านั้น กันไฟล์ต้นฉบับเสีย
    // ถ้าแอปถูกปิดกลางคัน/เข้ารหัสล้มเหลว
    val tempFile = java.io.File(context.cacheDir, "style_${System.currentTimeMillis()}.jpg")
    val encoded = try {
        tempFile.outputStream().use { fos -> edited.compress(Bitmap.CompressFormat.JPEG, 95, fos) }
    } catch (e: Exception) {
        false
    }
    if (encoded) {
        try {
            context.contentResolver.openOutputStream(uri, "wt")?.use { os ->
                tempFile.inputStream().use { it.copyTo(os) }
            }
        } catch (e: Exception) {
            // ไม่สำเร็จ: ไฟล์ต้นฉบับใน MediaStore อาจถูกเขียนไปบางส่วน แต่ผู้ใช้ยังมีไฟล์ชั่วคราวสำรองใน cache
        }
    }
    tempFile.delete()

    // เขียน orientation กลับไป เพราะการเข้ารหัส JPEG ใหม่ไม่ได้คัดลอก EXIF เดิมมาด้วย
    try {
        context.contentResolver.openFileDescriptor(uri, "rw")?.use { pfd ->
            androidx.exifinterface.media.ExifInterface(pfd.fileDescriptor).apply {
                setAttribute(androidx.exifinterface.media.ExifInterface.TAG_ORIENTATION, exifOrientation.toString())
                saveAttributes()
            }
        }
    } catch (e: Exception) {
        // ไม่ร้ายแรงถ้าทำไม่สำเร็จ ภาพยังดูได้ปกติแค่บางเครื่องอาจหมุนผิดถ้าถ่ายแนวตั้ง
    }
    edited.recycle()
}

// ปรับภาพให้คมชัดขึ้นด้วยตัวกรอง unsharp mask (คอนโวลูชัน 3x3 แบบ Laplacian) ทำงานบนพิกเซลจริง
// ต่างจากสไตล์ภาพที่เป็นแค่ ColorMatrix (ปรับสีต่อพิกเซล ไม่ทำให้คมขึ้นได้) นี่คือคมชัดแบบพื้นที่ภาพจริง
// ใช้ค่า amount พอประมาณเพื่อไม่ให้เกิดขอบเรืองแสง (halo) เกินจริงเหมือนภาพถูกแต่งจัดเกินไป
private fun sharpenBitmap(src: Bitmap, amount: Float = 0.6f): Bitmap {
    val w = src.width
    val h = src.height
    if (w < 3 || h < 3) return src
    val pixels = IntArray(w * h)
    src.getPixels(pixels, 0, w, 0, 0, w, h)
    val out = IntArray(w * h)
    // เคอร์เนล unsharp mask: center = 1 + 4*amount, เพื่อนบ้านสี่ทิศ = -amount (Laplacian sharpen)
    val center = 1f + 4f * amount
    val edge = -amount
    // หมายเหตุ: จงใจไม่ใช้ local function/lambda ในลูปต่อพิกเซล เพราะภาพ 12+MP มีหลายล้านพิกเซล
    // การสร้างอ็อบเจกต์ปิดล้อม (closure) ต่อพิกเซลจะทำให้ทำงานช้ามากและสร้างขยะให้ GC เก็บเยอะเกินจำเป็น
    // จึงคำนวณทีละแชนแนล R/G/B ตรงๆ ในลูปแทน
    for (y in 0 until h) {
        val yUp = (if (y > 0) y - 1 else y) * w
        val yDown = (if (y < h - 1) y + 1 else y) * w
        val yRow = y * w
        for (x in 0 until w) {
            val xLeft = if (x > 0) x - 1 else x
            val xRight = if (x < w - 1) x + 1 else x
            val pC = pixels[yRow + x]
            val pU = pixels[yUp + x]
            val pD = pixels[yDown + x]
            val pL = pixels[yRow + xLeft]
            val pR = pixels[yRow + xRight]

            val a = (pC shr 24) and 0xFF

            val rC = (pC shr 16) and 0xFF
            val rV = (rC * center + (((pU shr 16) and 0xFF) + ((pD shr 16) and 0xFF) + ((pL shr 16) and 0xFF) + ((pR shr 16) and 0xFF)) * edge)
                .roundToInt().coerceIn(0, 255)

            val gC = (pC shr 8) and 0xFF
            val gV = (gC * center + (((pU shr 8) and 0xFF) + ((pD shr 8) and 0xFF) + ((pL shr 8) and 0xFF) + ((pR shr 8) and 0xFF)) * edge)
                .roundToInt().coerceIn(0, 255)

            val bC = pC and 0xFF
            val bV = (bC * center + ((pU and 0xFF) + (pD and 0xFF) + (pL and 0xFF) + (pR and 0xFF)) * edge)
                .roundToInt().coerceIn(0, 255)

            out[yRow + x] = (a shl 24) or (rV shl 16) or (gV shl 8) or bV
        }
    }
    val result = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
    result.setPixels(out, 0, w, 0, 0, w, h)
    return result
}

@Composable
private fun GlassIconButton(
    icon: ImageVector,
    tint: Color = Color.White,
    size: Dp = 40.dp,
    onClick: () -> Unit
) {
    Box(
        Modifier
            .size(size)
            .clip(CircleShape)
            .background(Color.Black.copy(alpha = 0.28f))
            .background(
                androidx.compose.ui.graphics.Brush.verticalGradient(
                    listOf(Color.White.copy(alpha = 0.22f), Color.White.copy(alpha = 0.08f))
                )
            )
            .border(0.8.dp, Color.White.copy(alpha = 0.32f), CircleShape)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Icon(icon, contentDescription = null, tint = tint, modifier = Modifier.size(size * 0.5f))
    }
}

// อ่านรายการกล้องทั้งหมดที่ Android เปิดให้แอปภายนอกเห็น
// ≈mm คือความยาวโฟกัสเทียบกล้องฟูลเฟรม: อัลตราไวด์ประมาณ 13-16 mm, กล้องหลักประมาณ 23-26 mm
private fun describeCameras(context: Context): String {
    val cm = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
    val sb = StringBuilder()
    for (id in cm.cameraIdList) {
        try {
            val ch = cm.getCameraCharacteristics(id)
            val facing = when (ch.get(CameraCharacteristics.LENS_FACING)) {
                CameraCharacteristics.LENS_FACING_BACK -> "หลัง"
                CameraCharacteristics.LENS_FACING_FRONT -> "หน้า"
                else -> "อื่น"
            }
            val focals = ch.get(CameraCharacteristics.LENS_INFO_AVAILABLE_FOCAL_LENGTHS)
            val size = ch.get(CameraCharacteristics.SENSOR_INFO_PHYSICAL_SIZE)
            val eq = if (focals != null && focals.isNotEmpty() && size != null) {
                val diag = kotlin.math.sqrt(size.width * size.width + size.height * size.height)
                "%.0f".format(focals[0] * 43.27f / diag)
            } else {
                "?"
            }
            val zoomRange = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                ch.get(CameraCharacteristics.CONTROL_ZOOM_RATIO_RANGE)?.let { "${it.lower}-${it.upper}" } ?: "-"
            } else {
                "-"
            }
            val physical = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                ch.physicalCameraIds.joinToString(",").ifEmpty { "-" }
            } else {
                "-"
            }
            sb.appendLine("ID $id | $facing | ≈${eq}mm | ซูม $zoomRange | กล้องจริง $physical")

            val ois = ch.get(CameraCharacteristics.LENS_INFO_AVAILABLE_OPTICAL_STABILIZATION)
                ?.contains(CameraCharacteristics.LENS_OPTICAL_STABILIZATION_MODE_ON) == true
            val eis = ch.get(CameraCharacteristics.CONTROL_AVAILABLE_VIDEO_STABILIZATION_MODES)
                ?.contains(CameraCharacteristics.CONTROL_VIDEO_STABILIZATION_MODE_ON) == true
            sb.appendLine("   กันสั่น: OIS ${if (ois) "ได้" else "ไม่ได้"} / EIS ${if (eis) "ได้" else "ไม่ได้"}")

            val fpsRanges = ch.get(CameraCharacteristics.CONTROL_AE_AVAILABLE_TARGET_FPS_RANGES)
                ?.joinToString(" ") { "${it.lower}-${it.upper}" } ?: "-"
            sb.appendLine("   fps ปกติ: $fpsRanges")
            val highSpeed = ch.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)
                ?.highSpeedVideoFpsRanges?.joinToString(" ") { "${it.lower}-${it.upper}" }
            sb.appendLine("   fps ความเร็วสูง: ${if (highSpeed.isNullOrEmpty()) "-" else highSpeed}")
            val idInt = id.toIntOrNull()
            if (idInt != null) {
                val profiles = listOf(
                    "4K" to CamcorderProfile.QUALITY_2160P,
                    "1080p" to CamcorderProfile.QUALITY_1080P,
                    "720p" to CamcorderProfile.QUALITY_720P
                ).mapNotNull { (name, q) ->
                    if (CamcorderProfile.hasProfile(idInt, q)) "$name=${CamcorderProfile.get(idInt, q)?.videoFrameRate}" else null
                }
                sb.appendLine("   โปรไฟล์วิดีโอ: ${profiles.joinToString(" ")}")
            }
        } catch (e: Exception) {
            sb.appendLine("ID $id | อ่านไม่ได้: ${e.message}")
        }
    }
    return sb.toString().ifEmpty { "ไม่พบกล้อง" }
}

// อ่านไฟล์วิดีโอที่เพิ่งอัด แล้วคำนวณเฟรมเรตจริงจากจำนวนเฟรมหารด้วยความยาว
private fun describeVideo(context: Context, uri: Uri): String? = runCatching {
    val r = MediaMetadataRetriever()
    r.setDataSource(context, uri)
    val w = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)
    val h = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)
    val frames = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_FRAME_COUNT)?.toDoubleOrNull()
    val durMs = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toDoubleOrNull()
    r.release()
    val fps = if (frames != null && durMs != null && durMs > 0) frames / (durMs / 1000.0) else null
    "${w}x$h" + (fps?.let { " | %.1f fps".format(it) } ?: "")
}.getOrNull()

// อ่านขนาดภาพที่เพิ่งบันทึก (ไม่ต้องโหลดภาพทั้งใบ)
private fun describePhoto(context: Context, uri: Uri): String? = runCatching {
    val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
    val mp = opts.outWidth * opts.outHeight / 1_000_000.0
    "${opts.outWidth}x${opts.outHeight} | %.1f MP".format(mp)
}.getOrNull()
