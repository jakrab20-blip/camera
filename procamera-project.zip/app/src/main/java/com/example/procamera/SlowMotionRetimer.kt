package com.example.procamera

import android.content.ContentValues
import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMetadataRetriever
import android.media.MediaMuxer
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import java.io.File
import java.nio.ByteBuffer

// =====================================================================
//  ทำให้ไฟล์วิดีโอที่อัดด้วยเฟรมเรตสูง (โหมดสโลโมชัน) เล่นช้าลงจริงตอนเปิดดู
//  วิธีทำ: วัดเฟรมเรตจริงจากไฟล์ (จำนวนเฟรม / ความยาว) แล้ว "ยืด" ค่า presentation timestamp
//  ของทุกเฟรมออกตามอัตราส่วนเทียบกับเฟรมเรตเป้าหมายสำหรับเล่น (30fps) — ไม่ต้องถอดรหัส/เข้ารหัสใหม่
//  จึงเร็วและภาพไม่เสียคุณภาพ
//  หมายเหตุ: ตัดเสียงออกจากไฟล์ผลลัพธ์ เพราะยืดเสียงตามอัตราเดียวกับภาพจะทำให้เสียงเพี้ยน/ช้าผิดปกติ
//  (คนละเรื่องกับการยืดวิดีโอ ซึ่งแค่เว้นระยะเฟรมภาพห่างขึ้นก็ดูลื่นปกติ)
// =====================================================================
object SlowMotionRetimer {

    /** สาเหตุที่ retime ล้มเหลวครั้งล่าสุด (ว่างถ้าสำเร็จ) ใช้แสดงให้ผู้ใช้เห็นจริง ๆ แทนข้อความกว้าง ๆ */
    @Volatile var lastFailure: String = ""

    /** สรุปผลเมื่อ retime สำเร็จ เช่น "อัดได้ 60.0 fps ช้าลง 2.0 เท่า" */
    @Volatile var lastSummary: String = ""

    /** คืน Uri ไฟล์วิดีโอที่ retime แล้ว หรือ null ถ้าทำไม่ได้ (เช่นเฟรมเรตจริงไม่ได้สูงกว่าเป้าหมายจริง) */
    fun retime(
        context: Context,
        sourceUri: Uri,
        outputDisplayName: String,
        outputRelativePath: String = "Movies/ProCamera",
        targetPlaybackFps: Double = 30.0
    ): Uri? {
        lastFailure = ""
        lastSummary = ""
        val measuredFps = measureFps(context, sourceUri)
        if (measuredFps == null) {
            lastFailure = "อ่านเฟรมเรตจากไฟล์ไม่ได้ (ไฟล์ไม่มีข้อมูลจำนวนเฟรม/เวลา)"
            return null
        }
        val scale = measuredFps / targetPlaybackFps
        if (scale <= 1.05) {
            // ไม่ได้อัดเร็วกว่าปกติจริง ๆ ไม่ต้อง retime
            lastFailure = "เครื่องอัดได้จริงแค่ %.1f fps (ไม่เร็วกว่าปกติ) จึงทำสโลโมชันไม่ได้ " +
                "เครื่องไม่เปิดเฟรมเรตสูงให้แอปนี้ (แอปกล้องของเครื่องอาจใช้ช่องทางพิเศษที่แอปอื่นเข้าไม่ถึง)"
            lastFailure = lastFailure.format(measuredFps)
            return null
        }
        val rotation = runCatching {
            val r = MediaMetadataRetriever()
            r.setDataSource(context, sourceUri)
            val v = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
            r.release()
            v
        }.getOrDefault(0)

        val tempOut = File(context.cacheDir, "slomo_${System.currentTimeMillis()}.mp4")
        val ok = try {
            remux(context, sourceUri, tempOut, scale, rotation, targetPlaybackFps.toInt())
        } catch (e: Exception) {
            lastFailure = "รวมไฟล์ล้มเหลว: ${e.javaClass.simpleName}: ${e.message}"
            false
        }
        if (!ok) {
            if (lastFailure.isEmpty()) lastFailure = "ไม่พบแทร็กวิดีโอ/เฟรมให้ประมวลผลในไฟล์"
            tempOut.delete()
            return null
        }

        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, outputDisplayName)
            put(MediaStore.MediaColumns.MIME_TYPE, "video/mp4")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                put(MediaStore.MediaColumns.RELATIVE_PATH, outputRelativePath)
                put(MediaStore.MediaColumns.IS_PENDING, 1)
            }
        }
        val outUri = context.contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
        if (outUri == null) {
            lastFailure = "สร้างไฟล์ในแกลเลอรีไม่ได้"
            tempOut.delete()
            return null
        }
        return try {
            context.contentResolver.openOutputStream(outUri)?.use { out ->
                tempOut.inputStream().use { it.copyTo(out) }
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val done = ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }
                context.contentResolver.update(outUri, done, null, null)
            }
            lastSummary = "อัดได้ %.1f fps ช้าลง %.1f เท่า".format(measuredFps, scale)
            outUri
        } catch (e: Exception) {
            lastFailure = "บันทึกไฟล์ไม่สำเร็จ: ${e.javaClass.simpleName}: ${e.message}"
            runCatching { context.contentResolver.delete(outUri, null, null) }
            null
        } finally {
            tempOut.delete()
        }
    }

    // วัดเฟรมเรตจริง: ลองอ่านจากเมทาดาทาก่อน (Android 9+ บางเครื่องไม่คืนค่า) ถ้าไม่ได้ให้นับเฟรมจาก timestamp ตรง ๆ
    private fun measureFps(context: Context, uri: Uri): Double? {
        val meta = runCatching {
            val r = MediaMetadataRetriever()
            r.setDataSource(context, uri)
            val frames = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_FRAME_COUNT)?.toDoubleOrNull()
            val durMs = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toDoubleOrNull()
            r.release()
            if (frames != null && durMs != null && durMs > 0) frames / (durMs / 1000.0) else null
        }.getOrNull()
        if (meta != null) return meta
        return runCatching {
            val ex = MediaExtractor()
            context.contentResolver.openFileDescriptor(uri, "r")?.use { pfd -> ex.setDataSource(pfd.fileDescriptor) }
            var track = -1
            for (i in 0 until ex.trackCount) {
                if (ex.getTrackFormat(i).getString(MediaFormat.KEY_MIME)?.startsWith("video/") == true) {
                    track = i
                    break
                }
            }
            if (track < 0) {
                ex.release()
                return@runCatching null
            }
            ex.selectTrack(track)
            var n = 0
            var first = -1L
            var last = -1L
            while (true) {
                val t = ex.sampleTime
                if (t < 0) break
                if (first < 0) first = t
                last = t
                n++
                if (!ex.advance()) break
            }
            ex.release()
            if (n >= 2 && last > first) (n - 1) / ((last - first) / 1_000_000.0) else null
        }.getOrNull()
    }

    private fun remux(
        context: Context,
        sourceUri: Uri,
        outFile: File,
        scale: Double,
        rotation: Int,
        playbackFps: Int
    ): Boolean {
        val extractor = MediaExtractor()
        context.contentResolver.openFileDescriptor(sourceUri, "r")?.use { pfd ->
            extractor.setDataSource(pfd.fileDescriptor)
        } ?: return false

        var videoTrack = -1
        var videoFormat: MediaFormat? = null
        for (i in 0 until extractor.trackCount) {
            val f = extractor.getTrackFormat(i)
            val mime = f.getString(MediaFormat.KEY_MIME) ?: continue
            if (mime.startsWith("video/")) {
                videoTrack = i
                videoFormat = f
                break
            }
        }
        if (videoTrack < 0 || videoFormat == null) {
            extractor.release()
            return false
        }

        runCatching { videoFormat.setInteger(MediaFormat.KEY_FRAME_RATE, playbackFps) }
        val muxer = MediaMuxer(outFile.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        // ต้องบอกทิศทางภาพเอง ไม่งั้นคลิปที่ถ่ายแนวตั้งจะกลายเป็นตะแคงหลังรวมไฟล์ใหม่
        if (rotation == 0 || rotation == 90 || rotation == 180 || rotation == 270) muxer.setOrientationHint(rotation)
        val outTrack = muxer.addTrack(videoFormat)
        muxer.start()

        extractor.selectTrack(videoTrack)
        val buffer = ByteBuffer.allocate(8 * 1024 * 1024)
        val bufferInfo = MediaCodec.BufferInfo()
        var firstPts = -1L
        var wroteAny = false

        while (true) {
            buffer.clear()
            val size = extractor.readSampleData(buffer, 0)
            if (size < 0) break
            val pts = extractor.sampleTime
            if (firstPts < 0) firstPts = pts
            bufferInfo.offset = 0
            bufferInfo.size = size
            bufferInfo.presentationTimeUs = firstPts + ((pts - firstPts) * scale).toLong()
            bufferInfo.flags = if (extractor.sampleFlags and MediaExtractor.SAMPLE_FLAG_SYNC != 0) {
                MediaCodec.BUFFER_FLAG_KEY_FRAME
            } else {
                0
            }
            muxer.writeSampleData(outTrack, buffer, bufferInfo)
            wroteAny = true
            extractor.advance()
        }

        extractor.release()
        muxer.stop()
        muxer.release()
        return wroteAny
    }
}
