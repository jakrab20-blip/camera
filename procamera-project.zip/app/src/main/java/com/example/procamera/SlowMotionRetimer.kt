package com.example.procamera

import android.content.ContentValues
import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMetadataRetriever
import android.media.MediaMuxer
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import java.io.File
import java.nio.ByteBuffer

// =====================================================================
//  ทำให้ไฟล์วิดีโอที่อัดด้วยเฟรมเรตสูง (โหมดสโลโมชัน) เล่นช้าลงจริงตอนเปิดดู
//  วิธีทำ: วัดเฟรมเรตจริงจากไฟล์ (จำนวนเฟรม / ความยาว) แล้ว "ยืด" ค่า presentation timestamp
//  ของทุกเฟรมออกตามอัตราส่วนเทียบกับเฟรมเรตเป้าหมายสำหรับเล่น (30fps) — ไม่ต้องถอดรหัส/เข้ารหัสใหม่
//  จึงเร็วและภาพไม่เสียคุณภาพ
//  หมายเหตุ: ตัดเสียงออกจากไฟล์ผลลัพธ์ เพราะยืดเสียงตามอัตราเดียวกับภาพจะทำให้เสียงเพี้ยน/ช้าผิดปกติ
//  (คนละเรื่องกับการยืดวิดีโอ ซึ่งแค่เว้นระยะเฟรมภาพห่างขึ้นก็ดูลื่นปกติ)
// =====================================================================
object SlowMotionRetimer {

    /** คืน Uri ไฟล์วิดีโอที่ retime แล้ว หรือ null ถ้าทำไม่ได้ (เช่นเฟรมเรตจริงไม่ได้สูงกว่าเป้าหมายจริง) */
    fun retime(
        context: Context,
        sourceUri: Uri,
        outputDisplayName: String,
        outputRelativePath: String = "Movies/ProCamera",
        targetPlaybackFps: Double = 30.0
    ): Uri? {
        val measuredFps = measureFps(context, sourceUri) ?: return null
        val scale = measuredFps / targetPlaybackFps
        if (scale <= 1.05) return null // ไม่ได้อัดเร็วกว่าปกติจริง ๆ ไม่ต้อง retime

        val tempOut = File(context.cacheDir, "slomo_${System.currentTimeMillis()}.mp4")
        val ok = try {
            remux(context, sourceUri, tempOut, scale)
        } catch (e: Exception) {
            false
        }
        if (!ok) {
            tempOut.delete()
            return null
        }

        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, outputDisplayName)
            put(MediaStore.MediaColumns.MIME_TYPE, "video/mp4")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                put(MediaStore.MediaColumns.RELATIVE_PATH, outputRelativePath)
                put(MediaStore.MediaColumns.IS_PENDING, 1)
            }
        }
        val outUri = context.contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
        if (outUri == null) {
            tempOut.delete()
            return null
        }
        return try {
            context.contentResolver.openOutputStream(outUri)?.use { out ->
                tempOut.inputStream().use { it.copyTo(out) }
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val done = ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }
                context.contentResolver.update(outUri, done, null, null)
            }
            outUri
        } catch (e: Exception) {
            runCatching { context.contentResolver.delete(outUri, null, null) }
            null
        } finally {
            tempOut.delete()
        }
    }

    private fun measureFps(context: Context, uri: Uri): Double? = runCatching {
        val r = MediaMetadataRetriever()
        r.setDataSource(context, uri)
        val frames = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_FRAME_COUNT)?.toDoubleOrNull()
        val durMs = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toDoubleOrNull()
        r.release()
        if (frames != null && durMs != null && durMs > 0) frames / (durMs / 1000.0) else null
    }.getOrNull()

    private fun remux(context: Context, sourceUri: Uri, outFile: File, scale: Double): Boolean {
        val extractor = MediaExtractor()
        context.contentResolver.openFileDescriptor(sourceUri, "r")?.use { pfd ->
            extractor.setDataSource(pfd.fileDescriptor)
        } ?: return false

        var videoTrack = -1
        var videoFormat: MediaFormat? = null
        for (i in 0 until extractor.trackCount) {
            val f = extractor.getTrackFormat(i)
            val mime = f.getString(MediaFormat.KEY_MIME) ?: continue
            if (mime.startsWith("video/")) {
                videoTrack = i
                videoFormat = f
                break
            }
        }
        if (videoTrack < 0 || videoFormat == null) {
            extractor.release()
            return false
        }

        val muxer = MediaMuxer(outFile.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        val outTrack = muxer.addTrack(videoFormat)
        muxer.start()

        extractor.selectTrack(videoTrack)
        val buffer = ByteBuffer.allocate(8 * 1024 * 1024)
        val bufferInfo = MediaCodec.BufferInfo()
        var firstPts = -1L
        var wroteAny = false

        while (true) {
            buffer.clear()
            val size = extractor.readSampleData(buffer, 0)
            if (size < 0) break
            val pts = extractor.sampleTime
            if (firstPts < 0) firstPts = pts
            bufferInfo.offset = 0
            bufferInfo.size = size
            bufferInfo.presentationTimeUs = firstPts + ((pts - firstPts) * scale).toLong()
            bufferInfo.flags = if (extractor.sampleFlags and MediaExtractor.SAMPLE_FLAG_SYNC != 0) {
                MediaCodec.BUFFER_FLAG_KEY_FRAME
            } else {
                0
            }
            muxer.writeSampleData(outTrack, buffer, bufferInfo)
            wroteAny = true
            extractor.advance()
        }

        extractor.release()
        muxer.stop()
        muxer.release()
        return wroteAny
    }
}
