package com.example.procamera

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

// ทดสอบเฉพาะฟังก์ชันคำนวณล้วน ๆ (ไม่พึ่ง Android) รันด้วย ./gradlew testDebugUnitTest
class ProExtrasTest {
    @Test
    fun zoomSteps_followRealRange() {
        assertEquals(listOf(0.5f, 1f, 2f, 3f, 5f, 10f), zoomStepsFor(0.5f, 10f))
        assertEquals(listOf(1f, 2f), zoomStepsFor(1f, 2f))
        // ช่วงซูมที่เริ่มเหนือ 0.5 ต้องปัดขึ้น ไม่ให้ต่ำกว่าค่าต่ำสุดที่กล้องรับ
        assertTrue(zoomStepsFor(0.55f, 4f).first() >= 0.55f)
    }

    @Test
    fun zoomLabel_wholeAndFraction() {
        assertEquals("2", zoomLabel(2f))
        assertEquals("0.6", zoomLabel(0.6f).replace(',', '.'))
    }

    @Test
    fun mapUpright_rotations() {
        val out = FloatArray(2)
        mapUpright(0, 1f, 2f, 4, 2, out)
        assertEquals(1f, out[0], 0.001f); assertEquals(2f, out[1], 0.001f)
        mapUpright(90, 0.5f, 0.5f, 4, 2, out)
        assertEquals(0.5f, out[0], 0.001f); assertEquals(1.5f, out[1], 0.001f)
        mapUpright(180, 1f, 1f, 4, 2, out)
        assertEquals(3f, out[0], 0.001f); assertEquals(1f, out[1], 0.001f)
        mapUpright(270, 0.5f, 0.5f, 4, 2, out)
        assertEquals(3.5f, out[0], 0.001f); assertEquals(0.5f, out[1], 0.001f)
    }

    @Test
    fun sharpenAmount_levels() {
        assertEquals(0f, sharpenAmount(0), 0f)
        assertTrue(sharpenAmount(3) > sharpenAmount(2))
        assertTrue(sharpenAmount(2) > sharpenAmount(1))
    }
}
